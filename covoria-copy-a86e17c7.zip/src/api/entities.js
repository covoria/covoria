import { base44 } from './base44Client';


export const InsurancePolicy = base44.entities.InsurancePolicy;

export const SavingsAccount = base44.entities.SavingsAccount;

export const Insight = base44.entities.Insight;

export const Product = base44.entities.Product;

export const UserActivity = base44.entities.UserActivity;

export const Document = base44.entities.Document;

export const DocumentField = base44.entities.DocumentField;

export const AssistantConversation = base44.entities.AssistantConversation;

export const LLMUsageLog = base44.entities.LLMUsageLog;

export const ConversationSummary = base44.entities.ConversationSummary;

export const AIFeedback = base44.entities.AIFeedback;

export const ForecastItem = base44.entities.ForecastItem;

export const BehavioralEvent = base44.entities.BehavioralEvent;

export const UserBehaviorProfile = base44.entities.UserBehaviorProfile;

export const UserSimulationLog = base44.entities.UserSimulationLog;

export const AssistantMemoryLog = base44.entities.AssistantMemoryLog;

export const FeedbackLog = base44.entities.FeedbackLog;

export const BusinessEntity = base44.entities.BusinessEntity;

export const SmartPatternMatch = base44.entities.SmartPatternMatch;

export const InsuranceKnowledgeBase = base44.entities.InsuranceKnowledgeBase;

export const DocumentAnalysisLog = base44.entities.DocumentAnalysisLog;

export const InsightInteraction = base44.entities.InsightInteraction;

export const AdvisorBehaviorTrainingSet_v1 = base44.entities.AdvisorBehaviorTrainingSet_v1;

export const AIPersona = base44.entities.AIPersona;

export const UploadProcessingLog = base44.entities.UploadProcessingLog;



// auth sdk:
export const User = base44.auth;