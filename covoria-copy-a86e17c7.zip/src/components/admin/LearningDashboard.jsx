
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, 
  TrendingUp, 
  Users, 
  MessageSquare,
  Target,
  Zap,
  Clock,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  BarChart3,
  Activity,
  Lightbulb
} from 'lucide-react';
import { aiLearningEngine } from '@/api/functions';
import { continuousLearningOrchestrator } from '@/api/functions';

// Advanced AI Learning Dashboard for Administrators
export default function LearningDashboard() {
  const [learningStats, setLearningStats] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [recentAnalysis, setRecentAnalysis] = useState(null);
  const [learningCycle, setLearningCycle] = useState({});
  const [isRunningCycle, setIsRunningCycle] = useState(false);

  useEffect(() => {
    loadLearningData();
    const interval = setInterval(loadLearningData, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const loadLearningData = async () => {
    setIsLoading(true);
    try {
      // Load learning analytics
      const analysisResponse = await aiLearningEngine({ operation: 'analyze', timeframe: '7d' });
      if (analysisResponse.data.success) {
        setRecentAnalysis(analysisResponse.data.analysis);
      }

      // Load learning report
      const reportResponse = await aiLearningEngine({ operation: 'report' });
      if (reportResponse.data.success) {
        setLearningStats(reportResponse.data.report);
      }

    } catch (error) {
      console.error('Failed to load learning data:', error);
    }
    setIsLoading(false);
  };

  const runLearningCycle = async (autoApply = false) => {
    setIsRunningCycle(true);
    try {
      const response = await continuousLearningOrchestrator({ 
        trigger: 'manual', 
        auto_apply: autoApply 
      });
      
      if (response.data.success) {
        setLearningCycle(response.data.orchestration);
        setTimeout(loadLearningData, 2000); // Refresh data after cycle
      }
    } catch (error) {
      console.error('Learning cycle failed:', error);
    }
    setIsRunningCycle(false);
  };

  const tabs = [
    { id: 'overview', label: 'Learning Overview', icon: Brain },
    { id: 'performance', label: 'Performance Metrics', icon: BarChart3 },
    { id: 'improvements', label: 'Applied Improvements', icon: TrendingUp },
    { id: 'cycles', label: 'Learning Cycles', icon: RefreshCw }
  ];

  if (isLoading && !recentAnalysis) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="grid grid-cols-4 gap-4">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
            <div className="h-96 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Brain className="w-8 h-8 text-purple-600" />
              AI Learning Dashboard
            </h1>
            <p className="text-gray-600 mt-2">
              Continuous learning system monitoring and control
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            <Button
              onClick={() => runLearningCycle(false)}
              disabled={isRunningCycle}
              variant="outline"
              className="border-purple-200 text-purple-700 hover:bg-purple-50"
            >
              {isRunningCycle ? (
                <div className="w-4 h-4 border-2 border-purple-600 border-t-transparent rounded-full animate-spin mr-2" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Run Learning Cycle
            </Button>
            
            <Button
              onClick={() => runLearningCycle(true)}
              disabled={isRunningCycle}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Zap className="w-4 h-4 mr-2" />
              Auto-Apply Improvements
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-4 gap-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100 text-sm">User Satisfaction</p>
                    <p className="text-3xl font-bold">
                      {((learningStats.executive_summary?.user_satisfaction || 3) * 20).toFixed(1)}%
                    </p>
                    <p className="text-blue-100 text-xs mt-1">
                      {recentAnalysis?.feedback_summary?.total_feedback || 0} feedback points
                    </p>
                  </div>
                  <Users className="w-8 h-8 text-blue-200" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100 text-sm">Learning Progress</p>
                    <p className="text-3xl font-bold">
                      {((learningStats.executive_summary?.learning_progress || 0.5) * 100).toFixed(0)}%
                    </p>
                    <p className="text-green-100 text-xs mt-1">
                      Continuous improvement
                    </p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-green-200" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100 text-sm">AI Interactions</p>
                    <p className="text-3xl font-bold">
                      {recentAnalysis?.conversation_patterns?.total_conversations || 0}
                    </p>
                    <p className="text-purple-100 text-xs mt-1">
                      Last 7 days
                    </p>
                  </div>
                  <MessageSquare className="w-8 h-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100 text-sm">System Performance</p>
                    <p className="text-3xl font-bold">
                      {((recentAnalysis?.performance_metrics?.success_rate || 0.95) * 100).toFixed(1)}%
                    </p>
                    <p className="text-orange-100 text-xs mt-1">
                      Uptime & reliability
                    </p>
                  </div>
                  <Activity className="w-8 h-8 text-orange-200" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Tab Navigation */}
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center gap-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-purple-500 text-purple-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-6"
            >
              {/* Learning Insights */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-yellow-600" />
                    Recent Learning Insights
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {learningStats.learning_metrics?.feedback_trends && (
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-medium text-blue-900 mb-2">Feedback Trends</h4>
                      <div className="text-sm text-blue-800">
                        <div className="flex justify-between mb-1">
                          <span>Rating Trend:</span>
                          <Badge className="bg-blue-100 text-blue-800">
                            {learningStats.learning_metrics.feedback_trends.rating_trend}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Volume Trend:</span>
                          <Badge className="bg-green-100 text-green-800">
                            {learningStats.learning_metrics.feedback_trends.volume_trend}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  )}

                  {recentAnalysis?.improvement_opportunities?.map((opp, index) => (
                    <div key={index} className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5" />
                        <div>
                          <h4 className="font-medium text-yellow-900">{opp.area}</h4>
                          <p className="text-sm text-yellow-800 mt-1">{opp.description}</p>
                          <Badge className={`mt-2 text-xs ${
                            opp.priority === 'critical' ? 'bg-red-100 text-red-800' :
                            opp.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                            'bg-yellow-100 text-yellow-800'
                          }`}>
                            {opp.priority} priority
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* System Health */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-green-600" />
                    Learning System Health
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {((recentAnalysis?.performance_metrics?.success_rate || 0.95) * 100).toFixed(0)}%
                      </div>
                      <div className="text-sm text-green-700">Success Rate</div>
                    </div>
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">
                        {recentAnalysis?.performance_metrics?.response_times?.average?.toFixed(0) || 1200}ms
                      </div>
                      <div className="text-sm text-blue-700">Avg Response</div>
                    </div>
                  </div>

                  {recentAnalysis?.learning_insights?.map((insight, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-lg">
                      <h4 className="font-medium text-gray-900 mb-1">{insight.insight}</h4>
                      <p className="text-sm text-gray-700 mb-2">{insight.finding}</p>
                      <p className="text-xs text-gray-600 italic">{insight.implication}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {activeTab === 'cycles' && learningCycle.phases && (
            <motion.div
              key="cycles"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <RefreshCw className="w-5 h-5 text-purple-600" />
                    Latest Learning Cycle Results
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      <div className="text-center p-3 bg-purple-50 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">
                          {learningCycle.phases?.length || 0}
                        </div>
                        <div className="text-sm text-purple-700">Phases Completed</div>
                      </div>
                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">
                          {learningCycle.improvements_applied || 0}
                        </div>
                        <div className="text-sm text-green-700">Improvements Applied</div>
                      </div>
                      <div className="text-center p-3 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">
                          {(learningCycle.total_processing_time / 1000).toFixed(1)}s
                        </div>
                        <div className="text-sm text-blue-700">Processing Time</div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {learningCycle.phases?.map((phase, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              phase.status === 'completed' ? 'bg-green-100' : 
                              phase.status === 'failed' ? 'bg-red-100' : 'bg-yellow-100'
                            }`}>
                              {phase.status === 'completed' ? (
                                <CheckCircle className="w-4 h-4 text-green-600" />
                              ) : phase.status === 'failed' ? (
                                <AlertTriangle className="w-4 h-4 text-red-600" />
                              ) : (
                                <Clock className="w-4 h-4 text-yellow-600" />
                              )}
                            </div>
                            <div>
                              <h4 className="font-medium text-gray-900 capitalize">
                                {phase.phase.replace('_', ' ')}
                              </h4>
                              <p className="text-sm text-gray-600">
                                Status: {phase.status}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium text-gray-900">
                              {(phase.duration_ms / 1000).toFixed(2)}s
                            </div>
                            <div className="text-xs text-gray-500">
                              {phase.data_points && `${phase.data_points} data points`}
                              {phase.patterns_identified && `${phase.patterns_identified} patterns`}
                              {phase.improvements_generated && `${phase.improvements_generated} improvements`}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {learningCycle.next_cycle_scheduled && (
                      <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-blue-600" />
                          <span className="text-sm font-medium text-blue-900">Next Cycle Scheduled:</span>
                        </div>
                        <p className="text-sm text-blue-800 mt-1">
                          {new Date(learningCycle.next_cycle_scheduled).toLocaleString()}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
