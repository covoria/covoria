import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UserActivity } from '@/api/entities';
import { RefreshCw, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Skeleton } from '@/components/ui/skeleton';

const activityIcons = {
  policy_upload: '📄',
  document_analysis: '🔬',
  insight_creation: '💡',
  ai_interaction: '🤖',
  profile_update: '👤',
  system_event: '⚙️',
  default: '🔔',
};

export default function RecentActivity() {
  const [activities, setActivities] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchActivities();
  }, []);

  const fetchActivities = async () => {
    setIsLoading(true);
    try {
      const data = await UserActivity.list('-activity_date', 100);
      setActivities(data);
    } catch (error) {
      console.error("Failed to fetch recent activities:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredActivities = activities
    .filter(activity => filter === 'all' || activity.activity_type === filter)
    .slice(0, 10);

  const uniqueActivityTypes = [...new Set(activities.map(a => a.activity_type))];

  return (
    <Card className="covoria-card h-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-500" />
            <CardTitle className="text-white">Recent Activity</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Select onValueChange={setFilter} value={filter}>
              <SelectTrigger className="w-[150px] bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="All Activities" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700 text-white">
                <SelectItem value="all">All Activities</SelectItem>
                {uniqueActivityTypes.map(type => (
                  <SelectItem key={type} value={type} className="capitalize">{type.replace('_', ' ')}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <button onClick={fetchActivities} className="p-2 rounded-md hover:bg-slate-700 text-slate-400 hover:text-white">
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full bg-slate-700" />)}
          </div>
        ) : (
          <ul className="space-y-3">
            <AnimatePresence>
              {filteredActivities.map((activity, index) => (
                <motion.li
                  key={activity.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-start gap-3 p-2 bg-slate-800/50 rounded-lg"
                >
                  <div className="text-lg mt-1">{activityIcons[activity.activity_type] || activityIcons.default}</div>
                  <div className="flex-grow">
                    <p className="text-sm font-medium text-slate-200">{activity.title}</p>
                    <p className="text-xs text-slate-400">{activity.description}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-xs text-slate-500">{new Date(activity.activity_date).toLocaleString()}</p>
                      {activity.impact_score && (
                        <Badge variant="outline" className="border-slate-600 bg-slate-700 text-slate-300">
                          Impact: {activity.impact_score}
                        </Badge>
                      )}
                    </div>
                  </div>
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        )}
        {activities.length === 0 && !isLoading && (
          <div className="text-center py-8 text-slate-500">
            <Activity className="w-8 h-8 mx-auto mb-2" />
            <p>No recent activity.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}