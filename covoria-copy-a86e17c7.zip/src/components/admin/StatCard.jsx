import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

export default function StatCard({ title, value, isLoading }) {
  return (
    <Card className="bg-slate-800 border-slate-700 rounded-xl">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-slate-400">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-8 w-1/2 bg-slate-700" />
        ) : (
          <div className="text-2xl font-bold text-white">{value}</div>
        )}
      </CardContent>
    </Card>
  );
}