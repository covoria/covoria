import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { 
    CheckCircle, 
    AlertTriangle, 
    XCircle, 
    RefreshCw, 
    Database,
    FileText,
    Bot,
    User,
    Settings
} from 'lucide-react';
import { systemSyncVerification } from '@/api/functions';

export default function SystemSyncDashboard() {
    const [syncStatus, setSyncStatus] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [lastCheck, setLastCheck] = useState(null);

    const runVerification = async () => {
        setIsLoading(true);
        try {
            const { data } = await systemSyncVerification();
            setSyncStatus(data);
            setLastCheck(new Date().toLocaleString());
        } catch (error) {
            console.error('Verification failed:', error);
            setSyncStatus({
                status: 'failed',
                error: error.message,
                components: {}
            });
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        runVerification();
    }, []);

    const getStatusIcon = (status) => {
        switch (status) {
            case 'healthy': return <CheckCircle className="w-5 h-5 text-green-500" />;
            case 'warning': return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
            case 'error': return <XCircle className="w-5 h-5 text-red-500" />;
            default: return <Settings className="w-5 h-5 text-gray-500" />;
        }
    };

    const getStatusBadge = (status) => {
        const variants = {
            'healthy': 'bg-green-600',
            'warning': 'bg-yellow-600', 
            'error': 'bg-red-600',
            'failed': 'bg-red-600'
        };
        return <Badge className={variants[status] || 'bg-gray-600'}>{status?.toUpperCase()}</Badge>;
    };

    if (isLoading) {
        return (
            <div className="space-y-6 p-6">
                <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-white">System Sync Verification</h2>
                    <Skeleton className="h-10 w-32 bg-slate-700" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[...Array(6)].map((_, i) => (
                        <Skeleton key={i} className="h-32 bg-slate-700 rounded-lg" />
                    ))}
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-6 p-6">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-2xl font-bold text-white">System Sync Verification</h2>
                    <p className="text-slate-400">
                        Last checked: {lastCheck || 'Never'} • Overall Status: {getStatusBadge(syncStatus?.status)}
                    </p>
                </div>
                <Button onClick={runVerification} disabled={isLoading} className="covoria-gradient">
                    <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    Re-verify
                </Button>
            </div>

            {/* Overall Summary */}
            {syncStatus?.summary && (
                <Card className="bg-slate-800 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            {getStatusIcon(syncStatus.status)}
                            System Health Summary
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                            <div>
                                <div className="text-2xl font-bold text-green-400">{syncStatus.summary.healthyComponents}</div>
                                <div className="text-sm text-slate-400">Healthy</div>
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-yellow-400">{syncStatus.summary.warningsCount}</div>
                                <div className="text-sm text-slate-400">Warnings</div>
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-red-400">{syncStatus.summary.criticalIssues}</div>
                                <div className="text-sm text-slate-400">Errors</div>
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-cyan-400">{Object.keys(syncStatus.components).length}</div>
                                <div className="text-sm text-slate-400">Total Components</div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Component Status Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {syncStatus?.components && Object.entries(syncStatus.components).map(([component, data]) => (
                    <Card key={component} className="bg-slate-800 border-slate-700">
                        <CardHeader className="pb-3">
                            <CardTitle className="text-white text-sm flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    {component === 'knowledgeBase' && <Database className="w-4 h-4" />}
                                    {component === 'userEntities' && <User className="w-4 h-4" />}
                                    {component === 'documents' && <FileText className="w-4 h-4" />}
                                    {component === 'assistantConnection' && <Bot className="w-4 h-4" />}
                                    {!['knowledgeBase', 'userEntities', 'documents', 'assistantConnection'].includes(component) && <Settings className="w-4 h-4" />}
                                    {component.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                                </div>
                                {getStatusIcon(data.status)}
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                            {data.error && (
                                <p className="text-red-400 text-xs">{data.error}</p>
                            )}
                            
                            {data.totalEntries !== undefined && (
                                <p className="text-slate-300 text-xs">Total: {data.totalEntries}</p>
                            )}
                            
                            {data.activeEntries !== undefined && (
                                <p className="text-slate-300 text-xs">Active: {data.activeEntries}</p>
                            )}
                            
                            {data.sources && (
                                <p className="text-slate-300 text-xs">Sources: {data.sources.join(', ')}</p>
                            )}
                            
                            {data.policies !== undefined && (
                                <p className="text-slate-300 text-xs">Policies: {data.policies}</p>
                            )}
                            
                            {data.availableInsights !== undefined && (
                                <p className="text-slate-300 text-xs">Insights: {data.availableInsights}</p>
                            )}
                            
                            {data.note && (
                                <p className="text-slate-400 text-xs italic">{data.note}</p>
                            )}
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Recommendations */}
            {syncStatus?.recommendations && syncStatus.recommendations.length > 0 && (
                <Card className="bg-slate-800 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-white">Recommendations</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {syncStatus.recommendations.map((rec, index) => (
                                <li key={index} className="text-slate-300 text-sm flex items-start gap-2">
                                    <div className="w-2 h-2 bg-cyan-400 rounded-full mt-2 flex-shrink-0"></div>
                                    {rec}
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>
            )}

            {/* Errors */}
            {syncStatus?.errors && syncStatus.errors.length > 0 && (
                <Card className="bg-red-900/20 border-red-700">
                    <CardHeader>
                        <CardTitle className="text-red-400">Critical Issues</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {syncStatus.errors.map((error, index) => (
                                <li key={index} className="text-red-300 text-sm flex items-start gap-2">
                                    <XCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                                    {error}
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}