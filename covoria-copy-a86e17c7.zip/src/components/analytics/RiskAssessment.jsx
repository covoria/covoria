import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { motion } from 'framer-motion';
import { 
    Shield, 
    AlertTriangle, 
    CheckCircle, 
    Clock,
    DollarSign,
    Target,
    Brain
} from 'lucide-react';
import { riskAssessmentEngine } from '@/api/functions/riskAssessmentEngine';

export default function RiskAssessment({ refreshTrigger }) {
    const [riskData, setRiskData] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [expandedMitigation, setExpandedMitigation] = useState(null);

    useEffect(() => {
        loadRiskAssessment();
    }, [refreshTrigger]);

    const loadRiskAssessment = async () => {
        setIsLoading(true);
        try {
            const { data } = await riskAssessmentEngine({ 
                assessment_depth: 'comprehensive' 
            });
            
            if (data?.success) {
                setRiskData(data.data);
            }
        } catch (error) {
            console.error('Failed to load risk assessment:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const getRiskColor = (score) => {
        if (score >= 70) return 'text-red-600 bg-red-100';
        if (score >= 50) return 'text-orange-600 bg-orange-100';
        if (score >= 30) return 'text-yellow-600 bg-yellow-100';
        return 'text-green-600 bg-green-100';
    };

    const getRiskLevelColor = (level) => {
        switch (level) {
            case 'critical': return 'bg-red-500';
            case 'high': return 'bg-orange-500';
            case 'medium': return 'bg-yellow-500';
            default: return 'bg-green-500';
        }
    };

    const getPriorityIcon = (priority) => {
        switch (priority) {
            case 'critical': return <AlertTriangle className="w-4 h-4 text-red-600" />;
            case 'high': return <AlertTriangle className="w-4 h-4 text-orange-600" />;
            case 'medium': return <Clock className="w-4 h-4 text-yellow-600" />;
            default: return <CheckCircle className="w-4 h-4 text-green-600" />;
        }
    };

    const getRiskCategoryIcon = (category) => {
        switch (category) {
            case 'financial': return '💰';
            case 'health': return '🏥';
            case 'property': return '🏠';
            case 'life': return '❤️';
            case 'liability': return '⚖️';
            default: return '🛡️';
        }
    };

    if (isLoading) {
        return (
            <Card className="covoria-card">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-blue-600" />
                        Risk Assessment
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="animate-pulse space-y-3">
                        <div className="h-20 bg-gray-200 rounded"></div>
                        <div className="h-4 bg-gray-200 rounded"></div>
                        <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    </div>
                </CardContent>
            </Card>
        );
    }

    if (!riskData) {
        return (
            <Card className="covoria-card">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-blue-600" />
                        Risk Assessment
                    </CardTitle>
                </CardHeader>
                <CardContent className="text-center py-8">
                    <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">Complete your profile to unlock risk analysis</p>
                    <Button 
                        onClick={loadRiskAssessment} 
                        className="mt-4"
                        variant="outline"
                    >
                        Assess Risk
                    </Button>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="covoria-card">
            <CardHeader>
                <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-blue-600" />
                        Risk Assessment
                    </div>
                    <Badge className={`${getRiskColor(riskData.assessment_summary.overall_risk_score)}`}>
                        {riskData.assessment_summary.risk_level.toUpperCase()}
                    </Badge>
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                {/* Overall Risk Score */}
                <div className="text-center">
                    <div className="relative inline-block">
                        <div className={`w-24 h-24 rounded-full border-8 ${getRiskLevelColor(riskData.assessment_summary.risk_level)} border-opacity-20 flex items-center justify-center`}>
                            <span className="text-2xl font-bold text-gray-800">
                                {riskData.assessment_summary.overall_risk_score}
                            </span>
                        </div>
                    </div>
                    <p className="text-sm text-gray-600 mt-2">Overall Risk Score</p>
                </div>

                {/* Risk Category Breakdown */}
                <div className="space-y-3">
                    <h3 className="font-semibold text-gray-900">Risk Categories</h3>
                    {Object.entries(riskData.detailed_risk_scores).map(([category, score]) => (
                        <div key={category} className="space-y-2">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <span className="text-lg">{getRiskCategoryIcon(category)}</span>
                                    <span className="text-sm font-medium capitalize">
                                        {category.replace('_', ' ')}
                                    </span>
                                </div>
                                <Badge className={`${getRiskColor(score)} text-xs`}>
                                    {score}/100
                                </Badge>
                            </div>
                            <Progress value={score} className="h-2" />
                        </div>
                    ))}
                </div>

                {/* Critical Areas */}
                {riskData.assessment_summary.critical_areas?.length > 0 && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                        <h3 className="font-semibold text-red-900 flex items-center gap-2 mb-2">
                            <AlertTriangle className="w-4 h-4" />
                            Critical Risk Areas
                        </h3>
                        <div className="space-y-2">
                            {riskData.assessment_summary.critical_areas.map((area, index) => (
                                <div key={index} className="flex items-center justify-between">
                                    <span className="text-sm text-red-800 capitalize">
                                        {area.category.replace('_', ' ')}
                                    </span>
                                    <Badge className="bg-red-100 text-red-800 text-xs">
                                        {area.score}/100
                                    </Badge>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Immediate Actions */}
                {riskData.immediate_actions?.length > 0 && (
                    <div className="space-y-3">
                        <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                            <Target className="w-4 h-4 text-orange-500" />
                            Immediate Actions Required
                        </h3>
                        {riskData.immediate_actions.map((action, index) => (
                            <div key={index} className="border-l-4 border-orange-500 bg-orange-50 p-3 rounded-r-lg">
                                <p className="font-medium text-sm text-orange-900">{action.action}</p>
                                <div className="flex items-center gap-4 mt-2 text-xs text-orange-700">
                                    <span className="flex items-center gap-1">
                                        <Clock className="w-3 h-3" />
                                        {action.timeline}
                                    </span>
                                    <span className="flex items-center gap-1">
                                        <DollarSign className="w-3 h-3" />
                                        {action.estimated_cost}
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {/* Risk Mitigations */}
                <div className="space-y-3">
                    <h3 className="font-semibold text-gray-900">Risk Mitigation Strategies</h3>
                    {riskData.risk_mitigations.slice(0, 3).map((mitigation, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="border rounded-lg p-3 hover:bg-gray-50 cursor-pointer transition-colors"
                            onClick={() => setExpandedMitigation(
                                expandedMitigation === index ? null : index
                            )}
                        >
                            <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                    {getPriorityIcon(mitigation.priority)}
                                    <span className="text-sm font-medium capitalize">
                                        {mitigation.risk_category} Risk
                                    </span>
                                </div>
                                <Badge variant="outline" className="text-xs">
                                    {mitigation.priority}
                                </Badge>
                            </div>
                            
                            <p className="text-sm text-gray-700">{mitigation.recommendation}</p>
                            
                            {expandedMitigation === index && (
                                <motion.div
                                    initial={{ opacity: 0, height: 0 }}
                                    animate={{ opacity: 1, height: 'auto' }}
                                    className="mt-3 pt-3 border-t space-y-2"
                                >
                                    <div className="text-xs text-gray-600">
                                        <strong>Impact:</strong> {mitigation.impact}
                                    </div>
                                    <div className="flex items-center justify-between text-xs">
                                        <span><strong>Timeline:</strong> {mitigation.timeline}</span>
                                        <span><strong>Est. Cost:</strong> {mitigation.estimated_cost}</span>
                                    </div>
                                </motion.div>
                            )}
                        </motion.div>
                    ))}
                </div>

                {/* AI Analysis */}
                {riskData.ai_risk_analysis && (
                    <div className="pt-4 border-t">
                        <h3 className="font-semibold text-gray-900 flex items-center gap-2 mb-3">
                            <Brain className="w-4 h-4 text-purple-500" />
                            AI Risk Analysis
                        </h3>
                        <div className="bg-purple-50 rounded-lg p-4">
                            <p className="text-sm text-gray-700 leading-relaxed">
                                {riskData.ai_risk_analysis}
                            </p>
                        </div>
                    </div>
                )}

                {/* Coverage Gaps */}
                {riskData.coverage_gaps?.length > 0 && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <h3 className="font-semibold text-yellow-900 mb-2">Coverage Gaps Identified</h3>
                        <div className="flex flex-wrap gap-2">
                            {riskData.coverage_gaps.map((gap, index) => (
                                <Badge key={index} className="bg-yellow-100 text-yellow-800 capitalize">
                                    {gap.replace('_', ' ')}
                                </Badge>
                            ))}
                        </div>
                    </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2 pt-4">
                    <Button 
                        onClick={loadRiskAssessment} 
                        disabled={isLoading}
                        className="flex-1"
                        variant="outline"
                    >
                        Refresh Assessment
                    </Button>
                    <Button 
                        className="flex-1 covoria-gradient text-white"
                        onClick={() => {/* Navigate to detailed mitigation plan */}}
                    >
                        Create Action Plan
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}