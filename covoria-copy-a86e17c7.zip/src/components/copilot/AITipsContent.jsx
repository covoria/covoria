import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Brain, Lightbulb, TrendingUp, Shield, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AITipsContent() {
  const tips = [
    {
      icon: Shield,
      title: 'Review Coverage Annually',
      description: 'Your life changes, and so should your insurance. Review your policies every year to ensure they still meet your needs.',
      category: 'Best Practice',
      color: 'text-blue-400'
    },
    {
      icon: DollarSign,
      title: 'Bundle for Savings',
      description: 'Consider bundling auto and home insurance with the same provider. You could save 10-25% on your premiums.',
      category: 'Cost Saving',
      color: 'text-green-400'
    },
    {
      icon: TrendingUp,
      title: 'Increase Deductibles Wisely',
      description: 'Raising your deductible can lower premiums, but only do this if you have emergency savings to cover the higher deductible.',
      category: 'Optimization',
      color: 'text-yellow-400'
    },
    {
      icon: Lightbulb,
      title: 'Life Insurance Rule of Thumb',
      description: 'A common guideline is 10-12 times your annual income. However, consider your specific debts, dependents, and goals.',
      category: 'Planning',
      color: 'text-purple-400'
    }
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-lg text-white flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-400" />
            AI-Powered Tips
          </CardTitle>
          <p className="text-sm text-slate-400">
            Smart recommendations to optimize your insurance strategy and financial protection.
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {tips.map((tip, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 bg-slate-700/30 rounded-lg border border-slate-600/50"
              >
                <div className="flex items-start gap-3">
                  <tip.icon className={`w-6 h-6 ${tip.color} mt-1 flex-shrink-0`} />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-white">{tip.title}</h4>
                      <span className="text-xs px-2 py-1 bg-slate-600 text-slate-300 rounded-full">
                        {tip.category}
                      </span>
                    </div>
                    <p className="text-slate-300 text-sm leading-relaxed">{tip.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-lg text-white">Personalized Recommendations</CardTitle>
          <p className="text-sm text-slate-400">
            Based on your profile, here are AI-generated suggestions tailored specifically for you.
          </p>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <div className="w-12 h-12 border-4 border-purple-400 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="font-medium text-slate-300 mb-2">Analyzing Your Profile</p>
            <p className="text-sm text-slate-400">
              Generating personalized recommendations based on your policies and financial goals...
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}