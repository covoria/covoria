
import React from 'react';
import { TrendingUp, Calendar, AlertTriangle, Lightbulb } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function FutureOutlookContent({ forecasts, policies }) {
  const navigate = useNavigate();

  // FIXED: Only show generic content if user has NO policies at all
  if (!policies || policies.length === 0) {
    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-blue-900/30 to-cyan-900/30 rounded-xl p-6 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <AlertTriangle className="w-8 h-8 text-yellow-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No Policies Found</h3>
          <p className="text-slate-300 mb-4">
            Upload your insurance policies first to get personalized future outlook predictions.
          </p>
          <Button
            onClick={() => navigate(createPageUrl('Settings'))}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Upload Policies
          </Button>
        </div>
      </div>
    );
  }

  // FIXED: If user has policies but no forecasts yet, show this
  if (!forecasts || forecasts.length === 0) {
    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-blue-900/30 to-cyan-900/30 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp className="w-6 h-6 text-cyan-400" />
            <h3 className="text-xl font-semibold text-white">Future Outlook Analysis</h3>
          </div>
          <p className="text-slate-300 mb-4">
            Based on your {policies.length} policies, here are key considerations for your financial future:
          </p>
        </div>

        <div className="grid gap-4">
          {/* Life Stage Predictions */}
          <div className="bg-slate-800/50 rounded-xl p-5 border border-slate-700">
            <div className="flex items-center gap-3 mb-3">
              <Calendar className="w-5 h-5 text-green-400" />
              <h4 className="text-white font-semibold">Life Stage Planning</h4>
              <Badge className="bg-green-900/50 text-green-300">Medium Term</Badge>
            </div>
            <p className="text-slate-300 text-sm mb-3">
              As you progress through different life stages, your insurance and savings needs will evolve.
              Major milestones like marriage, home ownership, or having children typically require coverage adjustments.
            </p>
            <Button
              size="sm"
              onClick={() => navigate(createPageUrl('Assistant') + '?prompt=Help me plan for future life changes and how they might affect my insurance needs')}
              className="bg-green-600 hover:bg-green-700"
            >
              Plan for Life Changes
            </Button>
          </div>

          {/* Coverage Review */}
          <div className="bg-slate-800/50 rounded-xl p-5 border border-slate-700">
            <div className="flex items-center gap-3 mb-3">
              <TrendingUp className="w-5 h-5 text-blue-400" />
              <h4 className="text-white font-semibold">Coverage Review Outlook</h4>
              <Badge className="bg-blue-900/50 text-blue-300">Annual</Badge>
            </div>
            <p className="text-slate-300 text-sm mb-3">
              Your current {policies.length} policies provide a foundation, but regular reviews help ensure
              your coverage keeps pace with inflation and life changes.
            </p>
            <Button
              size="sm"
              onClick={() => navigate(createPageUrl('Assistant') + '?prompt=Review my current policies and suggest optimizations for the future')}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Schedule Review
            </Button>
          </div>

          {/* Risk Mitigation */}
          <div className="bg-slate-800/50 rounded-xl p-5 border border-slate-700">
            <div className="flex items-center gap-3 mb-3">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
              <h4 className="text-white font-semibold">Risk Management</h4>
              <Badge className="bg-yellow-900/50 text-yellow-300">Ongoing</Badge>
            </div>
            <p className="text-slate-300 text-sm mb-3">
              Economic changes, inflation, and market volatility can impact your financial security.
              Periodic coverage reviews help ensure your protection keeps pace with these changes.
            </p>
            <Button
              size="sm"
              onClick={() => navigate(createPageUrl('Assistant') + '?prompt=What future risks should I be aware of and how can I prepare for them?')}
              className="bg-yellow-600 hover:bg-yellow-700"
            >
              Assess Future Risks
            </Button>
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-xl p-6 text-center">
          <Lightbulb className="w-8 h-8 text-purple-400 mx-auto mb-3" />
          <h4 className="text-white font-semibold mb-2">AI-Powered Forecasting</h4>
          <p className="text-slate-300 text-sm mb-4">
            Our AI will generate personalized forecasts based on your policies and profile.
            Check back later or ask our assistant for specific predictions.
          </p>
          <Button
            onClick={() => navigate(createPageUrl('Assistant') + '?prompt=Create a comprehensive financial forecast for the next 5-10 years based on my current policies')}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500"
          >
            Generate AI Forecast
          </Button>
        </div>
      </div>
    );
  }

  // If forecasts exist, display them normally
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-green-900/30 to-blue-900/30 rounded-xl p-4 mb-6">
        <div className="flex items-center gap-3 mb-2">
          <TrendingUp className="w-5 h-5 text-green-400" />
          <h3 className="text-lg font-semibold text-white">AI-Generated Forecasts</h3>
        </div>
        <p className="text-green-200 text-sm">
          Based on your uploaded policies and profile, we've identified {forecasts.length} key forecast{forecasts.length > 1 ? 's' : ''} for your consideration.
        </p>
      </div>

      {forecasts.map((forecast, index) => (
        <div key={forecast.id} className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                forecast.risk_level === 'critical' ? 'bg-red-900/50' :
                forecast.risk_level === 'high' ? 'bg-orange-900/50' :
                forecast.risk_level === 'medium' ? 'bg-yellow-900/50' :
                'bg-green-900/50'
              }`}>
                <span className={`font-bold text-sm ${
                  forecast.risk_level === 'critical' ? 'text-red-300' :
                  forecast.risk_level === 'high' ? 'text-orange-300' :
                  forecast.risk_level === 'medium' ? 'text-yellow-300' :
                  'text-green-300'
                }`}>
                  {index + 1}
                </span>
              </div>
              <div>
                <h4 className="text-white font-semibold">{forecast.title}</h4>
                <div className="flex gap-2 mt-1">
                  <Badge className={`${
                    forecast.time_horizon === 'short_term' ? 'bg-cyan-900/50 text-cyan-300' :
                    forecast.time_horizon === 'medium_term' ? 'bg-blue-900/50 text-blue-300' :
                    'bg-purple-900/50 text-purple-300'
                  }`}>
                    {forecast.time_horizon.replace('_', ' ')}
                  </Badge>
                  <Badge className={`${
                    forecast.risk_level === 'critical' ? 'bg-red-900/50 text-red-300' :
                    forecast.risk_level === 'high' ? 'bg-orange-900/50 text-orange-300' :
                    forecast.risk_level === 'medium' ? 'bg-yellow-900/50 text-yellow-300' :
                    'bg-green-900/50 text-green-300'
                  }`}>
                    {forecast.risk_level} risk
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          <p className="text-slate-300 mb-4">{forecast.description}</p>

          {forecast.reasoning && (
            <div className="bg-slate-900/50 rounded-lg p-3 mb-4">
              <h5 className="text-cyan-400 font-medium text-sm mb-1">Analysis:</h5>
              <p className="text-slate-300 text-sm">{forecast.reasoning}</p>
            </div>
          )}

          {forecast.mitigation_actions && forecast.mitigation_actions.length > 0 && (
            <div className="bg-green-900/20 rounded-lg p-3 mb-4">
              <h5 className="text-green-400 font-medium text-sm mb-2">Recommended Actions:</h5>
              <ul className="text-slate-300 text-sm space-y-1">
                {forecast.mitigation_actions.map((action, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-green-400">•</span>
                    {action}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="flex gap-2">
            <Button
              size="sm"
              onClick={() => navigate(createPageUrl('Assistant') + `?prompt=Tell me more about this forecast: ${forecast.title}. How should I prepare?`)}
              className="bg-cyan-600 hover:bg-cyan-700 text-white"
            >
              Get AI Guidance
            </Button>
            {forecast.financial_impact && (
              <Button
                size="sm"
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Impact: ${forecast.financial_impact.toLocaleString()}
              </Button>
            )}
          </div>
        </div>
      ))}

      <div className="mt-8 text-center">
        <Button
          onClick={() => navigate(createPageUrl('Assistant') + '?prompt=Help me create a comprehensive financial action plan based on all these forecasts')}
          className="bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-400 hover:to-blue-500"
        >
          Create Master Action Plan
        </Button>
      </div>
    </div>
  );
}
