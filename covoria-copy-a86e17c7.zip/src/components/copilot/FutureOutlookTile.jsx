import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { TrendingUp, RefreshCw } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function FutureOutlookTile({ forecasts, isLoading }) {
    return (
        <Card className="h-full bg-slate-800/50 border border-slate-700 hover:border-slate-600 transition-colors">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">Future Outlook</CardTitle>
                <TrendingUp className="w-4 h-4 text-slate-500" />
            </CardHeader>
            <CardContent>
                {isLoading ? (
                    <>
                        <Skeleton className="h-12 w-1/2 mb-2 bg-slate-700" />
                        <Skeleton className="h-4 w-3/4 bg-slate-700" />
                    </>
                ) : (
                    <>
                        <div className="text-2xl font-bold text-white">{forecasts.length}</div>
                        <p className="text-xs text-slate-400">
                            {forecasts.length > 0 ? 'Potential risks & opportunities identified' : 'No new forecasts.'}
                        </p>
                    </>
                )}
            </CardContent>
        </Card>
    );
}