import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Shield, 
  Clock, 
  AlertTriangle, 
  FileText, 
  RefreshCw,
  TrendingUp,
  Users,
  Calendar
} from 'lucide-react';

const RiskItem = ({ label, count, action, disabled = false, onClick, icon: Icon }) => {
  return (
    <div className="bg-slate-800 p-4 rounded-lg flex justify-between items-center">
      <div className="flex items-center gap-3">
        <Icon className="w-6 h-6 text-slate-400" />
        <div>
          <p className="text-md font-semibold text-white">{label}</p>
          <p className="text-2xl font-bold text-white">{count}</p>
        </div>
      </div>
      <Button
        disabled={disabled}
        onClick={onClick}
        className={`px-4 py-2 rounded text-sm font-medium ${
          disabled
            ? "bg-slate-600 text-slate-400 cursor-not-allowed"
            : "bg-teal-600 hover:bg-teal-700 text-white"
        }`}
      >
        {action}
      </Button>
    </div>
  );
};

export default function RiskScannerContent({ insights, policies }) {
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(true);

  const handleRunScan = () => {
    setIsScanning(true);
    setScanComplete(false);
    
    // Simulate scan process
    setTimeout(() => {
      setIsScanning(false);
      setScanComplete(true);
    }, 3000);
  };

  const riskCategories = [
    {
      label: "Outdated Policies",
      count: policies?.filter(p => {
        const endDate = new Date(p.end_date);
        const now = new Date();
        const monthsUntilExpiry = (endDate - now) / (1000 * 60 * 60 * 24 * 30);
        return monthsUntilExpiry < 6;
      }).length || 1,
      action: "Update Policy",
      icon: Clock,
      onClick: () => alert('Navigate to policy update')
    },
    {
      label: "Missing Beneficiaries", 
      count: 1,
      action: "Add Beneficiary",
      icon: Users,
      onClick: () => alert('Navigate to beneficiary setup')
    },
    {
      label: "Expiring Soon",
      count: 0,
      action: "No Action",
      icon: Calendar,
      disabled: true
    },
    {
      label: "Needs Review",
      count: insights?.filter(i => !i.is_resolved && i.priority === 'high').length || 2,
      action: "Explain",
      icon: AlertTriangle,
      onClick: () => alert('Show risk explanations')
    }
  ];

  if (isScanning) {
    return (
      <div className="p-6 text-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="w-16 h-16 mx-auto mb-4"
        >
          <RefreshCw className="w-16 h-16 text-teal-400" />
        </motion.div>
        <h3 className="text-xl font-bold text-white mb-2">Scanning Your Coverage</h3>
        <p className="text-slate-400">Analyzing policies for potential risks and opportunities...</p>
      </div>
    );
  }

  if (!scanComplete) {
    return (
      <div className="p-6 text-center">
        <h3 className="text-xl font-bold text-white mb-4">Risk Scanner</h3>
        <p className="text-slate-400 mb-6">
          Ready to scan your policies for potential risks and optimization opportunities.
        </p>
        <Button 
          onClick={handleRunScan}
          className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-3"
        >
          <Shield className="w-5 h-5 mr-2" />
          Run Risk Scan
        </Button>
      </div>
    );
  }

  return (
    <div className="p-6 bg-slate-900 text-white rounded-lg max-w-4xl">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-2 text-white">Scan Complete</h2>
        <p className="text-sm text-slate-400">
          We found several items that may need your attention.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {riskCategories.map((risk, index) => (
          <motion.div
            key={risk.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <RiskItem
              label={risk.label}
              count={risk.count}
              action={risk.action}
              disabled={risk.disabled}
              onClick={risk.onClick}
              icon={risk.icon}
            />
          </motion.div>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4">
        <Button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium">
          <FileText className="w-5 h-5 mr-2" />
          View Full Risk Report
        </Button>
        <Button 
          variant="ghost"
          onClick={handleRunScan}
          className="text-slate-400 hover:text-white underline"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Run New Scan
        </Button>
      </div>

      <p className="text-xs text-slate-500 text-center">
        Your AI Advisor continuously monitors your policies and suggests actions to reduce risk.
      </p>
    </div>
  );
}