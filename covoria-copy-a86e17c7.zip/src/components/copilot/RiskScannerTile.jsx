import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Search } from 'lucide-react';
import RiskScannerContent from './RiskScannerContent';
import { Skeleton } from '@/components/ui/skeleton';

export default function RiskScannerTile({ count, isLoading, insights = [] }) {
  const riskInsights = Array.isArray(insights) ? insights.filter(i => !i.is_resolved && i.category === 'risk_alert') : [];
  const riskCount = count !== undefined ? count : riskInsights.length;

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card className="h-full bg-slate-800/50 border border-slate-700 hover:border-slate-600 transition-colors flex flex-col justify-between cursor-pointer">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-300">Risk Scanner</CardTitle>
            <Search className="w-4 h-4 text-slate-500" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
                <>
                    <Skeleton className="h-8 w-12 mb-2 bg-slate-700" />
                    <Skeleton className="h-4 w-24 bg-slate-700" />
                </>
            ) : (
                <>
                    <div className="text-2xl font-bold text-white">{riskCount}</div>
                    <p className="text-xs text-slate-400">
                        {riskCount > 0 ? `${riskCount} potential risk${riskCount > 1 ? 's' : ''} detected` : 'No major risks found'}
                    </p>
                </>
            )}
          </CardContent>
        </Card>
      </DialogTrigger>
      <DialogContent className="max-w-4xl h-[90vh] bg-slate-900/95 backdrop-blur-xl border border-slate-700/50 text-white shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-3">
             <Search className="w-8 h-8 text-slate-400" />
             Risk Scanner
          </DialogTitle>
        </DialogHeader>
        <div className="overflow-y-auto custom-scrollbar pr-4 -mr-4">
          <RiskScannerContent insights={riskInsights} />
        </div>
      </DialogContent>
    </Dialog>
  );
}