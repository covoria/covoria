import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Brain, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';

export default function AssistantFloatingPanel() {
  const navigate = useNavigate();

  const handleNavigate = () => {
    navigate(createPageUrl('Assistant'));
  };

  return (
    <Card className="bg-slate-800 border-slate-700 rounded-2xl shadow-lg overflow-hidden">
      <CardContent className="p-8 flex flex-col items-center justify-center gap-4 text-center">
        <motion.div
          animate={{
            rotate: [0, -8, 8, -8, 8, 0],
            scale: [1, 1.05, 1, 1.05, 1],
          }}
          transition={{
            duration: 5,
            ease: "easeInOut",
            repeat: Infinity,
            repeatDelay: 3
          }}
          className="p-4 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full shadow-lg"
        >
          <Brain className="w-8 h-8 text-white" />
        </motion.div>
        <div className="mt-2">
          <h3 className="text-xl font-bold text-white">HyperSync AI Assistant</h3>
          <p className="text-md text-slate-300 mt-1 max-w-md">
            Get personalized advice and analyze your coverage in seconds.
          </p>
        </div>
        <Button onClick={handleNavigate} className="covoria-gradient text-white mt-3 px-8 py-3 text-base font-semibold rounded-lg">
          Ask Now <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
      </CardContent>
    </Card>
  );
}