import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Target, Upload, FileText, CheckCircle, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CoverageScore({ policies, insights, onTriggerCheckup }) {
  const [scoreData, setScoreData] = useState({
    score: 0,
    maxScore: 100,
    factors: [],
    nextActions: []
  });
  const navigate = useNavigate();

  useEffect(() => {
    calculateCoverageScore();
  }, [policies, insights]);

  const calculateCoverageScore = () => {
    let score = 0;
    const factors = [];
    const nextActions = [];

    // Factor 1: Essential Coverage Types (40 points max)
    const essentialTypes = ['health', 'life', 'auto'];
    const activePolicies = policies.filter(p => p.is_active);
    const coveredEssentials = essentialTypes.filter(type => 
      activePolicies.some(p => p.insurance_type === type)
    );
    
    const essentialScore = (coveredEssentials.length / essentialTypes.length) * 40;
    score += essentialScore;
    
    factors.push({
      name: 'Essential Coverage',
      score: essentialScore,
      maxScore: 40,
      description: `${coveredEssentials.length}/${essentialTypes.length} core policies`,
      status: essentialScore >= 30 ? 'good' : 'needs-improvement'
    });

    if (essentialScore < 40) {
      const missing = essentialTypes.filter(type => 
        !activePolicies.some(p => p.insurance_type === type)
      );
      nextActions.push({
        action: `Add ${missing[0]} insurance`,
        icon: Plus,
        points: '+13 points',
        onClick: () => navigate(createPageUrl('Insurance'))
      });
    }

    // Factor 2: Documentation Quality (25 points max)
    const documentsUploaded = policies.filter(p => p.policy_number).length;
    const documentScore = Math.min((documentsUploaded / Math.max(activePolicies.length, 1)) * 25, 25);
    score += documentScore;
    
    factors.push({
      name: 'Documentation',
      score: documentScore,
      maxScore: 25,
      description: `${documentsUploaded} policies with full details`,
      status: documentScore >= 20 ? 'good' : 'needs-improvement'
    });

    if (documentScore < 25) {
      nextActions.push({
        action: 'Upload missing documents',
        icon: Upload,
        points: '+' + Math.round(25 - documentScore) + ' points',
        onClick: () => navigate(createPageUrl('Settings'))
      });
    }

    // Factor 3: AI Insights Engagement (20 points max)
    const totalInsights = insights.length;
    const resolvedInsights = insights.filter(i => i.is_resolved).length;
    const insightScore = totalInsights > 0 ? (resolvedInsights / totalInsights) * 20 : 0;
    score += insightScore;
    
    factors.push({
      name: 'Insight Actions',
      score: insightScore,
      maxScore: 20,
      description: `${resolvedInsights}/${totalInsights} recommendations addressed`,
      status: insightScore >= 15 ? 'good' : 'needs-improvement'
    });

    if (insightScore < 20 && totalInsights > 0) {
      nextActions.push({
        action: 'Review AI recommendations',
        icon: Target,
        points: '+' + Math.round(20 - insightScore) + ' points',
        onClick: () => navigate(createPageUrl('Insights'))
      });
    }

    // Factor 4: Profile Completeness (15 points max)
    const hasCheckupCompleted = localStorage.getItem('covoria_checkup_completed');
    const profileScore = hasCheckupCompleted ? 15 : 0;
    score += profileScore;
    
    factors.push({
      name: 'Profile Setup',
      score: profileScore,
      maxScore: 15,
      description: hasCheckupCompleted ? 'Coverage checkup completed' : 'Complete your profile',
      status: profileScore >= 15 ? 'good' : 'needs-improvement'
    });

    if (!hasCheckupCompleted) {
      nextActions.push({
        action: 'Complete coverage checkup',
        icon: FileText,
        points: '+15 points',
        onClick: onTriggerCheckup
      });
    }

    setScoreData({
      score: Math.round(score),
      maxScore: 100,
      factors,
      nextActions: nextActions.slice(0, 3) // Show top 3 actions
    });
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreLabel = (score) => {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Good';
    if (score >= 40) return 'Fair';
    return 'Needs Work';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <Card className="covoria-card">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-100 rounded-xl">
                <Target className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Coverage Score</h3>
                <p className="text-sm text-gray-600">Your financial protection strength</p>
              </div>
            </div>
            <div className="text-right">
              <div className={`text-3xl font-bold ${getScoreColor(scoreData.score)}`}>
                {scoreData.score}%
              </div>
              <div className="text-sm text-gray-600">
                {getScoreLabel(scoreData.score)}
              </div>
            </div>
          </div>

          <div className="mb-6">
            <Progress 
              value={scoreData.score} 
              className="h-3 mb-2"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>0%</span>
              <span>100%</span>
            </div>
          </div>

          <div className="space-y-3 mb-6">
            <h4 className="text-sm font-medium text-gray-700">Score Breakdown:</h4>
            {scoreData.factors.map((factor, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {factor.status === 'good' ? (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border-2 border-gray-300" />
                  )}
                  <div>
                    <span className="text-sm font-medium text-gray-900">{factor.name}</span>
                    <p className="text-xs text-gray-500">{factor.description}</p>
                  </div>
                </div>
                <span className="text-sm font-semibold text-gray-700">
                  {Math.round(factor.score)}/{factor.maxScore}
                </span>
              </div>
            ))}
          </div>

          {scoreData.nextActions.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-700">Quick Wins:</h4>
              {scoreData.nextActions.map((action, index) => (
                <Button
                  key={index}
                  variant="outline"
                  onClick={action.onClick}
                  className="w-full justify-between text-left h-auto p-3"
                >
                  <div className="flex items-center gap-2">
                    <action.icon className="w-4 h-4" />
                    <span className="text-sm">{action.action}</span>
                  </div>
                  <span className="text-xs text-green-600 font-medium">
                    {action.points}
                  </span>
                </Button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}