import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Heart, Shield, Users } from 'lucide-react';
import { motion } from 'framer-motion';

export default function CovoriaCaresMessage() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.8 }}
      className="mb-8"
    >
      <Card className="bg-gradient-to-r from-purple-900/60 to-blue-900/60 border border-purple-700/50 backdrop-blur-sm">
        <CardContent className="p-6 text-center bg-slate-900/40 rounded-lg">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Heart className="w-5 h-5 text-pink-300" />
            <Shield className="w-5 h-5 text-cyan-300" />
            <Users className="w-5 h-5 text-green-300" />
          </div>
          
          <h3 className="text-xl font-bold text-white mb-3 drop-shadow-lg">
            We're here for you
          </h3>
          
          <p className="text-gray-100 text-base leading-relaxed max-w-2xl mx-auto font-medium drop-shadow-md">
            Covoria reads your policies and gives you solutions, not just information. 
            You don't need to know anything about insurance - just upload your documents 
            and we'll take care of the rest.
          </p>
          
        </CardContent>
      </Card>
    </motion.div>
  );
}