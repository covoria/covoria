import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

const messages = [
  "We're quietly tracking your financial progress — and it's impressive.",
  "You're building something great. We're here to help optimize it.",
  "Small tweaks now lead to big peace of mind later.",
  "Your financial protection is stronger than most people your age.",
];

export default function EncouragementBlock() {
  const [currentMessage, setCurrentMessage] = useState(messages[0]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMessage(prev => {
        const currentIndex = messages.indexOf(prev);
        const nextIndex = (currentIndex + 1) % messages.length;
        return messages[nextIndex];
      });
    }, 8000); // Change message every 8 seconds
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1 }}
      className="mt-6 bg-purple-900/80 text-purple-200 text-sm px-4 py-3 rounded-xl shadow-inner flex items-center gap-3"
    >
      <Heart className="w-5 h-5 text-purple-300 flex-shrink-0" />
      <p className="font-medium">{currentMessage}</p>
    </motion.div>
  );
}