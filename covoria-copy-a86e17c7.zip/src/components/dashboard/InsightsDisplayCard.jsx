
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Lightbulb, 
  TrendingUp, 
  Shield, 
  AlertTriangle, 
  Eye,
  Sparkles,
  ChevronRight,
  RefreshCw
} from 'lucide-react';
import { Insight } from '@/api/entities';
import { User } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const getPriorityIcon = (priority) => {
  switch (priority) {
    case 'critical': 
    case 'high': 
      return '🔴';
    case 'medium': 
      return '🟠';
    case 'low': 
      return '🟢';
    default: 
      return '💡';
  }
};

const getPriorityColor = (priority) => {
  switch (priority) {
    case 'critical':
    case 'high': 
      return 'border-red-500/30 bg-red-900/20 text-red-200';
    case 'medium': 
      return 'border-orange-500/30 bg-orange-900/20 text-orange-200';
    case 'low': 
      return 'border-green-500/30 bg-green-900/20 text-green-200';
    default: 
      return 'border-slate-500/30 bg-slate-900/20 text-slate-200';
  }
};

const getCategoryEmoji = (category) => {
  switch (category) {
    case 'coverage_gap': return '🔍';
    case 'cost_saving': return '💰';
    case 'optimization': return '⚡';
    case 'risk_alert': return '⚠️';
    case 'overlap': return '🔄';
    default: return '💡';
  }
};

export default function InsightsDisplayCard() {
  const [insights, setInsights] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [newInsightsCount, setNewInsightsCount] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    loadInsights();
  }, []);

  useEffect(() => {
    // Check for new insights flag from localStorage
    const hasNewInsights = localStorage.getItem('covoria_new_insights');
    if (hasNewInsights === 'true') {
      setNewInsightsCount(insights.length);
      // Clear the flag after showing
      setTimeout(() => {
        localStorage.removeItem('covoria_new_insights');
        setNewInsightsCount(0);
      }, 10000); // Show for 10 seconds
    }
  }, [insights]);

  const loadInsights = async () => {
    try {
      const user = await User.me();
      if (!user) return;

      const allInsights = await Insight.filter({ 
        created_by: user.email, 
        is_resolved: false 
      });

      // Sort by priority: critical/high -> medium -> low
      const sortedInsights = allInsights.sort((a, b) => {
        const priorityOrder = { 'critical': 0, 'high': 0, 'medium': 1, 'low': 2 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      });

      setInsights(sortedInsights);
    } catch (error) {
      console.error('Failed to load insights:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <Card className="covoria-card">
          <CardContent className="p-6 text-center">
            <div className="flex items-center justify-center gap-2">
              <RefreshCw className="w-5 h-5 animate-spin text-cyan-400" />
              <span className="text-slate-300">Loading insights...</span>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  if (insights.length === 0) {
    return null; // Don't show anything if no insights
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-8"
    >
      <Card className="insight-card relative overflow-hidden bg-slate-800 border border-slate-700 shadow-lg">
        {newInsightsCount > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute top-2 right-2 z-10"
          >
            <Badge className="bg-green-500 text-white animate-pulse font-bold">
              NEW
            </Badge>
          </motion.div>
        )}

        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <motion.div
                  animate={{
                    rotate: [0, 5, -5, 0],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="bg-yellow-600 p-3 rounded-full"
                >
                  <Lightbulb className="w-6 h-6 text-white" />
                </motion.div>
              </div>
              <div>
                <CardTitle className="insight-card-title text-white text-lg font-bold flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-yellow-400" />
                  We found {insights.length} insights for you
                </CardTitle>
                <p className="text-slate-200 text-sm mt-1 font-medium">
                  We're here for you. Covoria reads your policies and gives you solutions, not just information.
                </p>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Priority Summary */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            {['high', 'medium', 'low'].map(priority => {
              const count = insights.filter(i => 
                priority === 'high' ? (i.priority === 'high' || i.priority === 'critical') : i.priority === priority
              ).length;
              return (
                <div key={priority} className={`insight-card text-center p-3 rounded-lg border bg-slate-700 border-slate-600`}>
                  <div className="text-lg font-bold text-white">
                    {getPriorityIcon(priority)} {count}
                  </div>
                  <div className="text-xs capitalize text-slate-200 font-medium">{priority === 'high' ? 'Urgent' : priority}</div>
                </div>
              );
            })}
          </div>

          {/* Top 3 Insights Preview */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-yellow-400" />
              Top Priority Items
            </h4>
            
            <AnimatePresence>
              {insights.slice(0, 3).map((insight, index) => (
                <motion.div
                  key={insight.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="insight-card p-3 bg-slate-700 rounded-xl border-l-4 border-cyan-500 hover:bg-slate-600 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 flex-1">
                      <span className="text-lg flex-shrink-0 mt-0.5">
                        {getCategoryEmoji(insight.category)}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="insight-card-title font-bold text-white text-sm mb-1 line-clamp-1">
                          {insight.title}
                        </div>
                        <p className="text-xs text-slate-200 line-clamp-2 leading-relaxed">
                          {insight.description}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">
                        {getPriorityIcon(insight.priority)}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-slate-600">
            <Button 
              onClick={() => navigate(createPageUrl('Insights'))}
              className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold"
            >
              <Eye className="w-4 h-4 mr-2" />
              View All Insights
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
            
            {insights.some(i => i.priority === 'high' || i.priority === 'critical') && (
              <Button 
                onClick={() => navigate(createPageUrl('Assistant'))}
                variant="outline"
                className="border-red-500 text-red-300 hover:bg-red-900/30 font-semibold"
              >
                <AlertTriangle className="w-4 h-4 mr-2" />
                Get Help Now
              </Button>
            )}
          </div>

          {/* Supportive Message */}
          <div className="text-center pt-2">
            <p className="text-xs text-slate-300 italic font-medium">
              💝 Don't worry - we'll walk you through everything step by step.
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
