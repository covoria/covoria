import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, X, AlertCircle, Info, CheckCircle, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { UserActivity } from '@/api/entities';
import { Insight } from '@/api/entities';

export default function NotificationCenter() {
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    try {
      // Get recent insights and activities
      const [recentInsights, recentActivities] = await Promise.all([
        Insight.filter({ is_resolved: false }, '-date_identified', 3).catch(() => []),
        UserActivity.list('-activity_date', 5).catch(() => [])
      ]);

      const notificationsList = [];

      // Add unresolved insights as notifications
      recentInsights.forEach((insight, index) => {
        if (insight.priority === 'high' || insight.priority === 'critical') {
          notificationsList.push({
            id: `insight-${insight.id}`,
            type: insight.priority === 'critical' ? 'critical' : 'warning',
            title: insight.title,
            message: insight.description.substring(0, 80) + '...',
            timestamp: new Date(insight.date_identified),
            isRead: false,
            action: 'View Insights'
          });
        }
      });

      // Add recent high-impact activities
      recentActivities
        .filter(activity => activity.impact_score > 70)
        .slice(0, 2)
        .forEach(activity => {
          notificationsList.push({
            id: `activity-${activity.id}`,
            type: 'info',
            title: activity.title,
            message: activity.description.substring(0, 80) + '...',
            timestamp: new Date(activity.activity_date),
            isRead: false,
            action: null
          });
        });

      // Sort by timestamp
      notificationsList.sort((a, b) => b.timestamp - a.timestamp);
      
      setNotifications(notificationsList.slice(0, 5));
      setUnreadCount(notificationsList.filter(n => !n.isRead).length);
    } catch (error) {
      console.error('Failed to load notifications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'critical': return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'warning': return <AlertCircle className="w-4 h-4 text-yellow-500" />;
      case 'success': return <CheckCircle className="w-4 h-4 text-green-500" />;
      default: return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  const getNotificationBg = (type) => {
    switch (type) {
      case 'critical': return 'bg-red-50 border-red-200';
      case 'warning': return 'bg-yellow-50 border-yellow-200';
      case 'success': return 'bg-green-50 border-green-200';
      default: return 'bg-blue-50 border-blue-200';
    }
  };

  const dismissNotification = (notificationId) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const markAsRead = (notificationId) => {
    setNotifications(prev => prev.map(n => 
      n.id === notificationId ? { ...n, isRead: true } : n
    ));
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-cyan-600" />
              Notifications
            </div>
            {unreadCount > 0 && (
              <Badge className="bg-red-500 text-white text-xs">
                {unreadCount}
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              <div className="animate-pulse bg-gray-200 h-12 rounded"></div>
              <div className="animate-pulse bg-gray-200 h-12 rounded"></div>
            </div>
          ) : notifications.length > 0 ? (
            <div className="space-y-3 max-h-80 overflow-y-auto">
              <AnimatePresence>
                {notifications.map((notification) => (
                  <motion.div
                    key={notification.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className={`p-3 border rounded-lg ${getNotificationBg(notification.type)} ${!notification.isRead ? 'border-l-4' : ''}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2 flex-1">
                        {getNotificationIcon(notification.type)}
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-sm text-gray-900 truncate">
                            {notification.title}
                          </h4>
                          <p className="text-xs text-gray-600 mt-1">
                            {notification.message}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <Clock className="w-3 h-3 text-gray-400" />
                            <span className="text-xs text-gray-400">
                              {notification.timestamp.toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0"
                        onClick={() => dismissNotification(notification.id)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          ) : (
            <div className="text-center py-6">
              <Bell className="mx-auto h-8 w-8 text-gray-400" />
              <p className="text-sm text-gray-500 mt-2">No new notifications</p>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}