import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Shield, Calendar, DollarSign } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '@/api/entities';
import { InsurancePolicy } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';

export default function RiskMagnetScanner() {
  const [riskAlerts, setRiskAlerts] = useState([]);
  const [isScanning, setIsScanning] = useState(false);
  const [lastScan, setLastScan] = useState(null);

  useEffect(() => {
    // Auto-scan on component mount
    performRiskScan();
  }, []);

  const performRiskScan = async () => {
    setIsScanning(true);
    try {
      const user = await User.me();
      const policies = await InsurancePolicy.filter({ created_by: user.email });
      
      const risks = await scanForRisks(user, policies);
      setRiskAlerts(risks);
      setLastScan(new Date());
    } catch (error) {
      console.error('Risk scan failed:', error);
    } finally {
      setIsScanning(false);
    }
  };

  const scanForRisks = async (user, policies) => {
    const detectedRisks = [];

    // 1. Life Insurance vs Mortgage Risk
    const lifePolicy = policies.find(p => p.insurance_type === 'life' && p.is_active);
    const hasSignificantDebt = user.income_bracket && ['100k-200k', '200k+'].includes(user.income_bracket);
    
    if (!lifePolicy && hasSignificantDebt && user.dependents > 0) {
      detectedRisks.push({
        id: 'life_insurance_gap',
        type: 'coverage_gap',
        severity: 'high',
        title: 'Life Insurance Gap Detected',
        description: 'Your income level and dependents suggest you may need life insurance protection.',
        reasoning: 'Based on your income bracket and family situation',
        action: 'Consider term life insurance coverage',
        icon: Shield
      });
    }

    // 2. Policy Expiration Risk
    const expiringPolicies = policies.filter(p => {
      if (!p.end_date || !p.is_active) return false;
      const endDate = new Date(p.end_date);
      const sixMonthsFromNow = new Date();
      sixMonthsFromNow.setMonth(sixMonthsFromNow.getMonth() + 6);
      return endDate <= sixMonthsFromNow;
    });

    if (expiringPolicies.length > 0) {
      detectedRisks.push({
        id: 'expiring_policies',
        type: 'expiration_risk',
        severity: 'medium',
        title: `${expiringPolicies.length} ${expiringPolicies.length === 1 ? 'Policy' : 'Policies'} Expiring Soon`,
        description: 'Some of your policies will expire within 6 months.',
        reasoning: 'Policy end dates are approaching',
        action: 'Review and renew before expiration',
        icon: Calendar,
        policies: expiringPolicies.map(p => p.policy_name)
      });
    }

    // 3. High Premium to Income Ratio
    const totalMonthlyPremiums = policies
      .filter(p => p.is_active)
      .reduce((sum, p) => {
        const monthly = p.premium_frequency === 'annually' ? (p.premium_amount || 0) / 12 : (p.premium_amount || 0);
        return sum + monthly;
      }, 0);

    const estimatedMonthlyIncome = getEstimatedMonthlyIncome(user.income_bracket);
    const premiumRatio = totalMonthlyPremiums / estimatedMonthlyIncome;

    if (premiumRatio > 0.15) { // More than 15% of income
      detectedRisks.push({
        id: 'high_premium_ratio',
        type: 'financial_strain',
        severity: 'medium',
        title: 'High Insurance Costs',
        description: `Your insurance premiums represent ${Math.round(premiumRatio * 100)}% of your estimated income.`,
        reasoning: 'Premium-to-income ratio analysis',
        action: 'Review coverage amounts and shop for better rates',
        icon: DollarSign
      });
    }

    // 4. Age-Based Risk Assessment
    if (user.age >= 50) {
      const hasDisability = policies.some(p => p.insurance_type === 'disability' && p.is_active);
      if (!hasDisability && user.employment_status === 'employed') {
        detectedRisks.push({
          id: 'disability_risk',
          type: 'age_related',
          severity: 'medium',
          title: 'Disability Insurance Consideration',
          description: 'As you approach peak earning years, disability insurance becomes increasingly important.',
          reasoning: 'Age and employment status analysis',
          action: 'Explore disability insurance options',
          icon: Shield
        });
      }
    }

    return detectedRisks;
  };

  const getEstimatedMonthlyIncome = (bracket) => {
    const incomeMap = {
      '0-50k': 3000,
      '50k-100k': 6250,
      '100k-200k': 12500,
      '200k+': 20000
    };
    return incomeMap[bracket] || 5000;
  };

  const getRiskColor = (severity) => {
    switch (severity) {
      case 'high': return 'border-red-500/50 bg-red-900/20';
      case 'medium': return 'border-yellow-500/50 bg-yellow-900/20';
      case 'low': return 'border-blue-500/50 bg-blue-900/20';
      default: return 'border-gray-500/50 bg-gray-900/20';
    }
  };

  const getRiskBadgeColor = (severity) => {
    switch (severity) {
      case 'high': return 'bg-red-800/30 text-red-200';
      case 'medium': return 'bg-yellow-800/30 text-yellow-200';
      case 'low': return 'bg-blue-800/30 text-blue-200';
      default: return 'bg-gray-800/30 text-gray-200';
    }
  };

  return (
    <Card className="covoria-card">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-white flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-orange-400" />
          Risk Scanner
        </CardTitle>
        <Button
          onClick={performRiskScan}
          disabled={isScanning}
          variant="outline"
          size="sm"
          className="text-orange-400 border-orange-400/50 hover:bg-orange-400/10"
        >
          {isScanning ? 'Scanning...' : 'Scan Now'}
        </Button>
      </CardHeader>
      <CardContent>
        {isScanning ? (
          <div className="text-center py-6">
            <div className="animate-spin w-8 h-8 border-2 border-orange-400 border-t-transparent rounded-full mx-auto mb-3"></div>
            <p className="text-slate-400 text-sm">Analyzing your risk exposure...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {lastScan && (
              <p className="text-xs text-slate-500 text-center">
                Last scan: {lastScan.toLocaleTimeString()}
              </p>
            )}

            <AnimatePresence>
              {riskAlerts.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-6"
                >
                  <Shield className="w-12 h-12 text-green-400 mx-auto mb-3" />
                  <p className="text-green-300 font-medium">No immediate risks detected</p>
                  <p className="text-slate-400 text-sm">Your coverage looks well-balanced</p>
                </motion.div>
              ) : (
                riskAlerts.map((risk, index) => (
                  <motion.div
                    key={risk.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`p-4 border rounded-lg ${getRiskColor(risk.severity)}`}
                  >
                    <div className="flex items-start gap-3">
                      <risk.icon className="w-5 h-5 text-orange-400 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold text-white text-sm">
                            {risk.title}
                          </h4>
                          <Badge className={`text-xs ${getRiskBadgeColor(risk.severity)}`}>
                            {risk.severity}
                          </Badge>
                        </div>
                        <p className="text-slate-300 text-sm mb-2">
                          {risk.description}
                        </p>
                        <p className="text-slate-400 text-xs mb-3">
                          <strong>Why:</strong> {risk.reasoning}
                        </p>
                        <div className="bg-slate-700/50 p-2 rounded text-xs text-slate-200">
                          <strong>Suggested Action:</strong> {risk.action}
                        </div>
                        {risk.policies && (
                          <div className="mt-2">
                            <p className="text-xs text-slate-400">
                              Affected policies: {risk.policies.join(', ')}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        )}
      </CardContent>
    </Card>
  );
}