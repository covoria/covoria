
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PiggyBank, TrendingUp, Eye, FileText, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { SavingsAccount } from '@/api/entities';
import { User } from '@/api/entities';

export default function SavingsSummary() {
  const [accounts, setAccounts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    loadAccounts();
    
    // Auto-refresh when data changes
    const handleDataUpdate = () => {
      console.log('🚀 [SavingsSummary] Data update detected, refreshing accounts');
      loadAccounts();
    };
    
    window.addEventListener('storage', handleDataUpdate);
    window.addEventListener('focus', handleDataUpdate);
    
    return () => {
      window.removeEventListener('storage', handleDataUpdate);
      window.removeEventListener('focus', handleDataUpdate);
    };
  }, []);

  const loadAccounts = async () => {
    setIsLoading(true);
    setError(null);
    try {
      console.log('🚀 [SavingsSummary] Loading accounts...');
      const user = await User.me();
      if (!user) {
        throw new Error('User not authenticated');
      }
      
      const userAccounts = await SavingsAccount.filter({ created_by: user.email });
      console.log('🚀 [SavingsSummary] Loaded accounts:', userAccounts.length);
      setAccounts(Array.isArray(userAccounts) ? userAccounts : []);
    } catch (error) {
      console.error('🚀 [SavingsSummary] Failed to load accounts:', error);
      setError(error.message || 'Failed to load savings data');
      setAccounts([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    loadAccounts();
  };

  if (isLoading) {
    return (
      <Card className="covoria-card">
        <CardHeader>
          <Skeleton className="h-6 w-3/4" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <PiggyBank className="w-6 h-6 text-purple-400" />
            Savings & Retirement
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <AlertTriangle className="w-8 h-8 text-red-400 mx-auto mb-2" />
            <p className="text-red-400 text-sm mb-2">Unable to load savings data</p>
            <p className="text-slate-400 text-xs mb-4">
              {error.includes('Network') ? 'Please check your internet connection' : error}
            </p>
            <Button 
              onClick={handleRetry} 
              variant="outline" 
              className="bg-slate-700 text-slate-200 hover:bg-slate-600 border-slate-600"
              size="sm"
            >
              Try Again {retryCount > 0 && `(${retryCount})`}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const activeAccounts = accounts.filter(a => a.is_active !== false);
  const totalBalance = activeAccounts.reduce((sum, a) => sum + (a.current_balance || 0), 0);
  const recentAccounts = accounts.slice(0, 2);

  const formatCurrency = (amount) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`;
    return `$${amount}`;
  };

  const getAccountTypeIcon = (type) => {
    switch (type) {
      case '401k':
      case '403b':
      case 'pension':
        return '🏢';
      case 'ira':
      case 'roth_ira':
        return '👤';
      case 'hsa':
        return '⚕️';
      default:
        return '💰';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
    >
      <Card className="covoria-card overflow-hidden">
        <CardHeader>
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-3 min-w-0 flex-1">
                <PiggyBank className="w-6 h-6 text-purple-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                    <CardTitle className="text-white text-lg sm:text-xl">Savings & Retirement</CardTitle>
                    <p className="text-slate-400 text-xs sm:text-sm">Your progress towards financial goals</p>
                </div>
            </div>
            <Button 
                variant="outline" 
                onClick={() => navigate(createPageUrl('Savings'))}
                className="bg-slate-700 text-slate-200 hover:bg-slate-600 border-slate-600 rounded-lg"
              >
              <Eye className="w-4 h-4 mr-2" />
              View All
            </Button>
          </div>
        </CardHeader>
        {accounts.length > 0 ? (
          <CardContent className="space-y-6">
            <div className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 rounded-xl border border-purple-200 dark:border-purple-700/30">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <p className="text-xs font-medium text-purple-700 dark:text-purple-300">Total Balance</p>
              </div>
              <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">{formatCurrency(totalBalance)}</p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-slate-200 mb-4">Recent Accounts</h3>
              <div className="space-y-3">
                {recentAccounts.map((account, index) => (
                   <motion.div
                      key={account.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.2 }}
                    >
                      <div className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
                        <div className="text-xl flex-shrink-0">{getAccountTypeIcon(account.account_type)}</div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-slate-100 text-sm truncate">{account.account_name}</h4>
                          <p className="text-xs text-slate-400 capitalize truncate">{account.account_type}</p>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p className="font-mono text-sm text-green-300">{formatCurrency(account.current_balance || 0)}</p>
                          <p className="text-xs text-slate-400 truncate max-w-20">{account.provider}</p>
                        </div>
                      </div>
                    </motion.div>
                ))}
              </div>
            </div>
          </CardContent>
        ) : (
          <CardContent>
            <div className="text-center py-10 px-4">
              <FileText className="w-12 h-12 mx-auto text-slate-500 mb-4" />
              <p className="text-lg text-slate-300 font-semibold">No Savings Accounts Found</p>
              <p className="text-sm text-slate-400 mt-2">
                Add your savings or retirement accounts to start tracking your goals.
              </p>
              <div className="flex justify-center gap-3 mt-6">
                <Button 
                    onClick={() => navigate(createPageUrl('Savings'))}
                    className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
                >
                  Go to Savings
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    </motion.div>
  );
}
