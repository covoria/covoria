
import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User, 
  X,
  Minimize2,
  Maximize2,
  Lightbulb,
  FileText,
  Brain
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Import the new functions
import { dailyTipGenerator } from '@/api/functions';
import { lifeEventSimulator } from '@/api/functions';
import { enhancedAssistant } from '@/api/functions';

export default function SmartChatbox({ userData, isVisible, onToggle, currentTab = 'Dashboard' }) {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [sessionId] = useState(() => `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`);
  const [showDailyTip, setShowDailyTip] = useState(false);
  const [dailyTip, setDailyTip] = useState(null);
  const [showLifeEventSim, setShowLifeEventSim] = useState(false);
  const [humanAdvisorMode, setHumanAdvisorMode] = useState(false);
  
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (messageContent) => {
    const messageToSend = messageContent || inputMessage;
    if (!messageToSend.trim() || isLoading) return;

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: messageToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      // Use enhanced assistant with full reasoning
      const { data } = await enhancedAssistant({
        message: messageToSend,
        session_id: sessionId,
        current_tab: currentTab
      });

      const assistantMessage = {
        id: Date.now() + 1,
        type: 'assistant',
        content: data.response,
        timestamp: new Date(),
        metadata: {
          follow_up_questions: data.follow_up_questions || [],
          suggested_actions: data.suggested_actions || [],
          contextual_follow_ups: data.contextual_follow_ups || [],
          proactive_suggestions: data.proactive_suggestions || [],
          personalization_level: data.personalization_level || 0,
          risk_alert_mode: data.risk_alert_mode || false,
          is_returning_user: data.is_returning_user || false,
          confidence_score: data.confidence_score || 0
        }
      };

      setMessages(prev => [...prev, assistantMessage]);

    } catch (error) {
      console.error('Enhanced Assistant Error:', error);
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        type: 'assistant',
        content: 'I apologize, but I\'m having trouble connecting right now. Please try again in a moment.',
        timestamp: new Date(),
        isError: true
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const getDailyTip = async () => {
    setShowDailyTip(true);
    try {
      const { data } = await dailyTipGenerator({ tip_type: 'daily' });
      setDailyTip(data.tip);
    } catch (error) {
      console.error('Daily Tip Error:', error);
      setDailyTip({
        category: 'general_tip',
        title: 'Daily Tip Unavailable',
        content: 'Sorry, I couldn\'t generate your daily tip right now. Try again later!',
        action_item: 'Check back tomorrow for your personalized tip.'
      });
    }
  };

  const simulateLifeEvent = async (eventType) => {
    try {
      const { data } = await lifeEventSimulator({ 
        event_type: eventType 
      });
      
      const simulationMessage = {
        id: Date.now(),
        type: 'assistant',
        content: `**Life Event Simulation: ${data.event_type.replace(/_/g, ' ').toUpperCase()}**\n\n` +
                 `**Severity Score:** ${data.severity_score}/100\n\n` +
                 `**Immediate Impact:**\n${data.immediate_impact.coverage_response}\n` +
                 `Estimated out-of-pocket: $${data.immediate_impact.out_of_pocket_estimate?.toLocaleString() || 'Unknown'}\n\n` +
                 `**Key Recommendations:**\n${data.recommendations.slice(0, 3).map(rec => `• ${rec.action}`).join('\n')}\n\n` +
                 `**Recovery Timeline:** ${data.recovery_timeline}`,
        timestamp: new Date(),
        metadata: {
          simulation_data: data,
          type: 'life_event_simulation'
        }
      };
      
      setMessages(prev => [...prev, simulationMessage]);
      setShowLifeEventSim(false);
    } catch (error) {
      console.error('Life Event Simulation Error:', error);
    }
  };

  const handleFollowUpClick = (question) => {
    setInputMessage(question);
  };

  const renderMessage = (message) => {
    const isUser = message.type === 'user';
    const metadata = message.metadata || {};
    
    return (
      <motion.div
        key={message.id}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
      >
        {!isUser && (
          <div className="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center">
            <Bot className="w-4 h-4 text-white" />
          </div>
        )}
        
        <div className={`max-w-[80%] ${isUser ? 'order-first' : ''}`}>
          <div className={`rounded-2xl px-4 py-3 ${
            isUser 
              ? 'bg-gradient-to-br from-cyan-500 to-blue-600 text-white ml-auto' 
              : message.isError 
                ? 'bg-red-50 text-red-800 border border-red-200'
                : 'bg-gray-50 text-gray-800'
          }`}>
            <div className="text-sm leading-relaxed whitespace-pre-wrap">
              {message.content}
            </div>
            
            {/* Enhanced metadata display */}
            {!isUser && metadata.personalization_level > 0 && (
              <div className="mt-2 pt-2 border-t border-gray-200">
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Brain className="w-3 h-3" />
                  <span>Personalization: {metadata.personalization_level}%</span>
                  {metadata.risk_alert_mode && (
                    <Badge className="bg-red-100 text-red-800 text-xs">Risk Alert</Badge>
                  )}
                  {metadata.is_returning_user && (
                    <Badge className="bg-blue-100 text-blue-800 text-xs">Returning User</Badge>
                  )}
                </div>
              </div>
            )}
            
            {/* Follow-up questions */}
            {!isUser && metadata.follow_up_questions && metadata.follow_up_questions.length > 0 && (
              <div className="mt-3 space-y-1">
                <p className="text-xs text-gray-500 mb-2">Follow-up questions:</p>
                {metadata.follow_up_questions.map((question, index) => (
                  <button
                    key={index}
                    onClick={() => handleFollowUpClick(question)}
                    className="block w-full text-left text-xs bg-white bg-opacity-50 hover:bg-opacity-75 rounded px-2 py-1 transition-colors"
                  >
                    {question}
                  </button>
                ))}
              </div>
            )}
            
            {/* Proactive suggestions */}
            {!isUser && metadata.proactive_suggestions && metadata.proactive_suggestions.length > 0 && (
              <div className="mt-3 space-y-1">
                <p className="text-xs text-gray-500 mb-2">💡 Suggestions:</p>
                {metadata.proactive_suggestions.map((suggestion, index) => (
                  <div key={index} className="text-xs bg-yellow-50 rounded px-2 py-1">
                    <strong>{suggestion.title}:</strong> {suggestion.message}
                  </div>
                ))}
              </div>
            )}
            
            <div className="text-xs text-gray-400 mt-2">
              {message.timestamp.toLocaleTimeString()}
              {!isUser && metadata.confidence_score && (
                <span className="ml-2">• Confidence: {Math.round(metadata.confidence_score * 100)}%</span>
              )}
            </div>
          </div>
        </div>
        
        {isUser && (
          <div className="flex-shrink-0 w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
            <User className="w-4 h-4 text-gray-600" />
          </div>
        )}
      </motion.div>
    );
  };

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8, y: 20 }}
        className={`fixed bottom-4 right-4 z-50 bg-white rounded-2xl shadow-2xl border border-gray-200 ${
          isMinimized ? 'w-80 h-16' : 'w-96 h-[600px]'
        } flex flex-col transition-all duration-300`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">AI Assistant</h3>
              <p className="text-xs text-gray-500">Enhanced with reasoning</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Human Advisor Mode Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setHumanAdvisorMode(!humanAdvisorMode)}
              className={`w-8 h-8 ${humanAdvisorMode ? 'bg-blue-100 text-blue-600' : ''}`}
              title="Human advisor tone"
            >
              <User className="w-4 h-4" />
            </Button>
            
            {/* Daily Tip Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={getDailyTip}
              className="w-8 h-8"
              title="Get daily tip"
            >
              <Lightbulb className="w-4 h-4" />
            </Button>
            
            {/* Life Event Simulator */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowLifeEventSim(!showLifeEventSim)}
              className="w-8 h-8"
              title="Simulate life event"
            >
              <FileText className="w-4 h-4" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMinimized(!isMinimized)}
              className="w-8 h-8"
            >
              {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggle}
              className="w-8 h-8"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {/* Life Event Simulation Menu */}
            {showLifeEventSim && (
              <div className="p-4 border-b border-gray-100 bg-gray-50">
                <p className="text-sm font-medium text-gray-700 mb-2">Simulate Life Event:</p>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => simulateLifeEvent('job_loss')}
                    className="text-xs"
                  >
                    Job Loss
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => simulateLifeEvent('medical_emergency')}
                    className="text-xs"
                  >
                    Medical Emergency
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => simulateLifeEvent('accident')}
                    className="text-xs"
                  >
                    Accident
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => simulateLifeEvent('disability')}
                    className="text-xs"
                  >
                    Disability
                  </Button>
                </div>
              </div>
            )}

            {/* Daily Tip Display */}
            {showDailyTip && dailyTip && (
              <div className="p-4 border-b border-gray-100 bg-gradient-to-r from-yellow-50 to-orange-50">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 mb-1">💡 {dailyTip.title}</h4>
                    <p className="text-sm text-gray-600 mb-2">{dailyTip.content}</p>
                    <p className="text-xs text-blue-600 font-medium">Action: {dailyTip.action_item}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowDailyTip(false)}
                    className="w-6 h-6"
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            )}

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.length === 0 && (
                <div className="text-center text-gray-500 text-sm space-y-4">
                  <p>👋 Hi! I'm your enhanced AI assistant.</p>
                  <p>I now remember our conversations and provide personalized advice based on your profile and coverage.</p>
                  <div className="grid grid-cols-1 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => sendMessage("Analyze my current coverage")}
                      className="text-xs"
                    >
                      Analyze my coverage
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => sendMessage("What are my biggest risks?")}
                      className="text-xs"
                    >
                      Identify my risks
                    </Button>
                  </div>
                </div>
              )}
              
              {messages.map(renderMessage)}
              
              {isLoading && (
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center">
                    <Bot className="w-4 h-4 text-white animate-pulse" />
                  </div>
                  <div className="bg-gray-50 rounded-2xl px-4 py-3">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t border-gray-200">
              <div className="flex gap-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  placeholder="Ask about your coverage, risks, or get personalized advice..."
                  className="flex-1"
                  disabled={isLoading}
                />
                <Button
                  onClick={() => sendMessage()}
                  disabled={isLoading || !inputMessage.trim()}
                  className="bg-gradient-to-br from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              
              {humanAdvisorMode && (
                <p className="text-xs text-blue-600 mt-1">🤝 Human advisor tone enabled</p>
              )}
            </div>
          </>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
