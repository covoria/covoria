import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, AlertCircle, Activity, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SystemStatusIndicator() {
  const [systemStatus, setSystemStatus] = useState({
    overall: 'operational',
    services: {
      ai_processing: 'operational',
      document_analysis: 'operational',
      data_sync: 'operational',
      insights_engine: 'operational'
    },
    uptime: '99.9%',
    last_updated: new Date().toISOString()
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'operational': return 'text-green-600 bg-green-100';
      case 'degraded': return 'text-yellow-600 bg-yellow-100';
      case 'down': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'operational': return <CheckCircle className="w-3 h-3" />;
      case 'degraded': return <AlertCircle className="w-3 h-3" />;
      case 'down': return <AlertCircle className="w-3 h-3" />;
      default: return <Activity className="w-3 h-3" />;
    }
  };

  return (
    <Card className="covoria-card">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Zap className="w-4 h-4 text-green-600" />
          System Status
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-gray-700">Overall Status</span>
          <Badge className={`text-xs ${getStatusColor(systemStatus.overall)}`}>
            {getStatusIcon(systemStatus.overall)}
            <span className="ml-1 capitalize">{systemStatus.overall}</span>
          </Badge>
        </div>

        <div className="space-y-2">
          {Object.entries(systemStatus.services).map(([service, status]) => (
            <div key={service} className="flex items-center justify-between text-xs">
              <span className="text-gray-600 capitalize">
                {service.replace('_', ' ')}
              </span>
              <Badge variant="outline" className={`text-xs ${getStatusColor(status)}`}>
                {getStatusIcon(status)}
              </Badge>
            </div>
          ))}
        </div>

        <div className="pt-2 border-t border-gray-100">
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-500">Uptime</span>
            <span className="font-medium text-green-600">{systemStatus.uptime}</span>
          </div>
          <div className="flex items-center justify-between text-xs mt-1">
            <span className="text-gray-500">Last Updated</span>
            <span className="text-gray-600">
              {new Date(systemStatus.last_updated).toLocaleTimeString()}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}