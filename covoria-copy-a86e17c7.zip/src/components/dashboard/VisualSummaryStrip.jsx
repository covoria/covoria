
import React from 'react';
import { Shield, Heart, Car, Home, User, PiggyBank, CheckCircle, AlertTriangle, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

const CategoryIcon = ({ category, status, onClick }) => {
  const icons = {
    health: Heart,
    life: User,
    auto: Car,
    home: Home,
    disability: Shield,
    retirement: PiggyBank
  };

  const statusConfig = {
    active: { color: 'bg-green-500', icon: CheckCircle, label: '✓' },
    missing: { color: 'bg-gray-300', icon: null, label: '–' },
    expiring: { color: 'bg-orange-500', icon: AlertTriangle, label: '!' }
  };

  const Icon = icons[category] || Shield;
  const config = statusConfig[status] || statusConfig.missing;

  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      onClick={onClick}
      className={`relative flex flex-col items-center p-3 rounded-xl cursor-pointer transition-all duration-200 ${
        status === 'active' ? 'bg-green-50 border-2 border-green-200' :
        status === 'expiring' ? 'bg-orange-50 border-2 border-orange-200' :
        'bg-gray-50 border-2 border-gray-200 hover:bg-gray-100'
      }`}
    >
      <div className={`p-2 rounded-lg ${config.color} mb-2`}>
        <Icon className="w-4 h-4 text-white" />
      </div>
      <span className="text-xs font-medium text-gray-700 capitalize">{category}</span>
      <span className="text-lg font-bold text-gray-800">{config.label}</span>
      {status === 'expiring' && (
        <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
      )}
    </motion.div>
  );
};

export default function VisualSummaryStrip({ policies, onCategoryClick }) {
  // Analyze coverage status
  const getCoverageStatus = () => {
    const categories = ['health', 'life', 'auto', 'home', 'disability', 'retirement'];
    const activePolicies = policies.filter(p => p.is_active);
    
    return categories.map(category => {
      const categoryPolicies = activePolicies.filter(p => p.insurance_type === category);
      
      if (categoryPolicies.length === 0) {
        return { category, status: 'missing', count: 0 };
      }
      
      // Check for expiring policies (within 90 days)
      const expiringPolicies = categoryPolicies.filter(p => {
        if (!p.end_date) return false;
        const endDate = new Date(p.end_date);
        const now = new Date();
        const daysUntilExpiry = (endDate - now) / (1000 * 60 * 60 * 24);
        return daysUntilExpiry <= 90 && daysUntilExpiry > 0;
      });
      
      return {
        category,
        status: expiringPolicies.length > 0 ? 'expiring' : 'active',
        count: categoryPolicies.length
      };
    });
  };

  const coverageData = getCoverageStatus();
  const activeCoverage = coverageData.filter(c => c.status === 'active').length;
  const missingCoverage = coverageData.filter(c => c.status === 'missing').length;
  const expiringCoverage = coverageData.filter(c => c.status === 'expiring').length;

  // Display names for categories (shortened to fit better)
  const categoryDisplayNames = {
    health: 'Health',
    life: 'Life',
    auto: 'Auto',
    home: 'Home',
    disability: 'Disabil.',
    retirement: 'Retire.'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-8"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Coverage Overview</h3>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-gray-600">{activeCoverage} Active</span>
          </div>
          {expiringCoverage > 0 && (
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
              <span className="text-gray-600">{expiringCoverage} Expiring</span>
            </div>
          )}
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-gray-300 rounded-full"></div>
            <span className="text-gray-600">{missingCoverage} Missing</span>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2 md:gap-3">
        {coverageData.map((item, index) => (
          <motion.div
            key={item.category}
            whileHover={{ scale: 1.05 }}
            onClick={() => onCategoryClick(item.category, item.status)}
            className={`relative flex flex-col items-center p-2 md:p-3 rounded-xl cursor-pointer transition-all duration-200 min-h-[100px] ${
              item.status === 'active' ? 'bg-green-50 border-2 border-green-200' :
              item.status === 'expiring' ? 'bg-orange-50 border-2 border-orange-200' :
              'bg-gray-50 border-2 border-gray-200 hover:bg-gray-100'
            }`}
          >
            <div className={`p-2 rounded-lg mb-2 ${
              item.status === 'active' ? 'bg-green-500' :
              item.status === 'expiring' ? 'bg-orange-500' :
              'bg-gray-300'
            }`}>
              {item.category === 'health' && <Heart className="w-4 h-4 text-white" />}
              {item.category === 'life' && <User className="w-4 h-4 text-white" />}
              {item.category === 'auto' && <Car className="w-4 h-4 text-white" />}
              {item.category === 'home' && <Home className="w-4 h-4 text-white" />}
              {item.category === 'disability' && <Shield className="w-4 h-4 text-white" />}
              {item.category === 'retirement' && <PiggyBank className="w-4 h-4 text-white" />}
            </div>
            <span className="text-xs font-medium text-gray-700 text-center leading-tight px-1 mb-1">
              {categoryDisplayNames[item.category]}
            </span>
            <span className="text-lg font-bold text-gray-800">
              {item.status === 'active' ? '✓' : item.status === 'expiring' ? '!' : '–'}
            </span>
            {item.status === 'expiring' && (
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
            )}
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
