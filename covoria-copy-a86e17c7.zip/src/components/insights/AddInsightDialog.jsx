import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';

export default function AddInsightDialog({ open, onOpenChange, onSubmit }) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'optimization',
    priority: 'medium',
    potential_savings: '',
    action_required: '',
    date_identified: new Date(),
    is_resolved: false
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const submitData = {
      ...formData,
      potential_savings: parseFloat(formData.potential_savings) || 0,
      date_identified: format(formData.date_identified, 'yyyy-MM-dd')
    };
    onSubmit(submitData);
    setFormData({
      title: '',
      description: '',
      category: 'optimization',
      priority: 'medium',
      potential_savings: '',
      action_required: '',
      date_identified: new Date(),
      is_resolved: false
    });
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Add New Insight</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2 space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                placeholder="Brief insight title"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select 
                value={formData.category} 
                onValueChange={(value) => handleInputChange('category', value)}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="coverage_gap">Coverage Gap</SelectItem>
                  <SelectItem value="risk_alert">Risk Alert</SelectItem>
                  <SelectItem value="optimization">Optimization</SelectItem>
                  <SelectItem value="cost_saving">Cost Saving</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">Priority</Label>
              <Select 
                value={formData.priority} 
                onValueChange={(value) => handleInputChange('priority', value)}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="potential_savings">Potential Savings ($)</Label>
              <Input
                id="potential_savings"
                type="number"
                value={formData.potential_savings}
                onChange={(e) => handleInputChange('potential_savings', e.target.value)}
                placeholder="e.g., 1200"
              />
            </div>

            <div className="space-y-2">
              <Label>Date Identified</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(formData.date_identified, 'PPP')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.date_identified}
                    onSelect={(date) => handleInputChange('date_identified', date)}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Detailed description of the insight..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="action_required">Recommended Action</Label>
            <Textarea
              id="action_required"
              value={formData.action_required}
              onChange={(e) => handleInputChange('action_required', e.target.value)}
              placeholder="What action should the user take?"
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="covoria-gradient text-white">
              Add Insight
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}