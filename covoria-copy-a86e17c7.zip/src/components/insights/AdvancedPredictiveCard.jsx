import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Brain, ChevronDown, ChevronUp, AlertCircle, TrendingDown, Briefcase } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdvancedPredictiveCard() {
  const [takeaway, setTakeaway] = useState('');
  const [predictions, setPredictions] = useState([]);
  const [openPrediction, setOpenPrediction] = useState(null);

  useEffect(() => {
    // Mock data, to be replaced with actual API call
    setTakeaway("The user's current financial situation is relatively stable with insurance coverage in place and a savings account. However, there are predictions of potential job loss and unexpected medical expenses that could impact their financial stability. It is advisable for the user to strengthen their emergency fund and explore options for diversifying income.");
    setPredictions([
      { id: 1, name: 'Job Loss', chance: '25%', icon: Briefcase, color: 'text-orange-400', bgColor: 'bg-orange-900/20' },
      { id: 2, name: 'Major Medical Expense', chance: '15%', icon: AlertCircle, color: 'text-red-400', bgColor: 'bg-red-900/20' },
      { id: 3, name: 'Economic Downturn Impact', chance: '35%', icon: TrendingDown, color: 'text-yellow-400', bgColor: 'bg-yellow-900/20' },
    ]);
  }, []);

  const togglePrediction = (id) => {
    setOpenPrediction(openPrediction === id ? null : id);
  };

  return (
    <Card className="covoria-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-gray-900 dark:text-[var(--covoria-text-primary)]">
          <Brain className="w-5 h-5 text-purple-500 dark:text-purple-400" />
          Advanced AI Future Outlook
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-gray-50 dark:bg-slate-800/50 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
          <h4 className="font-semibold text-gray-900 dark:text-[var(--covoria-text-primary)] mb-2">Key Takeaway</h4>
          <p className="text-sm text-gray-700 dark:text-[var(--covoria-text-secondary)] leading-relaxed">
            {takeaway}
          </p>
        </div>
        <div className="space-y-2">
          {predictions.map((prediction) => {
            const Icon = prediction.icon;
            return (
              <div key={prediction.id} className="border border-gray-200 dark:border-slate-700 rounded-lg overflow-hidden">
                <div 
                  className="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-800/30"
                  onClick={() => togglePrediction(prediction.id)}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${prediction.bgColor}`}>
                      <Icon className={`w-4 h-4 ${prediction.color}`} />
                    </div>
                    <span className="font-medium text-gray-900 dark:text-[var(--covoria-text-primary)]">{prediction.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="dark:bg-slate-700 dark:text-slate-300">{prediction.chance} chance</Badge>
                    {openPrediction === prediction.id ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </div>
                </div>
                <AnimatePresence>
                  {openPrediction === prediction.id && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="px-4 pb-4 bg-gray-50 dark:bg-slate-800/20"
                    >
                      <p className="text-sm text-gray-600 dark:text-[var(--covoria-text-secondary)] pt-3 border-t border-gray-200 dark:border-slate-700">
                        Detailed analysis and mitigation strategies would be displayed here.
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}