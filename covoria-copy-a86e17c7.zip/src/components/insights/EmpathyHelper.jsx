
import React from 'react';

// Enhanced empathy tone for Sprint 18 - more human and reassuring
export function applyEmpathyTone(prompt, type = 'help') {
  const tones = {
    gap: "I understand this might feel overwhelming - many people discover these gaps, and that's completely normal. Let me help you find gentle, practical solutions that won't strain your budget. You're being proactive by looking into this.",
    cost: "Great news! You're smart to explore ways to optimize your spending. Many of our users find meaningful savings opportunities - let's see what makes sense for your specific situation. You're already ahead of most people by being mindful about costs.",
    help: "I'm here to make insurance simple and less stressful for you. Think of me as your calm, knowledgeable friend who happens to know a lot about financial protection. There are no silly questions - we'll figure this out together.",
    general: "You're taking a smart step by getting organized with your coverage. I'm here to help you feel confident and secure about your financial protection - no pressure, just clear guidance tailored to you."
  };
  
  const selectedTone = tones[type] || tones.general;
  return `${selectedTone}\n\n${prompt}`;
}

// Emotional mapping with enhanced reassurance messages for Sprint 18
export const insightEmotionMap = {
  'coverage_gap': {
    tone: "gentle",
    message: "Don't worry - this gap is common and fixable. Let's explore your options together.",
    encouragement: "You're being smart by identifying this early.",
    color: "#FCD34D",
    icon: "🛡️"
  },
  'optimization': {
    tone: "friendly", 
    message: "Excellent! There's room to improve your strategy and save money 🌱",
    encouragement: "Small tweaks now can lead to big benefits later.",
    color: "#A7F3D0",
    icon: "💡"
  },
  'cost_saving': {
    tone: "encouraging",
    message: "Great catch! You might be able to reduce spending here 💰",
    encouragement: "You're ahead of most people by reviewing your costs.",
    color: "#FBBF24",
    icon: "💸"
  },
  'risk_alert': {
    tone: "calm",
    message: "Let's address this together - it's manageable and you're not alone.",
    encouragement: "Identifying risks early shows you're being responsible.",
    color: "#FCA5A5",
    icon: "🚨"
  },
  'overlap': {
    tone: "helpful",
    message: "No worries - overlapping coverage is more common than you think.",
    encouragement: "Streamlining this could free up money for other goals.",
    color: "#A78BFA",
    icon: "🔄"
  }
};

// Enhanced encouragement messages with more warmth
export const encouragementMessages = [
  "You're doing better than 78% of people your age with financial planning ⭐",
  "Your proactive approach to insurance puts you ahead of the curve ✨", 
  "Small improvements today = major peace of mind tomorrow 🛡️",
  "Your financial protection is stronger than most people realize 💪",
  "Every step you take builds a more secure future 🚀",
  "You're building something great - we're here to help you optimize it 🌟"
];

// Helper to get emotional context with enhanced messaging
export const getEmotionalContext = (insight) => {
  return insightEmotionMap[insight.category] || {
    tone: "supportive",
    message: "This insight can help strengthen your financial foundation.",
    encouragement: "Every improvement counts toward your security.",
    color: "#E5E7EB",
    icon: "💭"
  };
};
