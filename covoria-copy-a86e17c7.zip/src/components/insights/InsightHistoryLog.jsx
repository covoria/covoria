import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  History, 
  Search, 
  Filter, 
  Calendar,
  CheckCircle,
  AlertTriangle,
  Clock,
  Undo
} from 'lucide-react';

export default function InsightHistoryLog({ insights, onUpdateInsight }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  const filteredInsights = insights.filter(insight => {
    const matchesSearch = insight.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         insight.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || 
                         (filterStatus === 'resolved' && insight.is_resolved) ||
                         (filterStatus === 'unresolved' && !insight.is_resolved);
    return matchesSearch && matchesFilter;
  });

  const handleReopen = async (insightId) => {
    await onUpdateInsight(insightId, { is_resolved: false });
  };

  const getStatusIcon = (insight) => {
    if (insight.is_resolved) {
      return <CheckCircle className="w-4 h-4 text-green-500" />;
    } else if (insight.priority === 'critical') {
      return <AlertTriangle className="w-4 h-4 text-red-500" />;
    } else {
      return <Clock className="w-4 h-4 text-yellow-500" />;
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="covoria-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <History className="w-6 h-6 text-blue-600" />
          Insight History
        </CardTitle>
        <div className="flex flex-col sm:flex-row gap-4 mt-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search insight history..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg bg-white"
          >
            <option value="all">All Insights</option>
            <option value="resolved">Resolved</option>
            <option value="unresolved">Unresolved</option>
          </select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 max-h-96 overflow-y-auto">
          <AnimatePresence>
            {filteredInsights.map((insight, index) => (
              <motion.div
                key={insight.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ delay: index * 0.05 }}
                className={`p-4 rounded-lg border transition-all ${
                  insight.is_resolved ? 'bg-gray-50 border-gray-200' : 'bg-white border-gray-300'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      {getStatusIcon(insight)}
                      <h4 className={`font-medium ${insight.is_resolved ? 'text-gray-600' : 'text-gray-900'}`}>
                        {insight.title}
                      </h4>
                    </div>
                    
                    <p className={`text-sm mb-3 ${insight.is_resolved ? 'text-gray-500' : 'text-gray-700'}`}>
                      {insight.description}
                    </p>
                    
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className={getPriorityColor(insight.priority)}>
                        {insight.priority}
                      </Badge>
                      <Badge variant="outline">
                        {insight.category.replace('_', ' ')}
                      </Badge>
                      {insight.potential_savings && (
                        <Badge className="bg-green-100 text-green-800">
                          ${insight.potential_savings.toLocaleString()} savings
                        </Badge>
                      )}
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Calendar className="w-3 h-3" />
                        {new Date(insight.date_identified).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  
                  <div className="ml-4 flex flex-col gap-2">
                    {insight.is_resolved ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleReopen(insight.id)}
                        className="gap-1"
                      >
                        <Undo className="w-3 h-3" />
                        Reopen
                      </Button>
                    ) : (
                      <Badge className="bg-orange-100 text-orange-800">
                        Active
                      </Badge>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
        
        {filteredInsights.length === 0 && (
          <div className="text-center py-8">
            <History className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">
              {searchTerm ? 'No insights match your search' : 'No insights in history yet'}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}