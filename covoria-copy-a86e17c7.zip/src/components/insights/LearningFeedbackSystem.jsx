import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, 
  ThumbsUp, 
  ThumbsDown, 
  MessageSquare, 
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Star,
  Target
} from 'lucide-react';
import { AIFeedback, LLMUsageLog, UserActivity } from '@/api/entities';
import { User } from '@/api/entities';

// Advanced Learning System that collects and processes user feedback
export default function LearningFeedbackSystem({ 
  insightId, 
  aiResponse, 
  context = {},
  onFeedbackSubmitted 
}) {
  const [feedbackState, setFeedbackState] = useState('initial'); // initial, collecting, submitted
  const [selectedRating, setSelectedRating] = useState(null);
  const [feedbackText, setFeedbackText] = useState('');
  const [selectedIssues, setSelectedIssues] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [learningStats, setLearningStats] = useState({});
  const [showDetailedFeedback, setShowDetailedFeedback] = useState(false);

  useEffect(() => {
    loadLearningStats();
  }, []);

  const loadLearningStats = async () => {
    try {
      const user = await User.me();
      const [feedback, usage, activity] = await Promise.allSettled([
        AIFeedback.filter({ user_email: user.email }),
        LLMUsageLog.filter({ user_email: user.email }),
        UserActivity.filter({ user_email: user.email, activity_type: 'ai_interaction' })
      ]);

      const stats = {
        total_feedback: feedback.status === 'fulfilled' ? feedback.value.length : 0,
        positive_feedback: feedback.status === 'fulfilled' ? 
          feedback.value.filter(f => f.rating >= 4).length : 0,
        ai_interactions: activity.status === 'fulfilled' ? activity.value.length : 0,
        improvement_rate: 0.85 // Simulated learning improvement rate
      };

      setLearningStats(stats);
    } catch (error) {
      console.error('Failed to load learning stats:', error);
    }
  };

  const handleQuickFeedback = async (type) => {
    setIsSubmitting(true);
    
    try {
      const user = await User.me();
      const rating = type === 'positive' ? 5 : 2;
      
      await submitFeedback({
        feedback_type: type === 'positive' ? 'thumbs_up' : 'thumbs_down',
        rating: rating,
        user_email: user.email,
        quick_feedback: true
      });
      
      setFeedbackState('submitted');
      setSelectedRating(rating);
      
    } catch (error) {
      console.error('Failed to submit quick feedback:', error);
    }
    
    setIsSubmitting(false);
  };

  const handleDetailedFeedback = () => {
    setShowDetailedFeedback(true);
    setFeedbackState('collecting');
  };

  const submitDetailedFeedback = async () => {
    if (!selectedRating) return;
    
    setIsSubmitting(true);
    
    try {
      const user = await User.me();
      
      await submitFeedback({
        feedback_type: selectedRating >= 4 ? 'thumbs_up' : 'thumbs_down',
        rating: selectedRating,
        feedback_text: feedbackText,
        response_quality_issues: selectedIssues,
        user_email: user.email,
        detailed_feedback: true
      });
      
      setFeedbackState('submitted');
      
    } catch (error) {
      console.error('Failed to submit detailed feedback:', error);
    }
    
    setIsSubmitting(false);
  };

  const submitFeedback = async (feedbackData) => {
    const user = await User.me();
    
    // Store AI feedback for learning
    await AIFeedback.create({
      conversation_id: insightId,
      user_email: user.email,
      ...feedbackData,
      ai_response_text: aiResponse?.content || '',
      context_data: JSON.stringify(context),
      response_time_ms: Date.now() - (aiResponse?.timestamp || Date.now()),
      requires_review: feedbackData.rating <= 2 || selectedIssues.length > 0
    });

    // Log for usage analytics
    await LLMUsageLog.create({
      function_name: 'learning_feedback_system',
      prompt_type: 'feedback_collection',
      user_email: user.email,
      success: true,
      context_tab: 'insights'
    });

    // Track user activity for learning
    await UserActivity.create({
      activity_type: 'ai_interaction',
      title: 'Provided AI Feedback',
      description: `User rated AI response ${feedbackData.rating}/5 stars`,
      user_email: user.email,
      related_entity_id: insightId,
      related_entity_type: 'insight',
      activity_date: new Date().toISOString(),
      metadata: {
        rating: feedbackData.rating,
        feedback_type: feedbackData.feedback_type,
        issues: selectedIssues
      }
    });

    if (onFeedbackSubmitted) {
      onFeedbackSubmitted(feedbackData);
    }

    // Reload stats
    setTimeout(loadLearningStats, 1000);
  };

  const qualityIssues = [
    { id: 'inaccurate', label: 'Information seems inaccurate', icon: '❌' },
    { id: 'unhelpful', label: 'Response not helpful', icon: '😕' },
    { id: 'too_long', label: 'Too lengthy/verbose', icon: '📖' },
    { id: 'too_short', label: 'Too brief/lacking detail', icon: '📝' },
    { id: 'irrelevant', label: 'Not relevant to my question', icon: '🎯' },
    { id: 'inappropriate_tone', label: 'Inappropriate tone', icon: '🗣️' }
  ];

  const handleIssueToggle = (issueId) => {
    setSelectedIssues(prev => 
      prev.includes(issueId) 
        ? prev.filter(id => id !== issueId)
        : [...prev, issueId]
    );
  };

  if (feedbackState === 'submitted') {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="p-4 bg-green-50 border border-green-200 rounded-lg"
      >
        <div className="flex items-center gap-2 mb-2">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <span className="font-medium text-green-900">Thank you for your feedback!</span>
        </div>
        <p className="text-sm text-green-700 mb-3">
          Your input helps me learn and provide better recommendations for you and others.
        </p>
        
        {/* Learning Impact */}
        <div className="bg-white rounded-lg p-3 border border-green-200">
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-gray-900">Learning Impact</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-1">
              <TrendingUp className="w-3 h-3 text-blue-500" />
              <span className="text-gray-600">Feedback given: {learningStats.total_feedback + 1}</span>
            </div>
            <div className="flex items-center gap-1">
              <Target className="w-3 h-3 text-purple-500" />
              <span className="text-gray-600">AI Improvement: {(learningStats.improvement_rate * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Quick Feedback */}
      {feedbackState === 'initial' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200"
        >
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-gray-700">Was this helpful?</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleQuickFeedback('positive')}
              disabled={isSubmitting}
              className="text-green-600 hover:text-green-700 hover:bg-green-50"
            >
              <ThumbsUp className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleQuickFeedback('negative')}
              disabled={isSubmitting}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <ThumbsDown className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDetailedFeedback}
              className="text-gray-600 hover:text-gray-700"
            >
              <MessageSquare className="w-4 h-4" />
              <span className="ml-1 text-xs">More feedback</span>
            </Button>
          </div>
        </motion.div>
      )}

      {/* Detailed Feedback Form */}
      <AnimatePresence>
        {showDetailedFeedback && feedbackState === 'collecting' && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-purple-200">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm">
                  <Brain className="w-4 h-4 text-purple-600" />
                  Help me learn and improve
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                
                {/* Star Rating */}
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-2">
                    Overall rating
                  </label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((rating) => (
                      <button
                        key={rating}
                        onClick={() => setSelectedRating(rating)}
                        className={`p-1 transition-colors ${
                          selectedRating >= rating 
                            ? 'text-yellow-500' 
                            : 'text-gray-300 hover:text-yellow-400'
                        }`}
                      >
                        <Star className="w-5 h-5 fill-current" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quality Issues (for low ratings) */}
                {selectedRating && selectedRating <= 3 && (
                  <div>
                    <label className="text-sm font-medium text-gray-700 block mb-2">
                      What could be improved? (select all that apply)
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {qualityIssues.map((issue) => (
                        <button
                          key={issue.id}
                          onClick={() => handleIssueToggle(issue.id)}
                          className={`p-2 text-left text-xs rounded-lg border transition-colors ${
                            selectedIssues.includes(issue.id)
                              ? 'bg-red-50 border-red-200 text-red-800'
                              : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                          }`}
                        >
                          <span className="mr-1">{issue.icon}</span>
                          {issue.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Additional Comments */}
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-2">
                    Additional feedback (optional)
                  </label>
                  <Textarea
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                    placeholder="What would make this response more helpful?"
                    className="text-sm"
                    rows={3}
                  />
                </div>

                {/* Learning Stats */}
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="w-4 h-4 text-blue-600" />
                    <span className="text-sm font-medium text-blue-900">Learning Progress</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="text-center">
                      <div className="font-semibold text-blue-800">{learningStats.total_feedback}</div>
                      <div className="text-blue-600">Feedback received</div>
                    </div>
                    <div className="text-center">
                      <div className="font-semibold text-blue-800">{learningStats.positive_feedback}</div>
                      <div className="text-blue-600">Positive ratings</div>
                    </div>
                    <div className="text-center">
                      <div className="font-semibold text-blue-800">{(learningStats.improvement_rate * 100).toFixed(0)}%</div>
                      <div className="text-blue-600">Accuracy rate</div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    onClick={submitDetailedFeedback}
                    disabled={!selectedRating || isSubmitting}
                    className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                    size="sm"
                  >
                    {isSubmitting ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    ) : (
                      <CheckCircle className="w-4 h-4 mr-2" />
                    )}
                    Submit Feedback
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowDetailedFeedback(false);
                      setFeedbackState('initial');
                    }}
                    size="sm"
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}