import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { InsurancePolicy } from '@/api/entities';
import DatePicker from '../ui/date-picker';

export default function AddPolicyDialog({ onClose, onUpdate, policy }) {
  const [formData, setFormData] = useState({
    policy_name: '',
    insurance_type: 'health',
    provider: '',
    policy_number: '',
    coverage_amount: '',
    premium_amount: '',
    premium_frequency: 'monthly',
    start_date: null,
    end_date: null,
    deductible: '',
    is_active: true,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (policy) {
      setFormData({
        ...policy,
        coverage_amount: policy.coverage_amount || '',
        premium_amount: policy.premium_amount || '',
        deductible: policy.deductible || '',
        start_date: policy.start_date ? new Date(policy.start_date) : null,
        end_date: policy.end_date ? new Date(policy.end_date) : null,
      });
    }
  }, [policy]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleDateChange = (name, date) => {
    setFormData((prev) => ({ ...prev, [name]: date }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const dataToSave = {
        ...formData,
        coverage_amount: parseFloat(formData.coverage_amount) || 0,
        premium_amount: parseFloat(formData.premium_amount) || 0,
        deductible: parseFloat(formData.deductible) || 0,
        start_date: formData.start_date ? formData.start_date.toISOString().split('T')[0] : null,
        end_date: formData.end_date ? formData.end_date.toISOString().split('T')[0] : null,
      };

      if (policy) {
        await InsurancePolicy.update(policy.id, dataToSave);
      } else {
        await InsurancePolicy.create(dataToSave);
      }
      onUpdate();
    } catch (error) {
      console.error('Failed to save policy:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
        <DialogHeader>
          <DialogTitle>{policy ? 'Edit Policy' : 'Add New Policy'}</DialogTitle>
          <DialogDescription>
            {policy ? 'Update the details for this insurance policy.' : 'Enter the details for the new insurance policy.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="policy_name" className="text-right">Name</Label>
            <Input id="policy_name" name="policy_name" value={formData.policy_name} onChange={handleChange} className="col-span-3 bg-[var(--covoria-bg-main)] border-[var(--covoria-border-color)]" />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="insurance_type" className="text-right">Type</Label>
            <Select name="insurance_type" onValueChange={(value) => handleSelectChange('insurance_type', value)} value={formData.insurance_type}>
              <SelectTrigger className="col-span-3 bg-[var(--covoria-bg-main)] border-[var(--covoria-border-color)]">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent className="bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
                <SelectItem value="health">Health</SelectItem>
                <SelectItem value="life">Life</SelectItem>
                <SelectItem value="auto">Auto</SelectItem>
                <SelectItem value="home">Home</SelectItem>
                <SelectItem value="disability">Disability</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="provider" className="text-right">Provider</Label>
            <Input id="provider" name="provider" value={formData.provider} onChange={handleChange} className="col-span-3 bg-[var(--covoria-bg-main)] border-[var(--covoria-border-color)]" />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="coverage_amount" className="text-right">Coverage</Label>
            <Input id="coverage_amount" name="coverage_amount" type="number" value={formData.coverage_amount} onChange={handleChange} className="col-span-3 bg-[var(--covoria-bg-main)] border-[var(--covoria-border-color)]" />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="premium_amount" className="text-right">Premium</Label>
            <Input id="premium_amount" name="premium_amount" type="number" value={formData.premium_amount} onChange={handleChange} className="col-span-3 bg-[var(--covoria-bg-main)] border-[var(--covoria-border-color)]" />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="start_date" className="text-right">Start Date</Label>
            <DatePicker 
              date={formData.start_date}
              setDate={(date) => handleDateChange('start_date', date)}
              className="col-span-3"
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="is_active" className="text-right">Active</Label>
            <Switch
              id="is_active"
              checked={formData.is_active}
              onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, is_active: checked }))}
            />
          </div>
        </form>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
          <Button type="submit" onClick={handleSubmit} disabled={isSubmitting} className="covoria-gradient text-white">
            {isSubmitting ? 'Saving...' : 'Save Policy'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}