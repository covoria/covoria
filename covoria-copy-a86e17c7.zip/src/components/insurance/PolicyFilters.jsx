import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ListFilter, Shield, Users } from 'lucide-react';

export default function PolicyFilters({ onFilterChange }) {
  const [filters, setFilters] = React.useState({
    type: 'all',
    status: 'all',
    provider: 'all'
  });

  const handleFilterChange = (filterType, value) => {
    const newFilters = { ...filters, [filterType]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  return (
    <div className="flex gap-2 flex-wrap">
      <Select onValueChange={(value) => handleFilterChange('type', value)} value={filters.type}>
        <SelectTrigger className="w-[140px] bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
          <ListFilter className="w-4 h-4 mr-2" />
          <SelectValue placeholder="All Types" />
        </SelectTrigger>
        <SelectContent className="bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
          <SelectItem value="all">All Types</SelectItem>
          <SelectItem value="health">Health</SelectItem>
          <SelectItem value="life">Life</SelectItem>
          <SelectItem value="auto">Auto</SelectItem>
          <SelectItem value="home">Home</SelectItem>
          <SelectItem value="disability">Disability</SelectItem>
        </SelectContent>
      </Select>

      <Select onValueChange={(value) => handleFilterChange('status', value)} value={filters.status}>
        <SelectTrigger className="w-[140px] bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
          <Shield className="w-4 h-4 mr-2" />
          <SelectValue placeholder="All Status" />
        </SelectTrigger>
        <SelectContent className="bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
          <SelectItem value="all">All Status</SelectItem>
          <SelectItem value="active">Active</SelectItem>
          <SelectItem value="inactive">Inactive</SelectItem>
        </SelectContent>
      </Select>

      <Select onValueChange={(value) => handleFilterChange('provider', value)} value={filters.provider}>
        <SelectTrigger className="w-[140px] bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
          <Users className="w-4 h-4 mr-2" />
          <SelectValue placeholder="All Providers" />
        </SelectTrigger>
        <SelectContent className="bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
          <SelectItem value="all">All Providers</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}