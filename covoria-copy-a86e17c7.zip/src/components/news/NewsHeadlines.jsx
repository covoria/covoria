import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Newspaper, Clock, ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';
import NewsService from '../services/NewsService';

export default function NewsHeadlines({ maxItems = 2, showOnMobile = false }) {
  const [headlines, setHeadlines] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadHeadlines();
  }, []);

  const loadHeadlines = async () => {
    setIsLoading(true);
    try {
      const news = await NewsService.fetchHeadlines();
      setHeadlines(NewsService.getRecentHeadlines(maxItems));
    } catch (error) {
      console.error('Error loading headlines:', error);
    }
    setIsLoading(false);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'Today';
    if (diffDays === 2) return 'Yesterday';
    if (diffDays <= 7) return `${diffDays - 1} days ago`;
    return date.toLocaleDateString();
  };

  const getCategoryColor = (category) => {
    const colors = {
      health: 'bg-red-100 text-red-800',
      auto: 'bg-blue-100 text-blue-800',
      life: 'bg-purple-100 text-purple-800',
      home: 'bg-green-100 text-green-800',
      default: 'bg-gray-100 text-gray-800'
    };
    return colors[category] || colors.default;
  };

  if (isLoading) {
    return (
      <div className={`${showOnMobile ? '' : 'hidden md:block'}`}>
        <Card className="covoria-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm">
              <Newspaper className="w-4 h-4" />
              Industry News
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[...Array(maxItems)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className={`${showOnMobile ? '' : 'hidden md:block'}`}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="covoria-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm">
              <Newspaper className="w-4 h-4 text-cyan-600" />
              Industry News
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {headlines.map((headline, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="border-b border-gray-100 last:border-0 pb-3 last:pb-0"
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h4 className="text-sm font-medium text-gray-900 leading-tight line-clamp-2">
                      {headline.title}
                    </h4>
                    <ExternalLink className="w-3 h-3 text-gray-400 shrink-0 mt-1" />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">{headline.source}</span>
                      {headline.category && (
                        <Badge className={`text-xs px-2 py-0 ${getCategoryColor(headline.category)}`}>
                          {headline.category}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-gray-400">
                      <Clock className="w-3 h-3" />
                      <span>{formatDate(headline.date)}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}