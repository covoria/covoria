import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Bell, Users, Home, Briefcase, Baby, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const lifeEventIcons = {
  marriage: Users,
  birth: Baby,
  job_change: Briefcase,
  home_purchase: Home
};

export default function SmartCheckIn({ onCheckIn, onDismiss }) {
  const [lastCheckIn, setLastCheckIn] = useState(null);
  const [suggestedEvents, setSuggestedEvents] = useState([]);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    loadCheckInData();
  }, []);

  const loadCheckInData = () => {
    const lastCheck = localStorage.getItem('covoria_last_checkin');
    if (lastCheck) {
      setLastCheckIn(new Date(lastCheck));
    }

    // Mock life event suggestions
    setSuggestedEvents([
      { type: 'marriage', label: 'Got married', priority: 'high' },
      { type: 'birth', label: 'Had a child', priority: 'high' },
      { type: 'job_change', label: 'Changed jobs', priority: 'medium' },
      { type: 'home_purchase', label: 'Bought a home', priority: 'medium' }
    ]);
  };

  const handleCheckIn = (lifeEvents = []) => {
    const now = new Date();
    localStorage.setItem('covoria_last_checkin', now.toISOString());
    setLastCheckIn(now);
    setIsVisible(false);
    onCheckIn(lifeEvents);
  };

  const handleDismiss = () => {
    localStorage.setItem('covoria_last_checkin', new Date().toISOString());
    setIsVisible(false);
    onDismiss();
  };

  const handleEventSelect = (eventType) => {
    handleCheckIn([eventType]);
  };

  const daysSinceLastCheckIn = lastCheckIn 
    ? Math.floor((new Date() - lastCheckIn) / (1000 * 60 * 60 * 24))
    : null;

  const shouldShowReminder = !lastCheckIn || daysSinceLastCheckIn > 180;

  if (!shouldShowReminder || !isVisible) {
    return null;
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="fixed bottom-4 right-4 z-50 w-80 max-w-[90vw]"
        >
          <Card className="covoria-card border-2 border-cyan-200 shadow-xl">
            <CardHeader className="pb-3 relative">
              <Button
                onClick={handleDismiss}
                variant="ghost"
                size="sm"
                className="absolute top-2 right-2 h-6 w-6 p-0 hover:bg-gray-100"
              >
                <X className="w-4 h-4" />
              </Button>
              <CardTitle className="flex items-center gap-2 text-lg pr-8">
                <Bell className="w-5 h-5 text-cyan-600" />
                Time for a Coverage Check-in
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">
                {lastCheckIn 
                  ? `It's been ${daysSinceLastCheckIn} days since your last review. ` 
                  : 'Welcome! Let\'s make sure your coverage is up to date. '
                }
                Have any of these life events happened recently?
              </p>

              <div className="space-y-2 mb-4">
                {suggestedEvents.map((event) => {
                  const Icon = lifeEventIcons[event.type];
                  return (
                    <Button
                      key={event.type}
                      variant="outline"
                      onClick={() => handleEventSelect(event.type)}
                      className="w-full justify-start gap-2 h-auto p-3 text-left hover:bg-cyan-50 hover:border-cyan-200"
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="flex-1">{event.label}</span>
                      {event.priority === 'high' && (
                        <Badge className="bg-red-100 text-red-800 text-xs">Important</Badge>
                      )}
                    </Button>
                  );
                })}
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={() => handleCheckIn()}
                  className="flex-1 covoria-gradient text-white"
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Quick Check-in
                </Button>
                <Button
                  onClick={handleDismiss}
                  variant="ghost"
                  className="text-gray-500 hover:bg-gray-100"
                >
                  Later
                </Button>
              </div>

              {lastCheckIn && (
                <p className="text-xs text-gray-500 mt-2 text-center">
                  Last check-in: {lastCheckIn.toLocaleDateString()}
                </p>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}