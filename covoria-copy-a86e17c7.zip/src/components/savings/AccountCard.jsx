
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import {
  PiggyBank, // Used for account type icons
  Edit        // Used for the edit button icon
} from 'lucide-react';

export default function AccountCard({ account, delay = 0, onEdit }) {
  // Configuration for different account types, including icon, background, and text colors.
  // This replaces the previous getTypeColor function and standardizes color themes.
  const accountTypesConfig = {
    '401k': { icon: PiggyBank, bg: 'bg-blue-100 dark:bg-blue-900/50', color: 'text-blue-800 dark:text-blue-300' },
    '403b': { icon: PiggyBank, bg: 'bg-indigo-100 dark:bg-indigo-900/50', color: 'text-indigo-800 dark:text-indigo-300' },
    'ira': { icon: PiggyBank, bg: 'bg-green-100 dark:bg-green-900/50', color: 'text-green-800 dark:text-green-300' },
    'roth_ira': { icon: PiggyBank, bg: 'bg-purple-100 dark:bg-purple-900/50', color: 'text-purple-800 dark:text-purple-300' },
    'hsa': { icon: PiggyBank, bg: 'bg-teal-100 dark:bg-teal-900/50', color: 'text-teal-800 dark:text-teal-300' },
    'pension': { icon: PiggyBank, bg: 'bg-orange-100 dark:bg-orange-900/50', color: 'text-orange-800 dark:text-orange-300' },
    default: { icon: PiggyBank, bg: 'bg-gray-100 dark:bg-gray-800/50', color: 'text-gray-800 dark:text-gray-300' },
  };

  // Determine the configuration based on the account type, falling back to default.
  const config = accountTypesConfig[account.account_type] || accountTypesConfig.default;
  const Icon = config.icon; // The Icon component to be rendered.

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <Card className="covoria-card h-full flex flex-col">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-3">
              {/* Account type icon with dynamic background and text colors */}
              <div className={`p-2 rounded-lg ${config.bg}`}>
                <Icon className={`w-6 h-6 ${config.color}`} />
              </div>
              <div>
                {/* Account name with primary text color, including dark mode support */}
                <CardTitle className="text-lg font-bold text-gray-900 dark:text-[var(--covoria-text-primary)]">
                  {account.account_name}
                </CardTitle>
                {/* Provider name with secondary text color, including dark mode support */}
                <p className="text-sm text-gray-500 dark:text-[var(--covoria-text-secondary)]">
                  {account.provider}
                </p>
              </div>
            </div>
            {/* Account type badge with standardized outline style and dark mode support */}
            <Badge variant="outline" className="capitalize text-gray-600 dark:text-[var(--covoria-text-secondary)] border-gray-300 dark:border-slate-600">
              {account.account_type?.replace('_', ' ')}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="flex-grow space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            {/* Current Balance display */}
            <div>
              <p className="text-gray-500 dark:text-[var(--covoria-text-secondary)]">Current Balance</p>
              <p className="font-bold text-gray-900 dark:text-[var(--covoria-text-primary)]">
                {/* Use toLocaleString for currency formatting, as per outline */}
                ${(account.current_balance || 0).toLocaleString()}
              </p>
            </div>

            {/* Interest Rate display */}
            <div>
              <p className="text-gray-500 dark:text-[var(--covoria-text-secondary)]">Interest Rate</p>
              <p className="font-bold text-gray-900 dark:text-[var(--covoria-text-primary)]">
                {account.interest_rate ? `${account.interest_rate}%` : 'N/A'}
              </p>
            </div>
          </div>

          {/* Account Number (last 4 digits) display */}
          <div className="text-xs text-gray-500 dark:text-[var(--covoria-text-secondary)]">
            Account #: {account.account_number ? `...${account.account_number.slice(-4)}` : 'N/A'}
          </div>
        </CardContent>

        {/* Footer section with Active status badge and Details button */}
        <div className="p-4 border-t border-gray-100 dark:border-slate-700 flex justify-between items-center">
          <div>
            {/* Active/Inactive Badge with dynamic colors and dark mode support */}
            <Badge className={account.is_active ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' : 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300'}>
              {account.is_active ? 'Active' : 'Inactive'}
            </Badge>
          </div>
          {/* Details Button, utilizing the onEdit prop */}
          <Button variant="outline" size="sm" onClick={() => onEdit(account)}>
            <Edit className="w-3 h-3 mr-1" /> Details
          </Button>
        </div>
      </Card>
    </motion.div>
  );
}
