class NewsService {
  constructor() {
    this.headlines = [];
    this.isLoaded = false;
    this.lastFetch = null;
    this.cacheTimeout = 30 * 60 * 1000; // 30 minutes
    this.fallbackHeadlines = [
      {
        title: "Health Insurance Costs Rise 7% This Year",
        source: "Insurance Today",
        date: "2024-01-10",
        url: "#",
        category: "health"
      },
      {
        title: "New Auto Insurance Discounts for Safe Drivers",
        source: "Coverage News",
        date: "2024-01-08",
        url: "#",
        category: "auto"
      }
    ];
  }

  async fetchHeadlines() {
    // Check cache
    if (this.isLoaded && this.lastFetch && 
        (Date.now() - this.lastFetch < this.cacheTimeout)) {
      return this.headlines;
    }

    try {
      // For demo purposes, we'll use mock data
      // In production, this would call a real news API
      await this.simulateAPICall();
      
      this.headlines = [
        {
          title: "Life Insurance Rates Drop 12% for Healthy Adults",
          source: "Financial Times",
          date: new Date().toISOString().split('T')[0],
          url: "#",
          category: "life"
        },
        {
          title: "Auto Insurance: New State Regulations Take Effect",
          source: "Insurance Weekly",
          date: new Date(Date.now() - 86400000).toISOString().split('T')[0],
          url: "#",
          category: "auto"
        },
        {
          title: "HSA Contribution Limits Increase for 2024",
          source: "Health Coverage Report",
          date: new Date(Date.now() - 172800000).toISOString().split('T')[0],
          url: "#",
          category: "health"
        }
      ];
      
      this.isLoaded = true;
      this.lastFetch = Date.now();
      
      return this.headlines;
    } catch (error) {
      console.warn('Failed to fetch news, using fallback:', error);
      return this.fallbackHeadlines;
    }
  }

  async simulateAPICall() {
    // Simulate network delay
    return new Promise(resolve => setTimeout(resolve, 500));
  }

  filterByKeywords(keywords = ['insurance', 'coverage', 'health', 'auto']) {
    return this.headlines.filter(headline =>
      keywords.some(keyword =>
        headline.title.toLowerCase().includes(keyword.toLowerCase())
      )
    );
  }

  getRecentHeadlines(count = 2) {
    return this.headlines.slice(0, count);
  }
}

export default new NewsService();