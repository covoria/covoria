// SPRINT 22: Smart Insights Cascade & Full Platform Sync
// Unified Intelligence Layer with Dual-Source Knowledge Management

import { InsuranceKnowledgeBase } from '@/api/entities';
import { User } from '@/api/entities';
import { InsurancePolicy } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';

//////////////////////////////////////////////////////////////////
// SMART KNOWLEDGE ENGINE - DUAL SOURCE ARCHITECTURE
//////////////////////////////////////////////////////////////////

export class SmartKnowledgeEngine {
  constructor() {
    this.knowledgeCache = new Map();
    this.sourceStats = new Map();
    this.lastCacheUpdate = null;
    this.cacheValidityPeriod = 10 * 60 * 1000; // 10 minutes for faster refresh
    
    // Define source priorities
    this.sourcePriority = {
      'SmartCSV_v2': 10,           // Highest - New CSV insights
      'KnowledgeExpansion_V10': 8,  // High - PDF insights
      'default': 5                  // Medium - Other sources
    };
  }

  async initializeKnowledgeBase(forceRefresh = false) {
    const now = Date.now();
    
    if (!forceRefresh && this.lastCacheUpdate && 
        (now - this.lastCacheUpdate) < this.cacheValidityPeriod && 
        this.knowledgeCache.size > 0) {
      return this.getKnowledgeStats();
    }

    console.log("🧠 Initializing Smart Knowledge Engine...");
    
    try {
      // Load only verified sources
      const allInsights = await InsuranceKnowledgeBase.filter({
        is_active: true,
        visibleToAI: true
      }, '-created_date');

      // Filter for approved sources only
      const approvedSources = ['SmartCSV_v2', 'KnowledgeExpansion_V10'];
      const verifiedInsights = allInsights.filter(insight => 
        approvedSources.includes(insight.source) || 
        (insight.sourceFile && insight.sourceFile.includes('v10'))
      );

      // Clear and rebuild cache
      this.knowledgeCache.clear();
      this.sourceStats.clear();

      verifiedInsights.forEach(insight => {
        const enrichedInsight = this.enrichInsight(insight);
        this.knowledgeCache.set(insight.id, enrichedInsight);
        
        // Track source statistics
        const source = enrichedInsight.source || 'unknown';
        this.sourceStats.set(source, (this.sourceStats.get(source) || 0) + 1);
      });

      this.lastCacheUpdate = now;
      
      console.log(`✅ Smart Knowledge Engine initialized:`);
      console.log(`   Total insights: ${this.knowledgeCache.size}`);
      for (const [source, count] of this.sourceStats.entries()) {
        console.log(`   ${source}: ${count} insights`);
      }
      
      return this.getKnowledgeStats();

    } catch (error) {
      console.error("❌ Failed to initialize Smart Knowledge Engine:", error);
      return { totalInsights: 0, sources: {} };
    }
  }

  enrichInsight(insight) {
    // Standardize and enrich insight data
    const enriched = {
      ...insight,
      searchableText: this.buildSearchableText(insight),
      tagSet: new Set((insight.tags || []).map(t => t.toLowerCase())),
      sourcePriority: this.sourcePriority[insight.source] || this.sourcePriority.default,
      normalizedSeverity: this.normalizeSeverity(insight.severity),
      parsedLifeStage: this.parseLifeStage(insight.lifeStage),
      parsedIncomeLevel: this.parseIncomeLevel(insight.incomeLevel)
    };

    return enriched;
  }

  buildSearchableText(insight) {
    return [
      insight.title || insight.sectionTitle || '',
      insight.content || '',
      insight.insuranceType || '',
      insight.insightType || '',
      insight.recommendedAction || '',
      ...(insight.tags || []),
      insight.lifeStage || '',
      insight.incomeLevel || ''
    ].join(' ').toLowerCase();
  }

  normalizeSeverity(severity) {
    if (!severity) return 'medium';
    const lower = severity.toLowerCase();
    if (lower.includes('critical') || lower.includes('high')) return 'high';
    if (lower.includes('low')) return 'low';
    return 'medium';
  }

  parseLifeStage(lifeStage) {
    if (!lifeStage) return 'general';
    const lower = lifeStage.toLowerCase();
    if (lower.includes('senior') || lower.includes('65+')) return 'senior';
    if (lower.includes('family') || lower.includes('parent')) return 'family';
    if (lower.includes('young') || lower.includes('20s')) return 'young_professional';
    if (lower.includes('freelancer') || lower.includes('gig')) return 'freelancer';
    return 'general';
  }

  parseIncomeLevel(incomeLevel) {
    if (!incomeLevel) return 'general';
    const lower = incomeLevel.toLowerCase();
    if (lower.includes('low') || lower.includes('<50k')) return 'low_income';
    if (lower.includes('high') || lower.includes('200k+')) return 'high_income';
    return 'middle_income';
  }

  getKnowledgeStats() {
    return {
      totalInsights: this.knowledgeCache.size,
      sources: Object.fromEntries(this.sourceStats),
      lastUpdated: this.lastCacheUpdate
    };
  }

  // ADVANCED SEARCH WITH DUAL-SOURCE PRIORITIZATION
  async findRelevantInsights(query, filters = {}) {
    await this.initializeKnowledgeBase();
    
    if (this.knowledgeCache.size === 0) {
      console.warn("⚠️ No insights available in knowledge base");
      return [];
    }

    const {
      insuranceType,
      insightType,
      lifeStage,
      incomeLevel,
      severity,
      source,
      userProfile,
      maxResults = 10
    } = filters;

    const queryLower = query.toLowerCase();
    const queryWords = queryLower.split(/\s+/).filter(w => w.length > 2);
    
    const insights = Array.from(this.knowledgeCache.values());
    
    const scoredInsights = insights.map(insight => {
      let score = 0;
      
      // Base relevance scoring
      if (insight.searchableText.includes(queryLower)) score += 25;
      
      queryWords.forEach(word => {
        if (insight.title?.toLowerCase().includes(word) || 
            insight.sectionTitle?.toLowerCase().includes(word)) score += 15;
        if (insight.content?.toLowerCase().includes(word)) score += 8;
        if (insight.tagSet.has(word)) score += 12;
        if (insight.insuranceType?.toLowerCase().includes(word)) score += 10;
        if (insight.recommendedAction?.toLowerCase().includes(word)) score += 6;
      });

      // Source priority bonus
      score += insight.sourcePriority;

      // Profile matching bonuses
      if (userProfile) {
        if (insight.parsedLifeStage === this.determineUserLifeStage(userProfile)) score += 20;
        if (insight.parsedIncomeLevel === this.determineUserIncomeLevel(userProfile)) score += 15;
      }

      // Filter enforcement
      if (insuranceType && insight.insuranceType !== insuranceType) return null;
      if (insightType && insight.insightType !== insightType) return null;
      if (lifeStage && insight.parsedLifeStage !== lifeStage) return null;
      if (incomeLevel && insight.parsedIncomeLevel !== incomeLevel) return null;
      if (severity && insight.normalizedSeverity !== severity) return null;
      if (source && insight.source !== source) return null;

      return { ...insight, relevanceScore: score };
    }).filter(Boolean);

    return scoredInsights
      .sort((a, b) => {
        // Primary sort: relevance score
        if (a.relevanceScore !== b.relevanceScore) {
          return b.relevanceScore - a.relevanceScore;
        }
        // Secondary sort: source priority
        if (a.sourcePriority !== b.sourcePriority) {
          return b.sourcePriority - a.sourcePriority;
        }
        // Tertiary sort: severity
        const severityOrder = { high: 3, medium: 2, low: 1 };
        return (severityOrder[b.normalizedSeverity] || 2) - (severityOrder[a.normalizedSeverity] || 2);
      })
      .slice(0, maxResults);
  }

  determineUserLifeStage(userProfile) {
    const age = userProfile?.age || 30;
    const dependents = userProfile?.dependents || 0;
    const employment = userProfile?.employment_status;

    if (age >= 65) return 'senior';
    if (dependents > 0) return 'family';
    if (employment === 'self_employed') return 'freelancer';
    if (age < 30) return 'young_professional';
    return 'general';
  }

  determineUserIncomeLevel(userProfile) {
    const bracket = userProfile?.income_bracket;
    if (!bracket) return 'general';
    
    if (bracket.includes('0-50k')) return 'low_income';
    if (bracket.includes('200k+')) return 'high_income';
    return 'middle_income';
  }

  // POLICY DOCUMENT ANALYSIS WITH SMART MATCHING
  async analyzeDocumentGaps(userEmail, documentContent = '') {
    console.log(`🔍 Analyzing document gaps for user: ${userEmail}`);
    
    try {
      const user = await User.filter({ email: userEmail }).then(users => users[0]);
      const policies = await InsurancePolicy.filter({ created_by: userEmail });
      
      if (!user) {
        throw new Error("User not found");
      }

      const gapAnalysis = [];
      
      // Extract key terms from document if provided
      const documentTerms = this.extractKeyTerms(documentContent);
      
      // Check for missing essential coverage
      const policyTypes = new Set(policies.map(p => p.insurance_type));
      const userLifeStage = this.determineUserLifeStage(user);
      
      const essentialTypes = this.getEssentialCoverageTypes(user);
      
      for (const type of essentialTypes) {
        if (!policyTypes.has(type)) {
          const gapInsights = await this.findRelevantInsights(`${type} insurance essential coverage`, {
            insuranceType: type,
            insightType: 'gap',
            lifeStage: userLifeStage,
            userProfile: user,
            maxResults: 2
          });
          
          gapAnalysis.push(...gapInsights.map(insight => ({
            ...insight,
            gapType: 'missing_coverage',
            reasoning: `No ${type} insurance found in your policies`,
            priority: 'high'
          })));
        }
      }

      // Document-specific gap analysis
      if (documentTerms.length > 0) {
        const docQuery = documentTerms.join(' ');
        const documentInsights = await this.findRelevantInsights(docQuery, {
          insightType: 'gap',
          userProfile: user,
          maxResults: 3
        });
        
        gapAnalysis.push(...documentInsights.map(insight => ({
          ...insight,
          gapType: 'document_gap',
          reasoning: 'Based on your uploaded document analysis',
          priority: 'medium'
        })));
      }

      // Optimization opportunities
      for (const policy of policies) {
        const optimizationInsights = await this.findRelevantInsights(`${policy.insurance_type} optimization cost saving`, {
          insuranceType: policy.insurance_type,
          insightType: 'optimization',
          userProfile: user,
          maxResults: 1
        });
        
        gapAnalysis.push(...optimizationInsights.map(insight => ({
          ...insight,
          gapType: 'optimization',
          reasoning: `Potential optimization for your ${policy.insurance_type} policy`,
          priority: 'medium'
        })));
      }

      return this.prioritizeAndLimitGaps(gapAnalysis, 8);

    } catch (error) {
      console.error("❌ Document gap analysis failed:", error);
      return [];
    }
  }

  extractKeyTerms(content) {
    if (!content || typeof content !== 'string') return [];
    
    const insuranceTerms = [
      'deductible', 'premium', 'copay', 'coinsurance', 'out-of-pocket',
      'in-network', 'out-of-network', 'hmo', 'ppo', 'epo',
      'collision', 'comprehensive', 'liability', 'uninsured',
      'term life', 'whole life', 'disability', 'medicare',
      'medicaid', 'aca', 'cobra', 'hsa', 'fsa'
    ];
    
    const lowerContent = content.toLowerCase();
    return insuranceTerms.filter(term => lowerContent.includes(term));
  }

  getEssentialCoverageTypes(user) {
    const age = user?.age || 30;
    const dependents = user?.dependents || 0;
    const employment = user?.employment_status;
    
    const essential = ['health'];
    
    // Auto insurance (if driving age)
    if (age >= 16) essential.push('auto');
    
    // Life insurance (if dependents)
    if (dependents > 0) essential.push('life');
    
    // Disability insurance (if working)
    if (employment === 'employed' || employment === 'self_employed') {
      essential.push('disability');
    }
    
    return essential;
  }

  prioritizeAndLimitGaps(gaps, maxResults) {
    return gaps
      .sort((a, b) => {
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        const aPriority = priorityOrder[a.priority] || 2;
        const bPriority = priorityOrder[b.priority] || 2;
        
        if (aPriority !== bPriority) return bPriority - aPriority;
        return b.relevanceScore - a.relevanceScore;
      })
      .slice(0, maxResults);
  }

  // FORECAST ENGINE INTEGRATION
  async generateForecastInsights(userEmail) {
    console.log(`🔮 Generating forecast insights for: ${userEmail}`);
    
    try {
      const user = await User.filter({ email: userEmail }).then(users => users[0]);
      if (!user) throw new Error("User not found");
      
      const forecastInsights = [];
      const userLifeStage = this.determineUserLifeStage(user);
      const age = user?.age || 30;
      
      // Age-based future planning
      if (age >= 60 && age < 65) {
        const medicareInsights = await this.findRelevantInsights('medicare transition planning retirement', {
          insightType: 'forecast',
          lifeStage: 'senior',
          userProfile: user,
          maxResults: 2
        });
        forecastInsights.push(...medicareInsights);
      }

      // Life stage transitions
      if (userLifeStage === 'young_professional' && age > 25) {
        const familyPlanningInsights = await this.findRelevantInsights('family planning insurance life insurance', {
          insightType: 'forecast',
          lifeStage: 'family',
          userProfile: user,
          maxResults: 1
        });
        forecastInsights.push(...familyPlanningInsights);
      }

      // General future risks
      const generalForecast = await this.findRelevantInsights('future risks planning ahead', {
        insightType: 'forecast',
        lifeStage: userLifeStage,
        userProfile: user,
        maxResults: 2
      });
      forecastInsights.push(...generalForecast);

      return forecastInsights.slice(0, 5);

    } catch (error) {
      console.error("❌ Forecast generation failed:", error);
      return [];
    }
  }

  // AUDIT AND LOGGING
  logInsightUsage(insightId, context, userEmail) {
    console.log(`📊 Insight used: ${insightId} | Context: ${context} | User: ${userEmail}`);
    
    // Future: Store in analytics table
    // This will be used for click-through, conversion tracking
  }

  async getSourceAudit() {
    await this.initializeKnowledgeBase();
    
    const audit = {
      timestamp: new Date().toISOString(),
      totalInsights: this.knowledgeCache.size,
      sourceBreakdown: Object.fromEntries(this.sourceStats),
      cacheStatus: this.lastCacheUpdate ? 'active' : 'inactive',
      lastRefresh: this.lastCacheUpdate ? new Date(this.lastCacheUpdate).toISOString() : null
    };
    
    console.log("📊 Source Audit:", audit);
    return audit;
  }
}

// Initialize global instance
export const smartKnowledge = new SmartKnowledgeEngine();

console.log("🧠 Smart Knowledge Engine v2.0 initialized");