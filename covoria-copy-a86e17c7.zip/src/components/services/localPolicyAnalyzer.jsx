import { InsurancePolicy } from '@/api/entities';
import { SavingsAccount } from '@/api/entities';
import { Insight } from '@/api/entities';
import { User } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';

// This function runs entirely on the client-side to provide instant, basic insights.
export function analyzePolicyLocally(fileText, userEmail) {
  const insights = [];
  const lowerCaseText = fileText.toLowerCase();

  // Insight 1: Check for missing disability coverage
  if (!/disability|income protection|loss of income/i.test(lowerCaseText)) {
    insights.push({
      title: 'Potential Gap: Disability Insurance',
      description: "We didn't find any mention of disability or income protection. This is crucial for protecting your income if you're unable to work.",
      category: 'coverage_gap',
      priority: 'high',
      created_by: userEmail,
      is_resolved: false,
      date_identified: new Date().toISOString().split('T')[0],
      insight_suggestion_origin: 'auto_generated'
    });
  }

  // Insight 2: Check for potentially high premiums
  const premiumMatches = lowerCaseText.match(/premium.*\$?(\d{1,3}(,\d{3})*(\.\d{2})?)/);
  if (premiumMatches) {
      const premium = parseFloat(premiumMatches[1].replace(/,/g, ''));
      if (premium > 500) {
           insights.push({
              title: 'Review High Premium Cost',
              description: `A premium of $${premium.toLocaleString()} was detected, which seems high. It might be worth shopping around for better rates.`,
              category: 'cost_saving',
              priority: 'medium',
              created_by: userEmail,
              is_resolved: false,
              date_identified: new Date().toISOString().split('T')[0],
              insight_suggestion_origin: 'auto_generated'
            });
      }
  }

  // Insight 3: Check for policy expiration dates within 90 days
  const dateMatches = lowerCaseText.match(/expires on|expiration date|end date:?\s*(\d{1,2}\/\d{1,2}\/\d{4})/i);
  if (dateMatches && dateMatches[1]) {
    const expiryDate = new Date(dateMatches[1]);
    const today = new Date();
    const ninetyDaysFromNow = new Date();
    ninetyDaysFromNow.setDate(today.getDate() + 90);

    if (expiryDate > today && expiryDate <= ninetyDaysFromNow) {
      insights.push({
        title: 'Upcoming Policy Expiration',
        description: `Your policy is set to expire on ${expiryDate.toLocaleDateString()}. Be sure to renew or find new coverage to avoid a lapse.`,
        category: 'risk_alert',
        priority: 'high',
        created_by: userEmail,
        is_resolved: false,
        date_identified: new Date().toISOString().split('T')[0],
        insight_suggestion_origin: 'auto_generated'
      });
    }
  }

  if (insights.length === 0) {
      insights.push({
        title: 'Initial Check Looks Good',
        description: "Your uploaded document doesn't show any immediate critical issues. For a deeper analysis, our AI will continue processing it.",
        category: 'optimization',
        priority: 'low',
        created_by: userEmail,
        is_resolved: false,
        date_identified: new Date().toISOString().split('T')[0],
        insight_suggestion_origin: 'auto_generated'
      });
  }

  return insights;
}