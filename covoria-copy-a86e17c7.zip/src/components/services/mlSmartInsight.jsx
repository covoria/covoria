// Sprint 18: Client-side ML Logic Simulation
// This utility simulates "lightweight intelligence" using statistical rules

export class MLSmartInsightEngine {
  
  // Main analysis function
  static async analyzeUserData(user, policies, accounts) {
    const insights = [];
    const timestamp = new Date().toISOString().split('T')[0];
    
    // Rule 1: High premium alert
    const totalMonthlyPremiums = this.calculateTotalMonthlyPremiums(policies);
    if (totalMonthlyPremiums > 600) {
      insights.push({
        title: 'High Premium Cost Detected',
        description: `Your total monthly premiums ($${totalMonthlyPremiums.toFixed(0)}) are significantly above average. Smart analysis suggests reviewing your coverage.`,
        reasoning: 'Statistical analysis shows premiums above $600/month often indicate over-insurance or inefficient policy structures.',
        category: 'cost_saving',
        priority: 'high',
        potential_savings: totalMonthlyPremiums * 0.15, // Estimate 15% savings
        action_required: 'Review each policy and compare rates with competitors. Consider consolidating with one provider for multi-policy discounts.',
        date_identified: timestamp,
        insight_suggestion_origin: 'ai_generated',
        is_resolved: false,
        created_by: user.email
      });
    }

    // Rule 2: Long-term planning gap
    const hasLife = policies.some(p => p.insurance_type === 'life' && p.is_active);
    const hasRetirement = accounts.some(a => ['401k', '403b', 'ira', 'roth_ira'].includes(a.account_type));
    if (!hasLife && !hasRetirement && user.age > 45) {
      insights.push({
        title: 'Missing Long-Term Financial Security',
        description: 'Smart pattern analysis indicates a gap in long-term financial protection for someone in your age group.',
        reasoning: 'People over 45 typically need both life insurance and retirement savings to maintain financial security.',
        category: 'coverage_gap',
        priority: 'critical',
        potential_savings: 0,
        action_required: 'Consider term life insurance and opening a retirement account (IRA or 401k if available through employer).',
        date_identified: timestamp,
        insight_suggestion_origin: 'ai_generated',
        is_resolved: false,
        created_by: user.email
      });
    }

    // Rule 3: Policy consolidation opportunity
    const policyTypeCount = this.countPoliciesByType(policies);
    const duplicateTypes = Object.entries(policyTypeCount).filter(([type, count]) => count >= 3);
    if (duplicateTypes.length > 0) {
      const [type, count] = duplicateTypes[0];
      insights.push({
        title: `Potential ${type.charAt(0).toUpperCase() + type.slice(1)} Policy Consolidation`,
        description: `You have ${count} ${type} policies. Smart analysis suggests consolidation opportunities.`,
        reasoning: 'Multiple policies of the same type often lead to overlapping coverage and higher administrative costs.',
        category: 'optimization',
        priority: 'medium',
        potential_savings: count * 50, // Estimate $50 savings per policy
        action_required: `Review your ${count} ${type} policies to identify overlaps and consolidate where possible.`,
        date_identified: timestamp,
        insight_suggestion_origin: 'ai_generated',
        is_resolved: false,
        created_by: user.email
      });
    }

    // Rule 4: Underinsurance risk
    const totalCoverage = policies.reduce((sum, p) => sum + (p.coverage_amount || 0), 0);
    const recommendedCoverage = this.calculateRecommendedCoverage(user);
    if (totalCoverage < recommendedCoverage * 0.7) {
      insights.push({
        title: 'Potential Underinsurance Risk',
        description: `Your total coverage ($${totalCoverage.toLocaleString()}) may be insufficient for your profile.`,
        reasoning: 'Smart analysis based on age, income, and dependents suggests higher coverage levels for adequate protection.',
        category: 'risk_alert',
        priority: 'high',
        potential_savings: 0,
        action_required: 'Review coverage amounts and consider increasing protection levels to match your needs.',
        date_identified: timestamp,
        insight_suggestion_origin: 'ai_generated',
        is_resolved: false,
        created_by: user.email
      });
    }

    // Rule 5: Emergency fund gap
    const emergencyFunds = accounts.filter(a => a.account_type === 'general_savings');
    const totalEmergencyFunds = emergencyFunds.reduce((sum, a) => sum + (a.current_balance || 0), 0);
    const monthlyIncome = this.estimateMonthlyIncome(user.income_bracket);
    if (totalEmergencyFunds < monthlyIncome * 3) {
      insights.push({
        title: 'Emergency Fund Below Recommended Level',
        description: `Your emergency savings ($${totalEmergencyFunds.toLocaleString()}) appear below the 3-6 month guideline.`,
        reasoning: 'Financial experts recommend 3-6 months of expenses in easily accessible emergency funds.',
        category: 'optimization',
        priority: 'medium',
        potential_savings: 0,
        action_required: 'Consider building your emergency fund to cover 3-6 months of essential expenses.',
        date_identified: timestamp,
        insight_suggestion_origin: 'ai_generated',
        is_resolved: false,
        created_by: user.email
      });
    }

    return insights;
  }

  // Helper functions
  static calculateTotalMonthlyPremiums(policies) {
    return policies.reduce((total, policy) => {
      if (!policy.is_active || !policy.premium_amount) return total;
      
      const monthly = policy.premium_frequency === 'annually' ? 
        policy.premium_amount / 12 : 
        policy.premium_frequency === 'quarterly' ?
        policy.premium_amount / 3 :
        policy.premium_amount;
        
      return total + monthly;
    }, 0);
  }

  static countPoliciesByType(policies) {
    const count = {};
    policies.filter(p => p.is_active).forEach(policy => {
      count[policy.insurance_type] = (count[policy.insurance_type] || 0) + 1;
    });
    return count;
  }

  static calculateRecommendedCoverage(user) {
    const baseAmount = user.income_bracket === '200k+' ? 500000 :
                      user.income_bracket === '100k-200k' ? 300000 :
                      user.income_bracket === '50k-100k' ? 150000 : 100000;
    
    const dependentMultiplier = 1 + (user.dependents * 0.5);
    return baseAmount * dependentMultiplier;
  }

  static estimateMonthlyIncome(bracket) {
    switch (bracket) {
      case '200k+': return 20000;
      case '100k-200k': return 12500;
      case '50k-100k': return 6250;
      case '0-50k': return 3000;
      default: return 5000;
    }
  }

  // Check if no urgent patterns found
  static getNoPatternMessage() {
    return {
      title: 'Smart Pattern Analysis Complete',
      description: "Covoria didn't detect any urgent patterns. Your financial protection strategy looks well-balanced!",
      reasoning: 'Our smart analysis reviewed your policies and accounts for common risk patterns and optimization opportunities.',
      category: 'optimization',
      priority: 'low',
      potential_savings: 0,
      action_required: 'Continue monitoring your coverage and consider periodic reviews as your life situation changes.',
      date_identified: new Date().toISOString().split('T')[0],
      insight_suggestion_origin: 'ai_generated',
      is_resolved: false
    };
  }
}

// Entity for tracking smart patterns
export const SmartPatternMatch = {
  async create(patternData) {
    // This would typically save to SmartPatternMatch entity
    console.log('Smart pattern detected:', patternData);
    return patternData;
  }
};