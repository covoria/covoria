import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { UploadCloud, CheckCircle, Brain, LayoutDashboard, X, FileText, RefreshCw, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { uploadDocument } from '@/api/functions';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { UploadProcessingLog } from '@/api/entities';

export default function DataImportCard({ onProcessingComplete }) {
    const [filesToUpload, setFilesToUpload] = useState([]);
    const [uploadStatus, setUploadStatus] = useState([]);
    const [isUploading, setIsUploading] = useState(false);
    const [showCompletionModal, setShowCompletionModal] = useState(false);
    const fileInputRef = useRef(null);
    const navigate = useNavigate();

    const handleFileSelect = (selectedFiles) => {
        if (!selectedFiles || selectedFiles.length === 0) return;
        const filesArray = Array.from(selectedFiles).map(file => ({ file, name: file.name, status: 'pending', progress: 0, message: 'Waiting...' }));
        setFilesToUpload(filesArray);
        setUploadStatus([]);
    };
    
    useEffect(() => {
        if (filesToUpload.length > 0 && !isUploading) {
            handleUpload();
        }
    }, [filesToUpload, isUploading]);
    
    const handleUpload = async () => {
        if (filesToUpload.length === 0) return;
        
        setIsUploading(true);
        setUploadStatus(filesToUpload.map(f => ({ ...f, status: 'uploading', progress: 20, message: 'Uploading...' })));

        let completedCount = 0;
        const totalFiles = filesToUpload.length;

        for (let i = 0; i < totalFiles; i++) {
            const currentFile = filesToUpload[i];
            
            try {
                setUploadStatus(prev => prev.map((f, idx) => idx === i ? { ...f, status: 'analyzing', progress: 50, message: 'AI processing...' } : f));
                
                // We use a dummy file_url here because the backend function now handles file upload implicitly
                const response = await uploadDocument({ 
                    file: currentFile.file, 
                    fileName: currentFile.name,
                    file_url: "will_be_handled_by_backend"
                });

                if (!response.data?.success) {
                   throw new Error(response.data?.error || 'Backend processing failed.');
                }

                setUploadStatus(prev => prev.map((f, idx) => idx === i ? { ...f, status: 'completed', progress: 100, message: 'Analysis complete!' } : f));
                completedCount++;
            } catch (error) {
                console.error(`Upload failed for ${currentFile.name}:`, error);
                setUploadStatus(prev => prev.map((f, idx) => idx === i ? { ...f, status: 'failed', progress: 100, message: error.message || 'Upload failed' } : f));
            }
        }
        
        setIsUploading(false);
        sessionStorage.setItem('newAnalysisComplete', 'true');
        setShowCompletionModal(true);
        setFilesToUpload([]);
        
        if (onProcessingComplete) onProcessingComplete();
    };

    const handleModalClose = () => {
        setShowCompletionModal(false);
        setUploadStatus([]);
        window.dispatchEvent(new CustomEvent('covoriaDataUpdate'));
    };

    const totalProgress = uploadStatus.length > 0 ? (uploadStatus.reduce((acc, s) => acc + s.progress, 0) / uploadStatus.length) : 0;
    const completedCount = uploadStatus.filter(s => s.status === 'completed').length;

    return (
        <>
            <Card className="w-full max-w-2xl mx-auto bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardContent className="p-8">
                    <div className="text-center mb-6">
                        <h3 className="text-2xl font-bold text-white mb-2">AI-Powered Document Analysis</h3>
                        <p className="text-slate-300">Upload multiple insurance policies and financial documents for instant AI analysis.</p>
                    </div>
                    {isUploading || uploadStatus.length > 0 ? (
                         <div className="mb-6 p-4 bg-slate-700/50 rounded-lg space-y-3">
                            <div className="flex items-center justify-between mb-2">
                                <span className="text-white text-sm font-medium">Processing Files</span>
                                <span className="text-slate-300 text-xs">
                                    {completedCount} of {uploadStatus.length} files completed
                                </span>
                            </div>
                            <Progress value={totalProgress} className="w-full h-2 [&>div]:bg-gradient-to-r [&>div]:from-cyan-400 [&>div]:to-blue-500" />
                            {uploadStatus.map((file, index) => (
                                <div key={index} className="text-xs text-slate-300 flex items-center gap-2 p-2 bg-slate-800/50 rounded">
                                    {file.status === 'uploading' && <RefreshCw className="w-3 h-3 animate-spin text-cyan-400" />}
                                    {file.status === 'analyzing' && <RefreshCw className="w-3 h-3 animate-spin text-yellow-400" />}
                                    {file.status === 'completed' && <CheckCircle className="w-3 h-3 text-green-400" />}
                                    {file.status === 'failed' && <AlertTriangle className="w-3 h-3 text-red-400" />}
                                    <span className="truncate flex-1">{file.name}</span>
                                    <span className="font-mono text-xs">{file.message}</span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div
                            className="border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-200 border-slate-600 hover:border-slate-500"
                            onDragOver={(e) => e.preventDefault()}
                            onDrop={(e) => { e.preventDefault(); handleFileSelect(e.dataTransfer.files); }}
                        >
                            <UploadCloud className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                            <p className="text-white font-medium mb-2">Drop files here or click to browse</p>
                            <p className="text-slate-400 text-sm mb-4">Supports PDF, PNG, JPG files</p>
                            <input ref={fileInputRef} type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={(e) => handleFileSelect(e.target.files)} className="hidden" multiple />
                            <Button onClick={() => fileInputRef.current?.click()} disabled={isUploading}>
                                Choose Files
                            </Button>
                        </div>
                    )}
                </CardContent>
            </Card>

            <Dialog open={showCompletionModal} onOpenChange={(isOpen) => !isOpen && handleModalClose()}>
                <DialogContent className="bg-slate-900 border-slate-700 text-white max-w-md text-center p-8">
                    <DialogHeader className="space-y-4">
                        <div className="mx-auto w-16 h-16 rounded-full flex items-center justify-center bg-gradient-to-br from-cyan-500 to-blue-600">
                            <CheckCircle className="w-8 h-8 text-white" />
                        </div>
                        <DialogTitle className="text-2xl font-bold">Analysis Complete!</DialogTitle>
                        <DialogDescription className="text-slate-300 pt-2 text-base">
                            Your documents have been processed. Our AI is now generating insights for your dashboard and copilot.
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter className="mt-6 flex flex-col gap-3">
                        {/* THIS IS THE NEWLY ADDED BUTTON */}
                        <Button
                            onClick={() => { navigate(createPageUrl('MyInsuranceCopilot')); handleModalClose(); }}
                            className="w-full bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white h-12 text-base font-semibold rounded-lg"
                        >
                            <Brain className="w-5 h-5 mr-2" />
                            Go to AI Copilot
                        </Button>
                        <Button
                            onClick={() => { navigate(createPageUrl('Dashboard')); handleModalClose(); }}
                            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white h-12 text-base font-semibold rounded-lg"
                        >
                            <LayoutDashboard className="w-5 h-5 mr-2" />
                            Go to Dashboard
                        </Button>
                        <Button onClick={handleModalClose} variant="ghost" className="w-full text-slate-400 hover:text-white text-sm">
                            Close
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    );
}