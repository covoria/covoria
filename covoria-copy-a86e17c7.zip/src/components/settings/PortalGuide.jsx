import React, { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { UploadCloud, Loader2, CheckCircle, AlertTriangle, ArrowLeft, ExternalLink } from 'lucide-react';

export default function PortalGuide({ category, onBack, onFileSelect, status, message }) {
  const inputRef = useRef(null);

  const portalInfo = {
    health: {
      portals: [
        { name: "HealthCare.gov", url: "https://www.healthcare.gov", steps: ["Log in to your account", "Go to 'My Plans & Programs'", "Download your coverage summary or 1095-A form"] },
        { name: "Medicare.gov", url: "https://www.medicare.gov", steps: ["Sign in to MyMedicare", "Go to 'My Coverage'", "Download your Medicare Summary Notice"] },
        { name: "Your Insurance Company", url: "#", steps: ["Log in to your insurer's website", "Find 'Policy Documents' or 'Benefits Summary'", "Download your policy declaration page"] }
      ]
    },
    auto_home: {
      portals: [
        { name: "Geico", url: "https://www.geico.com", steps: ["Log in to your account", "Go to 'Policy Details'", "Download your policy declarations page"] },
        { name: "State Farm", url: "https://www.statefarm.com", steps: ["Sign in to your account", "Select 'Insurance' tab", "Download policy documents"] },
        { name: "Allstate", url: "https://www.allstate.com", steps: ["Log in to MyAccount", "View 'Policy Details'", "Download your policy summary"] }
      ]
    },
    life_disability: {
      portals: [
        { name: "Your Employer Benefits", url: "#", steps: ["Log in to your company's benefits portal", "Find 'Life Insurance' or 'Disability Coverage'", "Download your benefits summary"] },
        { name: "Your Insurance Company", url: "#", steps: ["Log in to your insurer's website", "Go to 'My Policies'", "Download policy documents"] }
      ]
    },
    government: {
      portals: [
        { name: "Social Security", url: "https://www.ssa.gov", steps: ["Create/log in to my Social Security account", "Go to 'Benefits & Payment Details'", "Download your benefit statement"] },
        { name: "VA Benefits", url: "https://www.va.gov", steps: ["Log in to VA.gov", "Go to 'Your VA Benefits'", "Download your benefits summary"] }
      ]
    }
  };

  const currentPortals = portalInfo[category.key] ? portalInfo[category.key].portals : [];

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      Array.from(e.target.files).forEach(file => onFileSelect(file));
      e.target.value = ''; // Reset input to allow selecting the same file again
    }
  };

  const handleContainerClick = () => {
    inputRef.current?.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="ghost" onClick={onBack} className="text-cyan-600 hover:text-cyan-700">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Categories
        </Button>
        <h3 className="text-xl font-bold text-gray-900">
          Connect to {category.title}
        </h3>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="bg-cyan-50 p-4 rounded-lg">
            <h4 className="font-semibold text-cyan-900 mb-2">Step 1: Log into your official portal</h4>
            <div className="space-y-3">
              {currentPortals.map((portal, index) => (
                <div key={index} className="bg-white p-3 rounded border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-gray-900">{portal.name}</span>
                    {portal.url !== '#' && (
                      <a href={portal.url} target="_blank" rel="noopener noreferrer" className="text-cyan-600 hover:text-cyan-700">
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {portal.steps.map((step, stepIndex) => (
                      <li key={stepIndex} className="flex items-start gap-2">
                        <span className="text-cyan-500 font-bold">•</span>
                        {step}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="font-semibold text-green-900 mb-3">Step 3: Upload the files below</h4>
            <div
              onClick={handleContainerClick}
              className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-green-300 rounded-lg cursor-pointer bg-white hover:bg-green-50 transition-all duration-200"
            >
              <UploadCloud className="w-12 h-12 mb-4 text-green-500" />
              <p className="font-medium text-gray-900 mb-2">Drop files here or click to upload</p>
              <p className="text-sm text-gray-600 text-center">PDF, Excel, CSV, Images (Max 10MB each)</p>
              <input
                type="file"
                ref={inputRef}
                onChange={handleFileChange}
                className="hidden"
                accept=".pdf,.csv,.xlsx,.xls,.jpg,.jpeg,.png"
                multiple
              />
            </div>
          </div>

          {status !== 'idle' && (
            <div className="flex items-center justify-center gap-3 p-3 bg-gray-100 rounded-lg">
              {status === 'uploading' || status === 'extracting' || status === 'analyzing' ? (
                <Loader2 className="w-5 h-5 text-gray-500 animate-spin" />
              ) : status === 'success' ? (
                <CheckCircle className="w-5 h-5 text-green-600" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-red-600" />
              )}
              <p className={`text-sm font-medium ${status === 'error' ? 'text-red-600' : 'text-gray-700'}`}>
                {message}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}