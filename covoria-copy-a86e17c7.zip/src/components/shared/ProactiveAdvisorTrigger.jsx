import React, { useEffect } from 'react';
import { proactiveAdvisor } from '@/api/functions';

export default function ProactiveAdvisorTrigger({ policyData, triggerType = 'policy_uploaded', context = {} }) {
  useEffect(() => {
    const triggerProactiveAdvice = async () => {
      try {
        const response = await proactiveAdvisor({
          trigger_type: triggerType,
          policy_data: policyData,
          context: context
        });
        
        if (response.data?.success) {
          console.log('Proactive advice generated:', response.data.message);
          // The message is stored in AssistantConversation and will be shown in notifications
        }
      } catch (error) {
        console.error('Failed to trigger proactive advice:', error);
      }
    };

    if (policyData || Object.keys(context).length > 0) {
      // Delay slightly to ensure document processing is complete
      setTimeout(triggerProactiveAdvice, 2000);
    }
  }, [policyData, triggerType, context]);

  return null; // This is a utility component that doesn't render anything
}