import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Save, 
  Edit, 
  Check, 
  X, 
  AlertCircle, 
  RefreshCw,
  Eye,
  EyeOff 
} from 'lucide-react';
import { DocumentField } from '@/api/entities';
import { motion, AnimatePresence } from 'framer-motion';

const FIELD_CATEGORIES = {
  policy_info: { label: 'Policy Information', color: 'blue' },
  coverage_details: { label: 'Coverage Details', color: 'green' },
  premium_info: { label: 'Premium Information', color: 'purple' },
  dates: { label: 'Important Dates', color: 'orange' },
  contact_info: { label: 'Contact Information', color: 'gray' },
  beneficiary_info: { label: 'Beneficiary Information', color: 'pink' }
};

const FIELD_TYPES = [
  { value: 'text', label: 'Text' },
  { value: 'number', label: 'Number' },
  { value: 'currency', label: 'Currency' },
  { value: 'date', label: 'Date' },
  { value: 'boolean', label: 'Yes/No' }
];

export default function DocumentFieldEditor({ documentId, onFieldsUpdated }) {
  const [fields, setFields] = useState([]);
  const [editingField, setEditingField] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showUnverified, setShowUnverified] = useState(true);
  const [groupedFields, setGroupedFields] = useState({});

  useEffect(() => {
    loadDocumentFields();
  }, [documentId]);

  useEffect(() => {
    // Group fields by category
    const grouped = fields.reduce((acc, field) => {
      const category = field.field_category || 'policy_info';
      if (!acc[category]) acc[category] = [];
      acc[category].push(field);
      return acc;
    }, {});

    // Sort fields within each category by display order
    Object.keys(grouped).forEach(category => {
      grouped[category].sort((a, b) => (a.display_order || 0) - (b.display_order || 0));
    });

    setGroupedFields(grouped);
  }, [fields]);

  const loadDocumentFields = async () => {
    setIsLoading(true);
    try {
      const documentFields = await DocumentField.filter({ document_id: documentId });
      setFields(Array.isArray(documentFields) ? documentFields : []);
    } catch (error) {
      console.error('Failed to load document fields:', error);
      setFields([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartEdit = (field) => {
    setEditingField({
      ...field,
      original_value: field.original_value || field.field_value
    });
  };

  const handleSaveEdit = async () => {
    if (!editingField) return;

    try {
      const updateData = {
        field_value: editingField.field_value,
        field_type: editingField.field_type,
        field_category: editingField.field_category,
        is_verified: true,
        user_corrected: editingField.field_value !== editingField.original_value
      };

      await DocumentField.update(editingField.id, updateData);
      
      setFields(prev => prev.map(field => 
        field.id === editingField.id 
          ? { ...field, ...updateData }
          : field
      ));
      
      setEditingField(null);
      onFieldsUpdated?.();
    } catch (error) {
      console.error('Failed to update field:', error);
    }
  };

  const handleCancelEdit = () => {
    setEditingField(null);
  };

  const handleVerifyField = async (field) => {
    try {
      await DocumentField.update(field.id, { is_verified: true });
      setFields(prev => prev.map(f => 
        f.id === field.id ? { ...f, is_verified: true } : f
      ));
      onFieldsUpdated?.();
    } catch (error) {
      console.error('Failed to verify field:', error);
    }
  };

  const getConfidenceColor = (score) => {
    if (score >= 0.8) return 'text-green-600 bg-green-50';
    if (score >= 0.6) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  const filteredFields = showUnverified 
    ? fields 
    : fields.filter(field => field.is_verified);

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-3">
            <RefreshCw className="w-5 h-5 animate-spin text-cyan-600" />
            <span>Loading extracted fields...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header Controls */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Extracted Fields</h3>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowUnverified(!showUnverified)}
            className="gap-2"
          >
            {showUnverified ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {showUnverified ? 'Hide Verified' : 'Show All'}
          </Button>
          <Badge variant="outline">
            {filteredFields.length} fields
          </Badge>
        </div>
      </div>

      {Object.keys(groupedFields).length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-700">No Fields Extracted</h3>
            <p className="text-sm text-gray-500 mt-1">
              This document hasn't been processed yet or no fields were found.
            </p>
          </CardContent>
        </Card>
      ) : (
        Object.entries(groupedFields).map(([category, categoryFields]) => {
          const categoryConfig = FIELD_CATEGORIES[category] || FIELD_CATEGORIES.policy_info;
          
          return (
            <Card key={category}>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <div className={`w-3 h-3 rounded-full bg-${categoryConfig.color}-500`}></div>
                  {categoryConfig.label}
                  <Badge variant="outline" className="ml-auto">
                    {categoryFields.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <AnimatePresence>
                  {categoryFields.map((field) => (
                    <motion.div
                      key={field.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className={`p-4 rounded-lg border ${
                        field.is_verified ? 'bg-green-50 border-green-200' : 'bg-white border-gray-200'
                      }`}
                    >
                      {editingField?.id === field.id ? (
                        <div className="space-y-3">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <label className="text-sm font-medium text-gray-700">Field Name</label>
                              <Input
                                value={editingField.field_name}
                                onChange={(e) => setEditingField({
                                  ...editingField,
                                  field_name: e.target.value
                                })}
                                className="mt-1"
                              />
                            </div>
                            <div>
                              <label className="text-sm font-medium text-gray-700">Field Type</label>
                              <Select
                                value={editingField.field_type}
                                onValueChange={(value) => setEditingField({
                                  ...editingField,
                                  field_type: value
                                })}
                              >
                                <SelectTrigger className="mt-1">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {FIELD_TYPES.map(type => (
                                    <SelectItem key={type.value} value={type.value}>
                                      {type.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          
                          <div>
                            <label className="text-sm font-medium text-gray-700">Field Value</label>
                            <Input
                              value={editingField.field_value}
                              onChange={(e) => setEditingField({
                                ...editingField,
                                field_value: e.target.value
                              })}
                              className="mt-1"
                            />
                          </div>

                          <div>
                            <label className="text-sm font-medium text-gray-700">Category</label>
                            <Select
                              value={editingField.field_category}
                              onValueChange={(value) => setEditingField({
                                ...editingField,
                                field_category: value
                              })}
                            >
                              <SelectTrigger className="mt-1">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {Object.entries(FIELD_CATEGORIES).map(([key, config]) => (
                                  <SelectItem key={key} value={key}>
                                    {config.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={handleSaveEdit}
                              className="gap-2"
                            >
                              <Save className="w-4 h-4" />
                              Save Changes
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={handleCancelEdit}
                              className="gap-2"
                            >
                              <X className="w-4 h-4" />
                              Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h4 className="font-medium text-gray-900">
                                {field.field_name}
                              </h4>
                              <Badge variant="outline" className="text-xs">
                                {field.field_type}
                              </Badge>
                              {field.confidence_score && (
                                <Badge 
                                  className={`text-xs ${getConfidenceColor(field.confidence_score)}`}
                                >
                                  {Math.round(field.confidence_score * 100)}% confident
                                </Badge>
                              )}
                              {field.is_verified && (
                                <Badge className="bg-green-100 text-green-800 text-xs">
                                  <Check className="w-3 h-3 mr-1" />
                                  Verified
                                </Badge>
                              )}
                              {field.user_corrected && (
                                <Badge className="bg-blue-100 text-blue-800 text-xs">
                                  User Edited
                                </Badge>
                              )}
                            </div>
                            <p className="text-gray-700 font-mono text-sm bg-gray-50 p-2 rounded">
                              {field.field_value}
                            </p>
                            {field.extraction_method && (
                              <p className="text-xs text-gray-500 mt-1">
                                Extracted via: {field.extraction_method}
                              </p>
                            )}
                          </div>
                          
                          <div className="flex gap-2 ml-4">
                            {!field.is_verified && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleVerifyField(field)}
                                className="gap-2"
                              >
                                <Check className="w-4 h-4" />
                                Verify
                              </Button>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleStartEdit(field)}
                              className="gap-2"
                            >
                              <Edit className="w-4 h-4" />
                              Edit
                            </Button>
                          </div>
                        </div>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </CardContent>
            </Card>
          );
        })
      )}
    </div>
  );
}