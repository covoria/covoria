import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Upload, 
  FileText, 
  Image, 
  CheckCircle, 
  Clock, 
  AlertTriangle,
  Search,
  Filter,
  Download,
  Trash2,
  Eye,
  RefreshCw,
  Plus,
  Brain
} from 'lucide-react';
import { Document } from '@/api/entities';
import { User } from '@/api/entities';
import { motion, AnimatePresence } from 'framer-motion';
import DocumentFieldEditor from './DocumentFieldEditor';
import { documentSyncEngine } from '@/api/functions';

const STATUS_CONFIG = {
  pending: { 
    label: 'Pending Upload', 
    icon: Clock, 
    color: 'yellow',
    description: 'Waiting to be processed'
  },
  uploading: { 
    label: 'Uploading', 
    icon: RefreshCw, 
    color: 'blue',
    description: 'File being uploaded'
  },
  encrypted: { 
    label: 'Encrypted', 
    icon: CheckCircle, 
    color: 'green',
    description: 'Securely stored'
  },
  analyzing: { 
    label: 'AI Processing', 
    icon: Brain, 
    color: 'purple',
    description: 'Extracting information'
  },
  completed: { 
    label: 'Processed', 
    icon: CheckCircle, 
    color: 'green',
    description: 'Ready for review'
  },
  failed: { 
    label: 'Failed', 
    icon: AlertTriangle, 
    color: 'red',
    description: 'Processing failed'
  },
  sync_failed: { 
    label: 'Sync Failed', 
    icon: AlertTriangle, 
    color: 'red',
    description: 'AI analysis failed'
  }
};

const DocumentStatusBadge = ({ status }) => {
  const config = STATUS_CONFIG[status] || STATUS_CONFIG.pending;
  const IconComponent = config.icon;
  
  return (
    <Badge className={`bg-${config.color}-100 text-${config.color}-800 border-${config.color}-200`}>
      <IconComponent className={`w-3 h-3 mr-1 ${status === 'uploading' || status === 'analyzing' ? 'animate-spin' : ''}`} />
      {config.label}
    </Badge>
  );
};

const DocumentCard = ({ document, onView, onDelete, onReprocess }) => {
  const statusConfig = STATUS_CONFIG[document.status] || STATUS_CONFIG.pending;
  
  const getFileIcon = (fileName) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    const imageTypes = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
    
    return imageTypes.includes(extension) ? Image : FileText;
  };

  const FileIcon = getFileIcon(document.file_name);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="group"
    >
      <Card className="covoria-card hover:shadow-lg transition-all duration-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className={`p-3 rounded-lg bg-${statusConfig.color}-100`}>
              <FileIcon className={`w-6 h-6 text-${statusConfig.color}-600`} />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-medium text-gray-900 truncate pr-2">
                  {document.file_name}
                </h3>
                <DocumentStatusBadge status={document.status} />
              </div>
              
              <p className="text-sm text-gray-500 mb-3">
                {statusConfig.description}
              </p>
              
              {document.analysis_summary && (
                <p className="text-sm text-gray-700 bg-gray-50 p-2 rounded mb-3 line-clamp-2">
                  {document.analysis_summary}
                </p>
              )}
              
              {document.ocr_confidence_score && (
                <div className="mb-3">
                  <Badge variant="outline" className="text-xs">
                    {Math.round(document.ocr_confidence_score * 100)}% extraction confidence
                  </Badge>
                </div>
              )}
              
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onView(document)}
                  className="gap-2"
                >
                  <Eye className="w-4 h-4" />
                  View Details
                </Button>
                
                {(document.status === 'failed' || document.status === 'sync_failed') && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onReprocess(document)}
                    className="gap-2 text-orange-600 border-orange-200 hover:bg-orange-50"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Retry
                  </Button>
                )}
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDelete(document)}
                  className="gap-2 text-red-600 border-red-200 hover:bg-red-50 ml-auto"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function EnhancedDocumentVault() {
  const [documents, setDocuments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUserAndDocuments();
  }, []);

  const loadUserAndDocuments = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      await loadDocuments(currentUser.email);
    } catch (error) {
      console.error('Failed to load user and documents:', error);
    }
  };

  const loadDocuments = useCallback(async (userEmail) => {
    setIsLoading(true);
    try {
      const userDocuments = await Document.filter({ user_email: userEmail }, '-created_date');
      setDocuments(Array.isArray(userDocuments) ? userDocuments : []);
    } catch (error) {
      console.error('Failed to load documents:', error);
      setDocuments([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleFileUpload = async (event) => {
    const files = Array.from(event.target.files);
    if (files.length === 0) return;

    setIsUploading(true);

    try {
      for (const file of files) {
        // Create document record
        const newDocument = await Document.create({
          file_name: file.name,
          user_email: user.email,
          status: 'pending',
          upload_source: 'web_upload'
        });

        // Convert file to base64
        const reader = new FileReader();
        reader.onload = async (e) => {
          const base64Data = e.target.result.split(',')[1];
          
          try {
            // Trigger document sync engine
            await documentSyncEngine({
              action: 'upload',
              document_id: newDocument.id,
              file_content_base64: base64Data
            });
          } catch (syncError) {
            console.error('Document sync failed:', syncError);
          }
        };
        reader.readAsDataURL(file);
      }

      // Reload documents after upload
      setTimeout(() => {
        loadDocuments(user.email);
      }, 1000);

    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteDocument = async (document) => {
    if (!confirm(`Are you sure you want to delete "${document.file_name}"? This action cannot be undone.`)) {
      return;
    }

    try {
      // Trigger cleanup via sync engine
      await documentSyncEngine({
        action: 'delete',
        document_id: document.id
      });

      // Delete the document record
      await Document.delete(document.id);
      
      // Remove from state
      setDocuments(prev => prev.filter(d => d.id !== document.id));
      
      if (selectedDocument?.id === document.id) {
        setSelectedDocument(null);
      }
      
    } catch (error) {
      console.error('Failed to delete document:', error);
    }
  };

  const handleReprocessDocument = async (document) => {
    try {
      // Trigger reprocessing via sync engine
      await documentSyncEngine({
        action: 'reanalyze',
        document_id: document.id
      });

      // Update document status
      setDocuments(prev => prev.map(d => 
        d.id === document.id 
          ? { ...d, status: 'analyzing', analysis_summary: 'Reprocessing document...' }
          : d
      ));

      // Reload after delay
      setTimeout(() => {
        loadDocuments(user.email);
      }, 2000);

    } catch (error) {
      console.error('Failed to reprocess document:', error);
    }
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.file_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (doc.analysis_summary && doc.analysis_summary.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || doc.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusCounts = documents.reduce((acc, doc) => {
    acc[doc.status] = (acc[doc.status] || 0) + 1;
    return acc;
  }, {});

  if (selectedDocument) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            onClick={() => setSelectedDocument(null)}
            className="gap-2"
          >
            ← Back to Vault
          </Button>
          <h2 className="text-xl font-semibold">{selectedDocument.file_name}</h2>
          <DocumentStatusBadge status={selectedDocument.status} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Document Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-600">File Name</label>
                <p className="font-mono text-sm bg-gray-50 p-2 rounded mt-1">
                  {selectedDocument.file_name}
                </p>
              </div>
              
              {selectedDocument.analysis_summary && (
                <div>
                  <label className="text-sm font-medium text-gray-600">AI Summary</label>
                  <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded mt-1">
                    {selectedDocument.analysis_summary}
                  </p>
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Upload Source</label>
                  <p className="text-sm mt-1 capitalize">{selectedDocument.upload_source || 'web_upload'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Created</label>
                  <p className="text-sm mt-1">
                    {new Date(selectedDocument.created_date).toLocaleDateString()}
                  </p>
                </div>
              </div>

              {selectedDocument.ocr_confidence_score && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Extraction Confidence</label>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${selectedDocument.ocr_confidence_score * 100}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium">
                      {Math.round(selectedDocument.ocr_confidence_score * 100)}%
                    </span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <div>
            <DocumentFieldEditor 
              documentId={selectedDocument.id}
              onFieldsUpdated={() => {
                // Optionally refresh document data
              }}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Document Vault</h1>
          <p className="text-gray-600 mt-1">
            Securely store and analyze your insurance documents with AI-powered insights
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <input
            type="file"
            multiple
            accept=".pdf,.png,.jpg,.jpeg"
            onChange={handleFileUpload}
            className="hidden"
            id="file-upload"
            disabled={isUploading}
          />
          <label htmlFor="file-upload">
            <Button
              className="covoria-gradient text-white gap-2"
              disabled={isUploading}
              asChild
            >
              <span>
                {isUploading ? (
                  <RefreshCw className="w-5 h-5 animate-spin" />
                ) : (
                  <Plus className="w-5 h-5" />
                )}
                {isUploading ? 'Uploading...' : 'Upload Documents'}
              </span>
            </Button>
          </label>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search documents..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-gray-500" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">All Status ({documents.length})</option>
            {Object.entries(statusCounts).map(([status, count]) => (
              <option key={status} value={status}>
                {STATUS_CONFIG[status]?.label || status} ({count})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Documents Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    <div className="h-8 bg-gray-200 rounded"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredDocuments.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <Upload className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              {documents.length === 0 ? 'No Documents Yet' : 'No Documents Found'}
            </h3>
            <p className="text-gray-500 mb-6">
              {documents.length === 0 
                ? 'Upload your first insurance document to get started with AI-powered analysis'
                : 'Try adjusting your search or filter criteria'
              }
            </p>
            {documents.length === 0 && (
              <label htmlFor="file-upload">
                <Button className="covoria-gradient text-white gap-2" asChild>
                  <span>
                    <Upload className="w-5 h-5" />
                    Upload Your First Document
                  </span>
                </Button>
              </label>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence>
            {filteredDocuments.map(document => (
              <DocumentCard
                key={document.id}
                document={document}
                onView={setSelectedDocument}
                onDelete={handleDeleteDocument}
                onReprocess={handleReprocessDocument}
              />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}