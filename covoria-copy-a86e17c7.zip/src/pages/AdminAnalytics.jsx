import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { User, Server, FileText, Activity } from 'lucide-react';
import { User as UserEntity } from '@/api/entities';
import { LLMUsageLog } from '@/api/entities';
import { Document } from '@/api/entities';

const StatCard = ({ title, value, icon: Icon, description }) => (
    <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            <Icon className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{value}</div>
            <p className="text-xs text-muted-foreground">{description}</p>
        </CardContent>
    </Card>
);

export default function AdminAnalytics() {
    const [stats, setStats] = useState(null);
    const [llmUsage, setLlmUsage] = useState([]);
    const [docStatusData, setDocStatusData] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isAuthorized, setIsAuthorized] = useState(false);

    useEffect(() => {
        const checkAuthAndLoadData = async () => {
            try {
                const user = await UserEntity.me();
                if (user && user.role === 'admin') {
                    setIsAuthorized(true);
                    loadData();
                } else {
                    setIsAuthorized(false);
                    setIsLoading(false);
                }
            } catch (error) {
                setIsAuthorized(false);
                setIsLoading(false);
            }
        };
        checkAuthAndLoadData();
    }, []);

    const loadData = async () => {
        setIsLoading(true);
        try {
            const [users, llmLogs, documents] = await Promise.all([
                UserEntity.list(),
                LLMUsageLog.list('-created_date', 100),
                Document.list()
            ]);

            // Process stats
            const successfulParses = documents.filter(d => d.status === 'completed').length;
            const totalDocs = documents.length;
            const successRate = totalDocs > 0 ? ((successfulParses / totalDocs) * 100).toFixed(1) : 0;
            const avgProcessingTime = llmLogs.length > 0 ? (llmLogs.reduce((acc, log) => acc + (log.processing_time_ms || 0), 0) / llmLogs.length).toFixed(0) : 0;

            setStats({
                totalUsers: users.length,
                totalDocs,
                successRate: `${successRate}%`,
                avgProcessingTime: `${avgProcessingTime}ms`
            });

            // Process doc status chart
            const statusCounts = documents.reduce((acc, doc) => {
                acc[doc.status] = (acc[doc.status] || 0) + 1;
                return acc;
            }, {});
            setDocStatusData(Object.entries(statusCounts).map(([name, value]) => ({ name, count: value })));

            // Process LLM usage chart
            setLlmUsage(llmLogs.map(log => ({ 
                date: new Date(log.created_date).toLocaleDateString(), 
                time: log.processing_time_ms 
            })).reverse());

        } catch (error) {
            console.error("Failed to load admin analytics:", error);
        }
        setIsLoading(false);
    };
    
    if (isLoading) {
        return <div className="p-8 text-center">Loading Admin Dashboard...</div>;
    }

    if (!isAuthorized) {
        return (
            <div className="p-8 text-center text-red-600">
                <h1 className="text-2xl font-bold">Access Denied</h1>
                <p>You do not have permission to view this page.</p>
            </div>
        );
    }

    return (
        <div className="p-4 sm:p-6 lg:p-8 space-y-6">
            <h1 className="text-3xl font-bold">Admin Analytics Dashboard</h1>
            
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <StatCard title="Total Users" value={stats.totalUsers} icon={User} description="Total registered users" />
                <StatCard title="Total Documents" value={stats.totalDocs} icon={FileText} description="Total documents uploaded" />
                <StatCard title="Parse Success Rate" value={stats.successRate} icon={Server} description="Successful document analyses" />
                <StatCard title="Avg. AI Response Time" value={stats.avgProcessingTime} icon={Activity} description="Average processing time" />
            </div>

            <div className="grid gap-6 md:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle>Document Status Overview</CardTitle>
                        <CardDescription>Distribution of documents by processing status.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={docStatusData}>
                                <XAxis dataKey="name" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="count" fill="#22d3ee" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>AI Processing Time (ms)</CardTitle>
                        <CardDescription>Recent AI processing times.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={llmUsage}>
                                <XAxis dataKey="date" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="time" stroke="#8884d8" />
                            </LineChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}