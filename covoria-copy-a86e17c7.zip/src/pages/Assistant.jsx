
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  MessageCircle,
  Send,
  Brain,
  User,
  Copy,
  RotateCcw,
  Lightbulb,
  ThumbsUp,
  ThumbsDown,
  TrendingUp,
  Shield,
  AlertCircle
} from 'lucide-react';
import { User as UserEntity } from '@/api/entities';
import { InsurancePolicy } from '@/api/entities';
import { SavingsAccount } from '@/api/entities';
import { Insight } from '@/api/entities';
import { AssistantConversation } from '@/api/entities';
import { AIFeedback }
 from '@/api/entities';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ReactMarkdown from 'react-markdown';
import { chatGPTWithRAG } from '@/api/functions';

// Enhanced quick action suggestions with better targeting
const ENHANCED_QUICK_ACTIONS = [
  {
    icon: TrendingUp,
    label: 'Compare my costs',
    prompt: 'Am I overpaying for insurance compared to others in my state and age group? Show me specific numbers.'
  },
  {
    icon: Shield,
    label: 'Find coverage gaps',
    prompt: 'What critical insurance coverage am I missing based on my age, income, and dependents?'
  },
  {
    icon: Brain,
    label: 'Summarize my risks',
    prompt: 'Based on my complete financial profile, what are my top 3 financial weaknesses or risks? Summarize them clearly for me.'
  }
];

export default function AssistantPage() {
  const [user, setUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const [sessionId] = useState(`session_${Date.now()}`);

  // EXACT new welcome message as requested
  const empatheticGreeting = `
Welcome to Covoria — your smart insurance companion.

No pushy sales. No confusion. Just clear, helpful info when you need it.

Ask anything — or let me suggest what matters most.
`;

  const initializeAssistant = async () => {
    try {
      const currentUser = await UserEntity.me();
      setUser(currentUser);

      const welcomeMessage = {
        id: `welcome_${Date.now()}`,
        sender: 'assistant',
        content: empatheticGreeting, // Using the new, shorter message
        feedback: null,
      };
      setMessages([welcomeMessage]);

    } catch (error) {
      console.error('Failed to initialize assistant:', error);
      setError("Failed to load user data. Some features might be limited.");
      const welcomeMessage = {
        id: `welcome_${Date.now()}`,
        sender: 'assistant',
        content: empatheticGreeting, // Also using the new message in case of error
        confidence: 0.5,
        feedback: null,
      };
      setMessages([welcomeMessage]);
    }
  };

  useEffect(() => {
    initializeAssistant();
  }, []);

  useEffect(() => {
    // Automatically refresh context when page is focused
    const handleFocus = () => {
        // This is a lightweight way to ensure context is fresh
        // In a more complex app, we might use websockets or a global state manager
        console.log("Assistant page focused, considering context refresh.");
    };
    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, []);

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const promptFromUrl = searchParams.get('prompt');
    if (promptFromUrl && user && !isLoading) {
      handleSend(decodeURIComponent(promptFromUrl));
      navigate(createPageUrl('Assistant'), { replace: true });
    }
  }, [location.search, user, isLoading]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const resetAssistant = () => {
    setMessages([]);
    setInput('');
    setIsLoading(false);
    setError(null);
    initializeAssistant();
  };

  const handleSend = async (predefinedPrompt) => {
    const userMessageContent = predefinedPrompt || input;
    if (!userMessageContent.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);

    const userMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      content: userMessageContent,
    };
    setMessages(prev => [...prev, userMessage]);
    setInput('');

    console.log('[Assistant] Calling chatGPTWithRAG with message:', userMessageContent);

    try {
      // Call the RAG-enabled function
      const response = await chatGPTWithRAG({ message: userMessageContent });
      
      console.log('[Assistant] chatGPTWithRAG response:', response);

      if (response && response.data && response.data.success) {
        const assistantMessage = {
          id: `assistant-${Date.now()}`,
          sender: 'assistant',
          content: response.data.response,
          feedback: null,
          source: response.data.source || 'Knowledge Base'
        };

        setMessages(prev => [...prev, assistantMessage]);
        console.log('[Assistant] Assistant message added successfully');
      } else {
        console.error('[Assistant] Invalid response structure:', response);
        throw new Error(response?.data?.error || response?.data?.details || 'The assistant returned an invalid response.');
      }

    } catch (err) {
      console.error('[Assistant] ChatGPT function failed:', err);

      // Extract a more user-friendly error message
      let displayError = "I'm having technical difficulties right now. Please try again later.";
      if (err.message && err.message.toLowerCase().includes('quota')) {
        displayError = "There seems to be an issue with the API quota. Please check the account's billing details.";
      } else if (err.message) {
        displayError = `An error occurred: ${err.message}`;
      }

      const errorMessage = {
        id: `error-${Date.now()}`,
        sender: 'system',
        content: displayError,
      };
      setMessages(prev => [...prev, errorMessage]);
      setError(displayError);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFeedback = async (messageId, feedbackType) => {
    const messageIndex = messages.findIndex(m => m.id === messageId);
    if (messageIndex === -1 || messages[messageIndex].feedback) return;

    const updatedMessages = messages.map(msg =>
        msg.id === messageId ? { ...msg, feedback: feedbackType } : msg
    );
    setMessages(updatedMessages);

    try {
        const message = updatedMessages[messageIndex];
        const userMessage = messages[messageIndex - 1]?.sender === 'user' ? messages[messageIndex - 1] : null;

        await AIFeedback.create({
            conversation_id: message.id,
            user_email: user?.email,
            feedback_type: feedbackType === 'helpful' ? 'thumbs_up' : 'thumbs_down',
            ai_response_text: message.content,
            user_message_text: userMessage?.content || 'N/A',
            page_context: 'Assistant',
            session_id: sessionId,
            confidence_score: message.confidence,
        });
    } catch (feedbackError) {
        console.error("Failed to save feedback:", feedbackError);
        const revertedMessages = messages.map(msg =>
            msg.id === messageId ? { ...msg, feedback: null } : msg
        );
        setMessages(revertedMessages);
        setError("Failed to record feedback. Please try again later.");
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyMessage = (content) => {
    navigator.clipboard.writeText(content);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <div className="w-full h-screen flex flex-col px-4 py-6">
        <div className="flex items-center justify-center gap-3 mb-6 text-center">
          <div className="bg-gradient-to-r from-cyan-500 to-blue-600 p-2 rounded-full">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-semibold tracking-tight text-white">
              Covoria Insurance Advisor
            </h1>
            <p className="text-xs text-slate-300 mt-1">🤖 Powered by GPT-4 + Knowledge Base</p>
          </div>
        </div>

        <Card className="bg-slate-900 border-slate-700 flex-1 flex flex-col w-full">
          <CardHeader className="flex flex-row items-center justify-between bg-gradient-to-r from-cyan-600 to-blue-700 text-white rounded-t-lg p-4 flex-shrink-0">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold">
              <MessageCircle className="w-5 h-5" />
              AI Conversation
            </CardTitle>
            <div className="flex gap-2">
              <Button
                onClick={resetAssistant}
                size="sm"
                variant="ghost"
                className="text-xs text-white hover:text-white hover:bg-white/20"
              >
                <RotateCcw className="w-3 h-3 mr-1" />
                Reset
              </Button>
            </div>
          </CardHeader>

          <CardContent className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
            <AnimatePresence>
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: "easeOut" }}
                  className={`flex gap-3 w-full ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex gap-3 max-w-prose w-full ${message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    {/* Message bubble */}
                    <div className={`rounded-xl p-4 shadow-md w-full ${
                      message.sender === 'user' ? 'bg-blue-600 text-white' :
                      message.sender === 'system' ? 'bg-yellow-800/30 text-yellow-300 border border-yellow-700' :
                      'bg-slate-700 text-slate-200'
                    }`}>
                      {message.sender === 'system' ? (
                        <div className="flex items-center gap-2">
                          <AlertCircle className="w-5 h-5 text-yellow-500 flex-shrink-0" />
                          <p className="font-medium">{message.content}</p>
                        </div>
                      ) : (
                        <>
                          <ReactMarkdown className="prose prose-sm max-w-none prose-p:my-2 prose-ul:my-2 prose-li:my-1 prose-invert break-words">
                            {message.content}
                          </ReactMarkdown>
                        </>
                      )}

                      {/* Feedback buttons */}
                      <AnimatePresence>
                        {message.sender === 'assistant' && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            transition={{ delay: 0.3 }}
                            className="flex items-center justify-between mt-3 pt-2 border-t border-slate-600"
                          >
                            <div className="text-xs text-slate-400">Did this help?</div>
                            <div className="flex items-center gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleFeedback(message.id, 'helpful')}
                                className="h-7 w-7"
                                disabled={!!message.feedback}
                                title="This was helpful"
                              >
                                <ThumbsUp className={`w-4 h-4 transition-colors ${message.feedback === 'helpful' ? 'text-green-500' : 'text-slate-400 hover:text-green-500'}`} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleFeedback(message.id, 'unhelpful')}
                                className="h-7 w-7"
                                disabled={!!message.feedback}
                                title="This was not helpful"
                              >
                                <ThumbsDown className={`w-4 h-4 transition-colors ${message.feedback === 'unhelpful' ? 'text-red-500' : 'text-slate-400 hover:text-red-500'}`} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => copyMessage(message.content)}
                                className="h-7 w-7 text-slate-400 hover:text-white"
                                title="Copy message"
                              >
                                <Copy className="w-4 h-4" />
                              </Button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Loading state */}
            {isLoading && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 max-w-[90%]">
                  <div className="flex items-center gap-2" title="Covoria is analyzing your policies for ways to help you save, optimize and protect your future.">
                    <div className="flex gap-1.5">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></div>
                      <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></div>
                    </div>
                    <span className="text-sm text-slate-400">Thinking...</span>
                  </div>
                </div>
              </motion.div>
            )}

            <div ref={messagesEndRef} />
          </CardContent>

          {/* Input area */}
          <div className="p-4 border-t border-slate-700 bg-slate-800/80">
            {messages.length <= 2 && !isLoading && (
              <div className="grid grid-cols-1 gap-2 mb-3">
                {ENHANCED_QUICK_ACTIONS.map((action) => (
                  <Button
                    key={action.label}
                    variant="outline"
                    className="h-auto p-3 justify-start text-left text-xs bg-slate-800/50 border-slate-700 hover:bg-slate-700 text-slate-300 hover:text-white w-full"
                    onClick={() => handleSend(action.prompt)}
                    disabled={isLoading}
                  >
                    <action.icon className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span className="text-sm">{action.label}</span>
                  </Button>
                ))}
              </div>
            )}
            <div className="flex gap-3 w-full">
              <div className="relative flex-1">
                <Textarea
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyPress}
                  placeholder="Ask anything - Covoria remembers and improves..."
                  className="w-full bg-slate-800 text-slate-100 placeholder-slate-400 border border-slate-600 rounded-lg px-3 py-2 resize-none"
                  rows={2}
                  disabled={isLoading}
                  maxLength={500}
                />
                <div className="absolute bottom-1 right-1 text-xs text-slate-500">
                  🧠 Learning enabled
                </div>
              </div>
              <Button
                onClick={() => handleSend()}
                disabled={!input.trim() || isLoading}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 px-4 flex-shrink-0"
              >
                {isLoading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
