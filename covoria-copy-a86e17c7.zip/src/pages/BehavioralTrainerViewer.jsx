import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Brain, ChevronLeft, ChevronRight, AlertTriangle, RefreshCw } from 'lucide-react';
import { AdvisorBehaviorTrainingSet_v1 } from '@/api/entities';
import { AdvisorBehaviorTrainingSet_v2 } from '@/api/entities/AdvisorBehaviorTrainingSet_v2';

const ITEMS_PER_PAGE = 20;

const DataViewer = ({ fetchData, entityName }) => {
    const [entries, setEntries] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [filters, setFilters] = useState({
        insurance_type: 'all',
        persona: 'all',
        coverage_domain: 'all'
    });
    const [currentPage, setCurrentPage] = useState(1);

    const loadData = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const data = await fetchData();
            setEntries(data || []);
        } catch (err) {
            setError(err.message);
            setEntries([]);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        loadData();
    }, [fetchData]);

    const filteredEntries = useMemo(() => {
        return entries.filter(entry => {
            const searchMatch = !searchTerm || 
                (entry.question && entry.question.toLowerCase().includes(searchTerm.toLowerCase())) ||
                (entry.ideal_response && entry.ideal_response.toLowerCase().includes(searchTerm.toLowerCase())) ||
                (entry.tags && entry.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())));

            const typeMatch = filters.insurance_type === 'all' || entry.insurance_type === filters.insurance_type;
            const personaMatch = filters.persona === 'all' || entry.persona === filters.persona;
            const domainMatch = filters.coverage_domain === 'all' || entry.coverage_domain === filters.coverage_domain;

            return searchMatch && typeMatch && personaMatch && domainMatch;
        });
    }, [entries, searchTerm, filters]);

    const uniqueValues = (key) => ['all', ...Array.from(new Set(entries.map(e => e[key]).filter(Boolean)))];
    
    const paginatedEntries = filteredEntries.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);
    const totalPages = Math.ceil(filteredEntries.length / ITEMS_PER_PAGE);

    if (error) {
        return <div className="text-center py-10 text-red-400"><AlertTriangle className="mx-auto h-8 w-8 mb-2" />Failed to load data: {error}</div>;
    }

    return (
        <div>
            <Card className="bg-slate-800/50 border-slate-700 mb-4 sticky top-0 z-10">
                <CardContent className="p-4 space-y-3">
                    <div className="flex gap-2">
                        <Input placeholder="Search questions, responses, or tags for gibberish..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="bg-slate-800 border-slate-700"/>
                        <Button onClick={loadData} variant="outline" size="icon" className="flex-shrink-0" disabled={isLoading}><RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} /></Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <Select onValueChange={v => setFilters(f => ({...f, insurance_type: v}))}><SelectTrigger className="bg-slate-800 border-slate-700"><SelectValue placeholder="Filter by Type" /></SelectTrigger><SelectContent>{uniqueValues('insurance_type').map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent></Select>
                        <Select onValueChange={v => setFilters(f => ({...f, persona: v}))}><SelectTrigger className="bg-slate-800 border-slate-700"><SelectValue placeholder="Filter by Persona" /></SelectTrigger><SelectContent>{uniqueValues('persona').map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent></Select>
                        <Select onValueChange={v => setFilters(f => ({...f, coverage_domain: v}))}><SelectTrigger className="bg-slate-800 border-slate-700"><SelectValue placeholder="Filter by Domain" /></SelectTrigger><SelectContent>{uniqueValues('coverage_domain').map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent></Select>
                    </div>
                </CardContent>
            </Card>
            
            <p className="text-sm text-slate-400 mb-4">Showing {paginatedEntries.length} of {filteredEntries.length} matching entries.</p>

            {isLoading ? (
                 <div className="space-y-4">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-24 w-full bg-slate-700" />)}</div>
            ) : (
                <div className="space-y-4">
                    {paginatedEntries.map(entry => (
                        <Card key={entry.id} className="bg-slate-800 border border-slate-700">
                            <CardHeader><CardTitle className="text-sm font-normal text-slate-300">{entry.question || "No Question"}</CardTitle></CardHeader>
                            <CardContent>
                                <p className={`text-sm mb-3 ${/finally wear each five|reflect shoulder every/i.test(entry.ideal_response) ? 'text-red-400 bg-red-900/50 p-2 rounded' : 'text-cyan-300'}`}>
                                    {entry.ideal_response || "No Response"}
                                </p>
                                <div className="flex flex-wrap gap-2 text-xs">
                                    <Badge variant="outline">ID: {entry.id}</Badge>
                                    {entry.tags?.map(t => <Badge key={t} variant="secondary">{t}</Badge>)}
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}

            <div className="flex justify-between items-center mt-6">
                <Button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}><ChevronLeft className="w-4 h-4 mr-1"/> Previous</Button>
                <span className="text-sm text-slate-400">Page {currentPage} of {totalPages}</span>
                <Button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages || totalPages === 0}>Next <ChevronRight className="w-4 h-4 ml-1"/></Button>
            </div>
        </div>
    );
}


export default function BehavioralTrainerViewer() {
    return (
        <div className="p-4 md:p-6 min-h-screen">
            <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-xl">
                    <Brain className="w-8 h-8 text-white" />
                </div>
                <div>
                    <h1 className="text-3xl font-bold text-white">Behavioral Training Data Viewer</h1>
                    <p className="text-slate-400">Inspect the live training data. Use search to find gibberish.</p>
                </div>
            </div>

            <Tabs defaultValue="v1" className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-slate-800">
                    <TabsTrigger value="v1">Training Set v1</TabsTrigger>
                    <TabsTrigger value="v2">Training Set v2</TabsTrigger>
                </TabsList>
                <TabsContent value="v1" className="mt-4">
                    <DataViewer fetchData={() => AdvisorBehaviorTrainingSet_v1.list()} entityName="v1" />
                </TabsContent>
                <TabsContent value="v2" className="mt-4">
                    <DataViewer fetchData={() => AdvisorBehaviorTrainingSet_v2.list()} entityName="v2" />
                </TabsContent>
            </Tabs>
        </div>
    );
}