import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { AdvisorBehaviorTrainingSet_v1 } from '@/api/entities';
import { Loader2, Play, AlertTriangle, CheckCircle } from 'lucide-react';

export default function DebugTrainingData() {
  const [query, setQuery] = useState("What happens if I miss a payment on my health insurance?");
  const [result, setResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Exact copy of the calculateMatchScore function
  const calculateMatchScore = (userQuery, trainingQuestion) => {
    if (!userQuery || !trainingQuestion || typeof userQuery !== 'string' || typeof trainingQuestion !== 'string') {
      return 0;
    }
    const userWords = new Set(userQuery.toLowerCase().split(/\s+/).filter(w => w.length > 2));
    const questionWords = new Set(trainingQuestion.toLowerCase().split(/\s+/).filter(w => w.length > 2));
    if (userWords.size === 0 || questionWords.size === 0) return 0;

    const intersection = new Set([...userWords].filter(x => questionWords.has(x)));
    const union = new Set([...userWords, ...questionWords]);
    return intersection.size / union.size;
  };

  // Exact copy of extractUserContext function
  const extractUserContext = (message) => {
    const lowerMessage = message.toLowerCase();
    const context = {};
    if (lowerMessage.includes('health')) context.insurance_type = 'health';
    else if (lowerMessage.includes('auto') || lowerMessage.includes('car')) context.insurance_type = 'auto';
    else if (lowerMessage.includes('life')) context.insurance_type = 'life';
    else if (lowerMessage.includes('home')) context.insurance_type = 'home';
    return context;
  };

  const runDebug = async () => {
    setIsLoading(true);
    setResult(null);

    try {
      const debugSteps = [];
      
      // Step 1: Extract context
      const context = extractUserContext(query);
      debugSteps.push({
        step: 1,
        name: "Extract Context",
        status: "success",
        data: context
      });

      // Step 2: Build filter query
      const filterQuery = {};
      if (context.insurance_type) {
        filterQuery.insurance_type = context.insurance_type;
      }
      filterQuery.persona = "general";
      debugSteps.push({
        step: 2,
        name: "Build Filter Query",
        status: "success",
        data: filterQuery
      });

      // Step 3: Query database
      const entries = await AdvisorBehaviorTrainingSet_v1.filter(filterQuery, '-created_date', 1000);
      debugSteps.push({
        step: 3,
        name: "Query Database",
        status: entries.length > 0 ? "success" : "warning",
        data: { entriesFound: entries.length, entries: entries.slice(0, 3) }
      });

      if (entries.length === 0) {
        setResult({ success: false, steps: debugSteps, error: "No entries found after filtering" });
        return;
      }

      // Step 4: Bulletproofing
      const validEntries = entries.filter(entry => 
        entry.question && entry.ideal_response && entry.ideal_response.length > 20
      );
      debugSteps.push({
        step: 4,
        name: "Bulletproofing",
        status: validEntries.length > 0 ? "success" : "error",
        data: { 
          totalEntries: entries.length,
          validEntries: validEntries.length,
          invalidReasons: entries.filter(e => !e.question || !e.ideal_response || e.ideal_response.length <= 20).map(e => ({
            id: e.id,
            hasQuestion: !!e.question,
            hasResponse: !!e.ideal_response,
            responseLength: e.ideal_response?.length || 0
          }))
        }
      });

      if (validEntries.length === 0) {
        setResult({ success: false, steps: debugSteps, error: "No valid entries after bulletproofing" });
        return;
      }

      // Step 5: Calculate match scores
      const scoredMatches = validEntries.map(entry => {
        const score = calculateMatchScore(query, entry.question);
        return { entry, score };
      }).sort((a, b) => b.score - a.score);

      debugSteps.push({
        step: 5,
        name: "Calculate Match Scores",
        status: "success",
        data: { 
          totalMatches: scoredMatches.length,
          topMatches: scoredMatches.slice(0, 5).map(m => ({
            question: m.entry.question,
            score: m.score.toFixed(3),
            responseLength: m.entry.ideal_response?.length || 0
          }))
        }
      });

      // Step 6: Check threshold
      const bestMatch = scoredMatches[0];
      const threshold = 0.3; // Current threshold
      const passesThreshold = bestMatch && bestMatch.score > threshold;

      debugSteps.push({
        step: 6,
        name: "Check Threshold",
        status: passesThreshold ? "success" : "error",
        data: {
          bestScore: bestMatch?.score || 0,
          threshold: threshold,
          passesThreshold: passesThreshold,
          bestMatch: bestMatch ? {
            question: bestMatch.entry.question,
            responsePreview: bestMatch.entry.ideal_response?.substring(0, 200) + "...",
            fullResponseLength: bestMatch.entry.ideal_response?.length || 0
          } : null
        }
      });

      setResult({
        success: passesThreshold,
        steps: debugSteps,
        finalResult: passesThreshold ? {
          response: bestMatch.entry.ideal_response,
          source: 'behavioral_training_v1',
          confidence: bestMatch.score
        } : null
      });

    } catch (error) {
      setResult({
        success: false,
        error: error.message,
        steps: []
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 min-h-screen bg-slate-900">
      <Card className="bg-slate-800 border-slate-700 mb-6">
        <CardHeader>
          <CardTitle className="text-white">Debug Training Data Logic</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-slate-300 text-sm mb-2 block">Test Query:</label>
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
              placeholder="Enter your test query..."
            />
          </div>
          <Button 
            onClick={runDebug} 
            disabled={isLoading || !query.trim()}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            Run Debug
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className={`text-white flex items-center gap-2 ${result.success ? 'text-green-400' : 'text-red-400'}`}>
              {result.success ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
              Debug Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {result.steps?.map((step) => (
              <div key={step.step} className="border border-slate-600 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-slate-400 font-mono">Step {step.step}:</span>
                  <span className="text-white font-semibold">{step.name}</span>
                  <span className={`px-2 py-1 rounded text-xs ${
                    step.status === 'success' ? 'bg-green-600 text-white' :
                    step.status === 'warning' ? 'bg-yellow-600 text-white' :
                    'bg-red-600 text-white'
                  }`}>
                    {step.status}
                  </span>
                </div>
                <pre className="bg-slate-900 p-3 rounded text-sm text-slate-300 overflow-x-auto">
                  {JSON.stringify(step.data, null, 2)}
                </pre>
              </div>
            ))}

            {result.error && (
              <div className="bg-red-900/30 border border-red-700 rounded-lg p-4">
                <h3 className="text-red-400 font-bold mb-2">Error:</h3>
                <p className="text-red-300">{result.error}</p>
              </div>
            )}

            {result.finalResult && (
              <div className="bg-green-900/30 border border-green-700 rounded-lg p-4">
                <h3 className="text-green-400 font-bold mb-2">Final Result:</h3>
                <div className="space-y-2">
                  <p><span className="text-slate-300">Source:</span> <span className="text-white">{result.finalResult.source}</span></p>
                  <p><span className="text-slate-300">Confidence:</span> <span className="text-white">{result.finalResult.confidence.toFixed(3)}</span></p>
                  <div>
                    <span className="text-slate-300">Response:</span>
                    <div className="bg-slate-900 p-3 rounded mt-2 text-slate-200 max-h-48 overflow-y-auto">
                      {result.finalResult.response}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}