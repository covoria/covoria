import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Product } from '@/api/entities';
import { Plus, Search, FileText } from 'lucide-react';
import ProductCard from '../components/catalog/ProductCard';
import AddProductDialog from '../components/catalog/AddProductDialog';

export default function ProductCatalog() {
    const [products, setProducts] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [isDialogOpen, setIsDialogOpen] = useState(false);

    useEffect(() => {
        loadProducts();
    }, []);

    const loadProducts = async () => {
        setIsLoading(true);
        try {
            const data = await Product.list();
            setProducts(data);
        } catch (error) {
            console.error('Failed to load products:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const filteredProducts = products.filter(p =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="p-4 md:p-6">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold text-white">Product Catalog</h1>
                <Button onClick={() => setIsDialogOpen(true)} className="bg-zinc-200 text-zinc-900 hover:bg-zinc-300">
                    <Plus className="mr-2 h-4 w-4" /> Add Product
                </Button>
            </div>
            {/* Search bar can be added here if needed */}

            {isLoading ? (
                <p className="text-slate-400">Loading products...</p>
            ) : filteredProducts.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredProducts.map(product => (
                        <ProductCard key={product.id} product={product} />
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 border border-dashed border-slate-700 rounded-lg">
                    <FileText className="mx-auto h-12 w-12 text-slate-500" />
                    <h3 className="mt-2 text-sm font-medium text-slate-300">No products yet</h3>
                    <p className="mt-1 text-sm text-slate-500">Add the first product to the catalog.</p>
                </div>
            )}

            {isDialogOpen && (
                <AddProductDialog
                    isOpen={isDialogOpen}
                    onClose={() => setIsDialogOpen(false)}
                    onProductAdded={loadProducts}
                />
            )}
        </div>
    );
}