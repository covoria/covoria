import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AdvisorBehaviorTrainingSet_v1 } from '@/api/entities';
import { Search, Database, AlertCircle } from 'lucide-react';

export default function QuickDatabaseCheck() {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const checkDatabase = async () => {
    setIsLoading(true);
    try {
      console.log('Checking database...');
      
      // Get all records
      const allRecords = await AdvisorBehaviorTrainingSet_v1.list('-created_date', 100);
      
      // Check for health insurance records specifically
      const healthRecords = allRecords.filter(record => 
        record.insurance_type === 'health' || 
        record.question?.toLowerCase().includes('health insurance')
      );
      
      // Check for payment/miss payment records
      const paymentRecords = allRecords.filter(record => 
        record.question?.toLowerCase().includes('payment') ||
        record.question?.toLowerCase().includes('miss') ||
        record.question?.toLowerCase().includes('premium')
      );
      
      // Check persona distribution
      const personaStats = {};
      allRecords.forEach(record => {
        const persona = record.persona || 'null';
        personaStats[persona] = (personaStats[persona] || 0) + 1;
      });
      
      setData({
        totalRecords: allRecords.length,
        healthRecords: healthRecords.length,
        paymentRecords: paymentRecords.length,
        personaStats,
        sampleHealthRecord: healthRecords[0] || null,
        samplePaymentRecord: paymentRecords[0] || null,
        lastUpdated: allRecords[0]?.updated_date || 'N/A'
      });
      
    } catch (error) {
      console.error('Database check failed:', error);
      setData({ error: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkDatabase();
  }, []);

  return (
    <div className="p-6 min-h-screen bg-slate-900">
      <Card className="bg-slate-800 border-slate-700 mb-6">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Database className="w-6 h-6" />
            Quick Database Check - AdvisorBehaviorTrainingSet_v1
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Button onClick={checkDatabase} disabled={isLoading} className="mb-4">
            {isLoading ? 'Checking...' : 'Refresh Database Check'}
          </Button>
          
          {data && !data.error && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-slate-700 p-4 rounded-lg">
                  <h3 className="text-cyan-400 font-bold">Total Records</h3>
                  <p className="text-white text-2xl">{data.totalRecords}</p>
                </div>
                <div className="bg-slate-700 p-4 rounded-lg">
                  <h3 className="text-green-400 font-bold">Health Records</h3>
                  <p className="text-white text-2xl">{data.healthRecords}</p>
                </div>
                <div className="bg-slate-700 p-4 rounded-lg">
                  <h3 className="text-blue-400 font-bold">Payment Records</h3>
                  <p className="text-white text-2xl">{data.paymentRecords}</p>
                </div>
                <div className="bg-slate-700 p-4 rounded-lg">
                  <h3 className="text-purple-400 font-bold">Last Updated</h3>
                  <p className="text-white text-sm">{data.lastUpdated}</p>
                </div>
              </div>

              <div className="bg-slate-700 p-4 rounded-lg">
                <h3 className="text-yellow-400 font-bold mb-2">Persona Distribution</h3>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(data.personaStats).map(([persona, count]) => (
                    <div key={persona} className="flex justify-between">
                      <span className="text-slate-300">{persona}:</span>
                      <span className="text-white font-bold">{count}</span>
                    </div>
                  ))}
                </div>
              </div>

              {data.sampleHealthRecord && (
                <div className="bg-slate-700 p-4 rounded-lg">
                  <h3 className="text-green-400 font-bold mb-2">Sample Health Record</h3>
                  <p className="text-slate-300 text-sm mb-1">
                    <strong>Question:</strong> {data.sampleHealthRecord.question}
                  </p>
                  <p className="text-slate-300 text-sm mb-1">
                    <strong>Persona:</strong> {data.sampleHealthRecord.persona}
                  </p>
                  <p className="text-slate-300 text-sm">
                    <strong>Response Length:</strong> {data.sampleHealthRecord.ideal_response?.length || 0} chars
                  </p>
                </div>
              )}

              {data.samplePaymentRecord && (
                <div className="bg-slate-700 p-4 rounded-lg">
                  <h3 className="text-blue-400 font-bold mb-2">Sample Payment Record</h3>
                  <p className="text-slate-300 text-sm mb-1">
                    <strong>Question:</strong> {data.samplePaymentRecord.question}
                  </p>
                  <p className="text-slate-300 text-sm mb-1">
                    <strong>Persona:</strong> {data.samplePaymentRecord.persona}
                  </p>
                  <p className="text-slate-300 text-sm">
                    <strong>Response Length:</strong> {data.samplePaymentRecord.ideal_response?.length || 0} chars
                  </p>
                </div>
              )}
            </div>
          )}
          
          {data?.error && (
            <div className="bg-red-800/30 border border-red-700 p-4 rounded-lg">
              <div className="flex items-center gap-2 text-red-400">
                <AlertCircle className="w-5 h-5" />
                <span>Database Error: {data.error}</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}