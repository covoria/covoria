
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import {
    Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from "@/components/ui/tooltip";
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { UploadCloud, Trash2, LayoutDashboard, MessageCircle, CheckCircle, AlertCircle, RefreshCw, ChevronDown } from 'lucide-react';
import { createPageUrl } from '@/utils';
import DataImportCard from '../components/settings/DataImportCard';
import { User } from '@/api/entities';
import { Document } from '@/api/entities';
import { InsurancePolicy } from '@/api/entities';
import { SavingsAccount } from '@/api/entities';
import { Insight } from '@/api/entities';
import { UploadProcessingLog } from '@/api/entities';
import { getUploadStatusV2 } from '@/api/functions';
import { resetUserData } from '@/api/functions';

const HomeTile = ({ icon: Icon, title, subtitle, gradient, onClick, delay, isPulsing, isProcessing, progressText }) => (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: delay, duration: 0.4 }}
      whileHover={{ scale: 1.05, boxShadow: "0 10px 20px rgba(0,0,0,0.2)" }}
      onClick={isProcessing ? undefined : onClick}
      className={`${gradient} text-white h-36 w-36 flex flex-col items-center justify-center text-center rounded-2xl shadow-lg transition-all duration-300 ${isProcessing ? 'cursor-wait' : 'cursor-pointer'} border border-white/10 relative overflow-hidden group p-2`}
    >
        <AnimatePresence>
        {isPulsing && (
            <motion.div
                key="pulse"
                initial={{ scale: 1, opacity: 0.7 }}
                animate={{ scale: 2.5, opacity: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.5, repeat: Infinity, ease: 'easeOut' }}
                className="absolute inset-0 bg-cyan-400 rounded-full z-0"
            />
        )}
        </AnimatePresence>
      <div className="relative z-10 flex flex-col items-center justify-center h-full w-full">
        <Icon className={`w-8 h-8 mb-2 text-slate-100 drop-shadow-lg`} strokeWidth={1.5} />
        <div className="text-sm font-semibold mt-1 leading-tight">{title}</div>
        <div className="text-xs text-white/60 mt-1">{subtitle}</div>
      </div>
      
      <AnimatePresence>
        {isProcessing && (
            <motion.div
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: 'spring', stiffness: 200, damping: 25 }}
                className="absolute bottom-0 left-0 right-0 bg-black/50 backdrop-blur-sm p-2 text-xs flex items-center justify-center gap-2"
            >
                <RefreshCw className="w-3 h-3 animate-spin" />
                <span>{progressText}</span>
            </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
);

export default function Settings() {
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState('');
  const [deleteSuccess, setDeleteSuccess] = useState('');
  const [isFeaturesVisible, setIsFeaturesVisible] = useState(false);
  const [dataExists, setDataExists] = useState(false);
  const [shouldPulse, setShouldPulse] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressText, setProgressText] = useState('');
  const navigate = useNavigate();
  const [showDeletionInProgress, setShowDeletionInProgress] = useState(false);

  const checkDataStatus = useCallback(async () => {
    if (sessionStorage.getItem('newAnalysisComplete') === 'true') {
        setShouldPulse(true);
    } else {
        setShouldPulse(false);
    }
    
    try {
        const [policies, accounts] = await Promise.all([
            InsurancePolicy.list(null, 1),
            SavingsAccount.list(null, 1),
        ]);
        const hasData = policies.length > 0 || accounts.length > 0;
        setDataExists(hasData);
        console.log('🚀 Data check:', { policies: policies.length, accounts: accounts.length, hasData });
    } catch (error) {
        console.error("Failed to check for data:", error);
        setDataExists(false);
    }
  }, []);

  const checkUploadStatus = useCallback(async () => {
    try {
        const response = await getUploadStatusV2();
        console.log('🚀 Upload status response:', response);
        
        if (response && response.data && response.data.success) {
            setIsProcessing(response.data.isActive || false);
            setProgressText(response.data.progressText || '');
        } else {
            console.warn('[Settings] Invalid response structure:', response);
            setIsProcessing(false);
            setProgressText('');
        }
    } catch (error) {
        console.warn('[Settings] Upload status check failed:', error.message);
        setIsProcessing(false);
        setProgressText('');
    }
  }, []);

  useEffect(() => {
    checkDataStatus();
    checkUploadStatus();

    const intervalId = setInterval(checkUploadStatus, 5000);
    
    const handleStorageChange = () => checkDataStatus();
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('focus', checkDataStatus);
    window.addEventListener('focus', checkUploadStatus);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('focus', checkDataStatus);
      window.removeEventListener('focus', checkUploadStatus);
      clearInterval(intervalId);
    };
  }, [checkDataStatus, checkUploadStatus]);

  const handleClearDocuments = async () => {
      setIsDeleting(true);
      setShowDeletionInProgress(true);
      setDeleteError('');
      setDeleteSuccess('');

      try {
          console.log('🚀 Starting complete data reset');
          
          const response = await resetUserData();
          console.log('🚀 Reset response:', response);
          
          if (response && response.data && response.data.success) {
              setDataExists(false);
              setShouldPulse(false);
              
              sessionStorage.removeItem('covoria_active_uploads');
              sessionStorage.removeItem('newAnalysisComplete');
              
              setDeleteSuccess(`Successfully cleared ${response.data.deleted_count} items. The page will now refresh.`);
              
              setTimeout(() => {
                  window.location.reload();
              }, 3000);
          } else {
              throw new Error(response?.data?.error || 'Reset failed');
          }

      } catch (error) {
          console.error('[Settings] Reset failed:', error);
          setDeleteError(`Reset failed: ${error.message}`);
          setIsDeleting(false);
          setShowDeletionInProgress(false);
      }
  };

  const onUploadComplete = () => {
      console.log('🚀 Upload completed - refreshing status');
      checkDataStatus();
      checkUploadStatus();
  };
  
  if (showDeletionInProgress) {
    return (
        <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-center">
            <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
            >
                <RefreshCw className="w-16 h-16 text-cyan-400 animate-spin mb-6" />
                <h2 className="text-2xl font-bold text-white mb-2">Clearing Your Data...</h2>
                <p className="text-slate-300">{deleteSuccess || "This may take a moment. Please don't refresh the page."}</p>
                {deleteError && <p className="text-red-400 mt-4">{deleteError}</p>}
            </motion.div>
        </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4">
      <div className="text-center mb-6">
          <motion.img
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/4afd61a5c_file_00000000a74c61fa895c27e866860641.png"
              alt="Covoria Logo"
              className="h-20 w-auto object-contain select-none transition-all duration-300 mb-4 mx-auto"
              style={{ filter: 'brightness(1.5)' }}
              draggable="false"
          />
          <motion.h1
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{delay: 0.1}}
            className="text-3xl font-bold tracking-wider text-white" style={{ fontFamily: "'Poppins', sans-serif" }}>
            COVORIA
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{delay: 0.2}}
            className="text-sm font-light tracking-widest text-slate-400 uppercase">
            SMARTER COVERAGE STARTS HERE
          </motion.p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
        className="w-full max-w-md bg-slate-800/50 border border-slate-700 rounded-2xl p-6 text-center mb-8 shadow-lg"
      >
        <h2 className="text-lg font-bold text-white mb-3">
          Your entire insurance universe — unified, analyzed, and optimized.
        </h2>
        
        <div
          className="cursor-pointer flex flex-col items-center text-slate-500 hover:text-slate-300"
          onClick={() => setIsFeaturesVisible(!isFeaturesVisible)}
        >
          <motion.div animate={{ rotate: isFeaturesVisible ? 180 : 0 }}>
            <ChevronDown className="w-5 h-5" />
          </motion.div>
        </div>
        <AnimatePresence>
          {isFeaturesVisible && (
            <motion.div
              initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.4, ease: "easeInOut" }}
              className="overflow-hidden"
            >
              <div className="space-y-3 mt-4 pt-4 border-t border-slate-700/50 text-left">
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-slate-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm text-slate-300">All your policies and accounts in one smart, secured hub</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-slate-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm text-slate-300">AI-driven insights reveal gaps and overpriced plans</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-slate-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm text-slate-300">Smarter coverage decisions that save you money</p>
                </div>
                 <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-slate-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm text-slate-300">Actionable, personalized recommendations in seconds.</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      <AnimatePresence>
        {isProcessing && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="w-full max-w-md mb-4"
          >
            <div className="bg-gradient-to-r from-cyan-900/50 to-blue-900/50 border border-cyan-600/30 rounded-2xl p-4 text-center backdrop-blur-sm">
              <div className="flex items-center justify-center gap-3 mb-2">
                <RefreshCw className="w-5 h-5 text-cyan-400 animate-spin" />
                <span className="text-white font-medium">AI Analysis in Progress</span>
              </div>
              <p className="text-cyan-300 text-sm">{progressText}</p>
              <div className="w-full bg-slate-700 rounded-full h-2 mt-3 overflow-hidden">
                <motion.div 
                  className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col items-center gap-4">
        <div>
          <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
            <DialogTrigger asChild>
              <div>
                <HomeTile
                    icon={UploadCloud} title="Upload Documents" subtitle="Start your analysis"
                    gradient="bg-gradient-to-br from-gray-900 to-slate-800" delay={0.4}
                    onClick={() => setIsUploadOpen(true)}
                    isProcessing={isProcessing}
                    progressText={progressText}
                />
              </div>
            </DialogTrigger>
            <DialogContent className="max-w-3xl bg-slate-900/95 backdrop-blur-xl border border-slate-700/50 text-white shadow-2xl">
                   <DataImportCard onProcessingComplete={onUploadComplete} />
            </DialogContent>
          </Dialog>
        </div>

        <div className="flex gap-4">
          <TooltipProvider>
            <Tooltip open={shouldPulse ? true : undefined}>
              <TooltipTrigger asChild>
                <div>
                  <HomeTile
                    icon={LayoutDashboard} title="Coverage Overview"
                    subtitle={dataExists ? "View insights" : "Awaiting data"}
                    gradient="bg-gradient-to-br from-blue-900 to-slate-700"
                    onClick={() => navigate(createPageUrl('Dashboard'))}
                    delay={0.5} isPulsing={shouldPulse}
                    isProcessing={isProcessing} progressText={progressText}
                  />
                </div>
              </TooltipTrigger>
              {shouldPulse && (
                <TooltipContent className="bg-slate-950 text-white border-slate-700">
                  <p>New insights are ready for you!</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>

          <HomeTile
            icon={MessageCircle} title="Covoria AI Advisor"
            subtitle={dataExists ? "Ask anything" : "Awaiting data"}
            gradient="bg-gradient-to-br from-indigo-800 to-blue-950"
            onClick={() => navigate(createPageUrl('Assistant'))}
            delay={0.6}
          />
        </div>

        <AlertDialog>
          <AlertDialogTrigger asChild>
              <div>
                <HomeTile
                  icon={Trash2} 
                  title="Reset Your Data" 
                  subtitle="Start fresh"
                  gradient="bg-gradient-to-br from-slate-800 to-cyan-900" 
                  delay={0.7}
                />
              </div>
          </AlertDialogTrigger>
          <AlertDialogContent className="bg-slate-900 border-slate-700 text-white">
              <AlertDialogHeader>
                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription className="text-slate-400">
                      This will permanently delete all documents, policies, accounts, and insights. This action cannot be undone.
                  </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter className="mt-4">
                {deleteSuccess && <p className="text-green-400 text-sm flex items-center gap-2"><CheckCircle className="w-4 h-4" />{deleteSuccess}</p>}
                {deleteError && <p className="text-red-400 text-sm flex items-center gap-2"><AlertCircle className="w-4 h-4" />{deleteError}</p>}
                <AlertDialogCancel className="bg-slate-700 border-slate-600 hover:bg-slate-600" disabled={isDeleting}>
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction
                    onClick={handleClearDocuments}
                    className="bg-red-600 hover:bg-red-700"
                    disabled={isDeleting}
                >
                  {isDeleting ? (
                    <div className="flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Deleting...
                    </div>
                  ) : (
                    'Delete Everything'
                  )}
                </AlertDialogAction>
              </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
