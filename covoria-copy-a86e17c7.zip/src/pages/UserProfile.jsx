
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { 
  User as UserIcon, 
  Save, 
  RefreshCw, 
  CheckCircle, 
  AlertCircle,
  Calendar,
  MapPin,
  Users,
  Briefcase,
  Heart,
  Shield,
  DollarSign
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '@/api/entities';
import { insightEngine } from '@/api/functions';
import { futureOutlookEngine } from '@/api/functions';
import { createUserProfile } from '@/api/functions';

const ProfileSection = ({ title, icon: Icon, children, isLoading = false }) => (
  <Card className="covoria-card">
    <CardHeader className="pb-3">
      <CardTitle className="flex items-center gap-2 text-lg text-gray-900 dark:text-[var(--covoria-text-primary)]">
        <Icon className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
        {title}
      </CardTitle>
    </CardHeader>
    <CardContent className="space-y-4">
      {isLoading ? (
        <div className="space-y-3">
          <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded animate-pulse"></div>
          <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded animate-pulse w-3/4"></div>
          <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded animate-pulse w-1/2"></div>
        </div>
      ) : (
        children
      )}
    </CardContent>
  </Card>
);

export default function UserProfile() {
  const [user, setUser] = useState(null);
  const [profileData, setProfileData] = useState({ 
    age: '',
    location: '',
    marital_status: '',
    dependents: 0,
    employment_status: '',
    income_bracket: '',
    health_status: '',
    financial_goals: [],
    risk_concerns: [],
    communication_preferences: {
      tone: 'professional',
      frequency: 'weekly',
      topics: []
    },
    profile_notes: ''
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState(null);
  const [profileCompleteness, setProfileCompleteness] = useState(0);

  useEffect(() => {
    loadUserProfile();
  }, []);

  useEffect(() => {
    calculateProfileCompleteness();
  }, [profileData]);

  const loadUserProfile = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      // Merge user data with profile structure
      const existingProfileData = {
        age: currentUser.age || '',
        location: currentUser.location || '',
        marital_status: currentUser.marital_status || '',
        dependents: currentUser.dependents || 0,
        employment_status: currentUser.employment_status || '',
        income_bracket: currentUser.income_bracket || '',
        health_status: currentUser.health_status || '',
        financial_goals: currentUser.financial_goals || [],
        risk_concerns: currentUser.risk_concerns || [],
        communication_preferences: currentUser.communication_preferences || {
          tone: 'professional',
          frequency: 'weekly',
          topics: []
        },
        profile_notes: currentUser.profile_notes || ''
      };
      
      setProfileData(existingProfileData);
      
    } catch (error) {
      console.error('Failed to load user profile:', error);
      setSaveStatus({ type: 'error', message: 'Failed to load profile data' });
    } finally {
      setIsLoading(false);
    }
  };

  const calculateProfileCompleteness = () => {
    const requiredFields = ['age', 'location', 'marital_status', 'employment_status', 'income_bracket', 'health_status'];
    const filledFields = requiredFields.filter(field => 
      profileData[field] && profileData[field] !== ''
    ).length;
    
    const additionalPoints = 
      (profileData.financial_goals.length > 0 ? 1 : 0) +
      (profileData.risk_concerns.length > 0 ? 1 : 0) +
      (profileData.dependents >= 0 ? 1 : 0);
    
    const completeness = Math.round(((filledFields + additionalPoints) / (requiredFields.length + 3)) * 100);
    setProfileCompleteness(completeness);
  };

  const handleInputChange = (field, value) => {
    setProfileData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleArrayFieldChange = (field, value) => {
    const items = value.split(',').map(item => item.trim()).filter(item => item.length > 0);
    setProfileData(prev => ({
      ...prev,
      [field]: items
    }));
  };

  const handleCommunicationPreferenceChange = (field, value) => {
    setProfileData(prev => ({
      ...prev,
      communication_preferences: {
        ...prev.communication_preferences,
        [field]: value
      }
    }));
  };

  const saveProfile = async () => {
    setSaving(true);
    setSaveStatus(null);
    
    try {
      // FIX: Update user entity with profile data using updateMyUserData
      await User.updateMyUserData({
        ...profileData,
        profile_completeness: profileCompleteness / 100,
        last_profile_update: new Date().toISOString()
      });
      
      // Trigger background re-analysis. We don't wait for these to complete.
      console.log("Profile updated, triggering background analysis engines...");
      insightEngine().catch(e => console.error("Insight engine trigger failed:", e.message));
      futureOutlookEngine().catch(e => console.error("Future outlook engine trigger failed:", e.message));

      // This function might be for other purposes, so we keep it.
      await createUserProfile({
        user_id: user.id, // Assuming user.id is still needed for createUserProfile
        profile_data: profileData,
        completeness_score: profileCompleteness
      });
      
      setSaveStatus({ type: 'success', message: 'Profile saved successfully! AI will now provide more personalized assistance.' });
      
      // Reload to get the updated data
      setTimeout(() => {
        loadUserProfile();
      }, 1000);
      
    } catch (error) {
      console.error('Failed to save profile:', error);
      setSaveStatus({ type: 'error', message: 'Failed to save profile. Please try again.' });
    } finally {
      setSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[var(--covoria-bg-main)] p-4">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="h-12 bg-gray-200 dark:bg-slate-700 rounded animate-pulse"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-64 bg-gray-200 dark:bg-slate-700 rounded animate-pulse"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[var(--covoria-bg-main)] p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }} 
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <h1 className="text-3xl font-bold text-gray-900 dark:text-[var(--covoria-text-primary)] mb-2">Your Profile</h1>
          <p className="text-gray-600 dark:text-[var(--covoria-text-secondary)] mb-4">
            Help Covoria provide more personalized insurance and financial guidance
          </p>
          
          {/* Profile Completeness Indicator */}
          <div className="bg-white dark:bg-[var(--covoria-bg-card)] rounded-lg p-4 shadow-sm max-w-md mx-auto">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)]">Profile Completeness</span>
              <span className="text-sm font-bold text-cyan-600 dark:text-cyan-400">{profileCompleteness}%</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2">
              <motion.div 
                className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${profileCompleteness}%` }}
              />
            </div>
            <p className="text-xs text-gray-500 dark:text-slate-400 mt-2">
              {profileCompleteness >= 80 ? 'Great! Your profile is comprehensive.' : 
               profileCompleteness >= 50 ? 'Good progress! Add more details for better recommendations.' :
               'Complete your profile for personalized AI assistance.'}
            </p>
          </div>
        </motion.div>

        {/* Save Status */}
        <AnimatePresence>
          {saveStatus && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className={`p-4 rounded-lg flex items-center gap-2 ${
                saveStatus.type === 'success' 
                  ? 'bg-green-50 text-green-800 border border-green-200' 
                  : 'bg-red-50 text-red-800 border border-red-200'
              }`}
            >
              {saveStatus.type === 'success' ? 
                <CheckCircle className="w-5 h-5" /> : 
                <AlertCircle className="w-5 h-5" />
              }
              {saveStatus.message}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Profile Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Basic Information */}
          <ProfileSection title="Basic Information" icon={UserIcon}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Name</label>
                <Input 
                  value={user?.full_name || ''} 
                  disabled 
                  className="bg-gray-100 dark:bg-slate-700/50 border-gray-300 dark:border-slate-600"
                />
                <p className="text-xs text-gray-500 dark:text-slate-400 mt-1">Name cannot be changed</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Age</label>
                <Input 
                  type="number"
                  value={profileData.age}
                  onChange={(e) => handleInputChange('age', parseInt(e.target.value) || '')}
                  placeholder="Enter your age"
                  className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)] placeholder:text-gray-400 dark:placeholder:text-slate-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Location</label>
                <Input 
                  value={profileData.location}
                  onChange={(e) => handleInputChange('location', e.target.value)}
                  placeholder="City, State"
                  className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)] placeholder:text-gray-400 dark:placeholder:text-slate-500"
                />
              </div>
            </div>
          </ProfileSection>

          {/* Family & Lifestyle */}
          <ProfileSection title="Family & Lifestyle" icon={Users}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Marital Status</label>
                <Select value={profileData.marital_status} onValueChange={(value) => handleInputChange('marital_status', value)}>
                  <SelectTrigger className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-200 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectItem value="single">Single</SelectItem>
                    <SelectItem value="married">Married</SelectItem>
                    <SelectItem value="divorced">Divorced</SelectItem>
                    <SelectItem value="widowed">Widowed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Number of Dependents</label>
                <Input 
                  type="number"
                  value={profileData.dependents}
                  onChange={(e) => handleInputChange('dependents', parseInt(e.target.value) || 0)}
                  min="0"
                  className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)] placeholder:text-gray-400 dark:placeholder:text-slate-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Health Status</label>
                <Select value={profileData.health_status} onValueChange={(value) => handleInputChange('health_status', value)}>
                  <SelectTrigger className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectValue placeholder="Select health status" />
                  </SelectTrigger>
                  <SelectContent className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-200 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectItem value="excellent">Excellent</SelectItem>
                    <SelectItem value="good">Good</SelectItem>
                    <SelectItem value="fair">Fair</SelectItem>
                    <SelectItem value="poor">Poor</SelectItem>
                    <SelectItem value="has_chronic_conditions">Has Chronic Conditions</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </ProfileSection>

          {/* Employment & Income */}
          <ProfileSection title="Employment & Income" icon={Briefcase}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Employment Status</label>
                <Select value={profileData.employment_status} onValueChange={(value) => handleInputChange('employment_status', value)}>
                  <SelectTrigger className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectValue placeholder="Select employment status" />
                  </SelectTrigger>
                  <SelectContent className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-200 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectItem value="employed">Employed</SelectItem>
                    <SelectItem value="self_employed">Self-Employed</SelectItem>
                    <SelectItem value="unemployed">Unemployed</SelectItem>
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="retired">Retired</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Annual Household Income</label>
                <Select value={profileData.income_bracket} onValueChange={(value) => handleInputChange('income_bracket', value)}>
                  <SelectTrigger className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectValue placeholder="Select income range" />
                  </SelectTrigger>
                  <SelectContent className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-200 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectItem value="0-50k">$0 - $50,000</SelectItem>
                    <SelectItem value="50k-100k">$50,001 - $100,000</SelectItem>
                    <SelectItem value="100k-200k">$100,001 - $200,000</SelectItem>
                    <SelectItem value="200k+">$200,001+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </ProfileSection>

          {/* Financial Goals & Concerns */}
          <ProfileSection title="Financial Goals & Concerns" icon={DollarSign}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Financial Goals</label>
                <Textarea 
                  value={profileData.financial_goals.join(', ')}
                  onChange={(e) => handleArrayFieldChange('financial_goals', e.target.value)}
                  placeholder="e.g., Emergency fund, Retirement planning, Home purchase"
                  className="h-20 bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)] placeholder:text-gray-400 dark:placeholder:text-slate-500"
                />
                <p className="text-xs text-gray-500 dark:text-slate-400 mt-1">Separate multiple goals with commas</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Risk Concerns</label>
                <Textarea 
                  value={profileData.risk_concerns.join(', ')}
                  onChange={(e) => handleArrayFieldChange('risk_concerns', e.target.value)}
                  placeholder="e.g., Job loss, Medical emergency, Disability"
                  className="h-20 bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)] placeholder:text-gray-400 dark:placeholder:text-slate-500"
                />
                <p className="text-xs text-gray-500 dark:text-slate-400 mt-1">Separate multiple concerns with commas</p>
              </div>
            </div>
          </ProfileSection>

          {/* Communication Preferences */}
          <ProfileSection title="AI Assistant Preferences" icon={Shield}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Communication Tone</label>
                <Select 
                  value={profileData.communication_preferences.tone} 
                  onValueChange={(value) => handleCommunicationPreferenceChange('tone', value)}
                >
                  <SelectTrigger className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-200 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectItem value="casual">Casual & Friendly</SelectItem>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="concise">Concise & Direct</SelectItem>
                    <SelectItem value="detailed">Detailed & Educational</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Update Frequency</label>
                <Select 
                  value={profileData.communication_preferences.frequency} 
                  onValueChange={(value) => handleCommunicationPreferenceChange('frequency', value)}
                >
                  <SelectTrigger className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-200 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)]">
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="as_needed">As Needed Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </ProfileSection>

          {/* Personal Notes */}
          <ProfileSection title="Additional Notes" icon={Heart}>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-1">Personal Notes</label>
              <Textarea 
                value={profileData.profile_notes}
                onChange={(e) => handleInputChange('profile_notes', e.target.value)}
                placeholder="Any additional information that might help us provide better recommendations..."
                className="h-24 bg-white dark:bg-[var(--covoria-bg-surface)] border-gray-300 dark:border-[var(--covoria-border-color)] text-gray-900 dark:text-[var(--covoria-text-primary)] placeholder:text-gray-400 dark:placeholder:text-slate-500"
              />
              <p className="text-xs text-gray-500 dark:text-slate-400 mt-1">This information helps our AI provide more personalized advice</p>
            </div>
          </ProfileSection>
        </div>

        {/* Save Button */}
        <motion.div 
          className="flex justify-center pt-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Button
            onClick={saveProfile}
            disabled={isSaving}
            className="covoria-gradient text-white px-8 py-3 text-lg font-semibold hover:shadow-lg transition-all duration-200"
          >
            {isSaving ? (
              <>
                <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                Saving Profile...
              </>
            ) : (
              <>
                <Save className="w-5 h-5 mr-2" />
                Save Profile
              </>
            )}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
