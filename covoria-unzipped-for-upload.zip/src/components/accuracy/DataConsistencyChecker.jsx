import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, CheckCircle, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';

export default function DataConsistencyChecker({ 
  policies, 
  questionnaireAnswers, 
  onUpdateAnswer, 
  onReinterpretDocument 
}) {
  const [inconsistencies, setInconsistencies] = useState([]);
  const [isChecking, setIsChecking] = useState(false);

  useEffect(() => {
    if (policies.length > 0 && questionnaireAnswers) {
      checkConsistency();
    }
  }, [policies, questionnaireAnswers]);

  const checkConsistency = async () => {
    setIsChecking(true);
    
    try {
      const found = [];
      
      // Check insurance types mentioned in questionnaire vs uploaded policies
      const userClaimedTypes = questionnaireAnswers.insurance_types || [];
      const uploadedTypes = policies.filter(p => p.is_active).map(p => p.insurance_type);
      
      // Find types claimed but not uploaded
      const missingUploads = userClaimedTypes.filter(type => !uploadedTypes.includes(type));
      missingUploads.forEach(type => {
        found.push({
          type: 'missing_upload',
          severity: 'medium',
          message: `You mentioned having ${type} insurance, but we didn't find a policy document.`,
          suggestedAction: 'upload_document',
          relatedType: type
        });
      });
      
      // Find uploaded types not mentioned in questionnaire
      const unmentionedUploads = uploadedTypes.filter(type => !userClaimedTypes.includes(type));
      unmentionedUploads.forEach(type => {
        const policy = policies.find(p => p.insurance_type === type && p.is_active);
        found.push({
          type: 'unmentioned_policy',
          severity: 'low',
          message: `We found a ${type} policy from ${policy.provider}, but you didn't mention it in your profile.`,
          suggestedAction: 'update_questionnaire',
          relatedType: type,
          relatedPolicy: policy
        });
      });
      
      // Check for premium discrepancies
      policies.forEach(policy => {
        if (policy.premium_amount > 500) {
          found.push({
            type: 'high_premium',
            severity: 'medium',
            message: `Your ${policy.insurance_type} policy premium ($${policy.premium_amount}) seems high compared to market averages.`,
            suggestedAction: 'review_policy',
            relatedPolicy: policy
          });
        }
      });
      
      setInconsistencies(found);
    } catch (error) {
      console.error('Error checking consistency:', error);
    }
    
    setIsChecking(false);
  };

  const handleResolveInconsistency = (inconsistency) => {
    if (inconsistency.suggestedAction === 'update_questionnaire') {
      onUpdateAnswer('insurance_types', [...(questionnaireAnswers.insurance_types || []), inconsistency.relatedType]);
    } else if (inconsistency.suggestedAction === 'reinterpret_document') {
      onReinterpretDocument(inconsistency.relatedPolicy);
    }
    
    // Remove this inconsistency from the list
    setInconsistencies(prev => prev.filter(item => item !== inconsistency));
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high': return 'border-red-200 bg-red-50';
      case 'medium': return 'border-yellow-200 bg-yellow-50';
      case 'low': return 'border-blue-200 bg-blue-50';
      default: return 'border-gray-200 bg-gray-50';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'high': return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case 'medium': return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'low': return <AlertTriangle className="w-4 h-4 text-blue-600" />;
      default: return <AlertTriangle className="w-4 h-4 text-gray-600" />;
    }
  };

  if (isChecking) {
    return (
      <Card className="covoria-card">
        <CardContent className="p-6">
          <div className="flex items-center justify-center gap-3">
            <RefreshCw className="w-5 h-5 animate-spin text-cyan-600" />
            <span className="text-gray-600">Checking data consistency...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (inconsistencies.length === 0) {
    return (
      <Card className="covoria-card border-green-200">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 text-green-700">
            <CheckCircle className="w-5 h-5" />
            <span className="font-medium">All data looks consistent!</span>
          </div>
          <p className="text-sm text-green-600 mt-1">
            Your questionnaire answers match your uploaded documents.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="covoria-card">
      <CardContent className="p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Data Consistency Check</h3>
        
        <div className="space-y-3">
          {inconsistencies.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Alert className={getSeverityColor(item.severity)}>
                <div className="flex items-start gap-3">
                  {getSeverityIcon(item.severity)}
                  <div className="flex-1">
                    <AlertDescription className="text-sm">
                      {item.message}
                    </AlertDescription>
                    <Button
                      onClick={() => handleResolveInconsistency(item)}
                      size="sm"
                      className="mt-2 h-7 text-xs"
                      variant="outline"
                    >
                      {item.suggestedAction === 'update_questionnaire' && 'Update Profile'}
                      {item.suggestedAction === 'upload_document' && 'Upload Document'}
                      {item.suggestedAction === 'review_policy' && 'Review Policy'}
                      {item.suggestedAction === 'reinterpret_document' && 'Re-analyze'}
                    </Button>
                  </div>
                </div>
              </Alert>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}