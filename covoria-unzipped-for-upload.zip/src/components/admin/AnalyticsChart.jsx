import React from 'react';
import { 
    ResponsiveContainer, 
    LineChart, Line, 
    BarChart, Bar, 
    PieChart, Pie, Cell,
    XAxis, YAxis, CartesianGrid, Tooltip, Legend 
} from 'recharts';
import { Skeleton } from '@/components/ui/skeleton';

const COLORS = ['#0ea5e9', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444'];

export default function AnalyticsChart({ data, type, dataKeys, isLoading }) {
    if (isLoading) {
        return <Skeleton className="w-full h-32 bg-slate-800" />;
    }

    if (!data || data.length === 0) {
        // V2 Fix: Collapse empty state to minimal height instead of h-72
        return (
            <div className="flex items-center justify-center h-24 text-slate-400 bg-slate-900/50 rounded-xl border border-slate-700/50">
                <div className="text-center">
                    <p className="text-sm">No data available</p>
                    <p className="text-xs text-slate-500">Try adjusting the date range</p>
                </div>
            </div>
        );
    }

    const renderChart = () => {
        switch (type) {
            case 'line':
                return (
                    <LineChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                        <XAxis dataKey="date" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" />
                        <Tooltip 
                            contentStyle={{ 
                                backgroundColor: '#1e293b', 
                                border: '1px solid #475569',
                                borderRadius: '8px',
                                color: '#f8fafc'
                            }} 
                        />
                        <Legend />
                        {dataKeys.map((key, index) => (
                             <Line key={key} type="monotone" dataKey={key} stroke={COLORS[index % COLORS.length]} strokeWidth={2} />
                        ))}
                    </LineChart>
                );
            case 'bar':
                return (
                    <BarChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                        <XAxis dataKey="name" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" />
                        <Tooltip 
                            contentStyle={{ 
                                backgroundColor: '#1e293b', 
                                border: '1px solid #475569',
                                borderRadius: '8px',
                                color: '#f8fafc'
                            }} 
                        />
                        <Legend />
                        <Bar dataKey="leads" fill={COLORS[0]} />
                    </BarChart>
                );
            case 'pie':
                return (
                    <PieChart>
                        <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} fill="#8884d8" label>
                             {data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip 
                            contentStyle={{ 
                                backgroundColor: '#1e293b', 
                                border: '1px solid #475569',
                                borderRadius: '8px',
                                color: '#f8fafc'
                            }} 
                        />
                        <Legend />
                    </PieChart>
                );
            default:
                return null;
        }
    };

    return (
        <div className="w-full h-72">
            <ResponsiveContainer>
                {renderChart()}
            </ResponsiveContainer>
        </div>
    );
}