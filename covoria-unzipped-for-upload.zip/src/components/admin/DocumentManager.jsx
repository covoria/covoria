import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Trash2, RefreshCw, FileText, AlertCircle, BookOpen, User as UserIcon } from 'lucide-react';
import { Document } from '@/api/entities';
import { Skeleton } from '@/components/ui/skeleton';

export default function DocumentManager() {
  const [documents, setDocuments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchDocuments();
  }, []);

  const fetchDocuments = async () => {
    setIsLoading(true);
    setError('');
    try {
      // Fetch only knowledge source documents (admin uploads)
      const knowledgeDocs = await Document.filter({ document_type: 'knowledge_source' }, '-created_date');
      setDocuments(knowledgeDocs);
    } catch (err) {
      setError('Failed to load knowledge documents.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (docId, fileName) => {
    if (!confirm(`Are you sure you want to delete "${fileName}"? This action cannot be undone.`)) {
      return;
    }

    const originalDocuments = [...documents];
    setDocuments(documents.filter(doc => doc.id !== docId));
    
    try {
      await Document.delete(docId);
    } catch (err) {
      setError(`Failed to delete document. Please refresh and try again.`);
      setDocuments(originalDocuments); 
      console.error(err);
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed': return <Badge variant="default" className="bg-green-600">Completed</Badge>;
      case 'analyzing': return <Badge variant="secondary" className="bg-yellow-600">Analyzing</Badge>;
      case 'failed': return <Badge variant="destructive">Failed</Badge>;
      default: return <Badge variant="outline">{status || 'N/A'}</Badge>;
    }
  };

  const renderContent = () => {
    if (isLoading) {
      return <div className="space-y-4">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>;
    }

    if (error) {
      return (
        <div className="text-center py-10 text-red-400">
          <AlertCircle className="mx-auto w-8 h-8 mb-2" />
          <p>{error}</p>
          <Button onClick={fetchDocuments} variant="outline" className="mt-2 text-sm">
            <RefreshCw className="w-4 h-4 mr-2" /> Retry
          </Button>
        </div>
      );
    }

    if (documents.length === 0) {
      return (
        <div className="text-center py-10">
          <BookOpen className="mx-auto w-12 h-12 text-slate-500" />
          <h3 className="mt-2 text-lg font-medium text-slate-300">No Knowledge Documents</h3>
          <p className="mt-1 text-sm text-slate-500">Upload knowledge base documents through the Knowledge Management page.</p>
        </div>
      );
    }

    return (
      <div className="space-y-3">
        {documents.map(doc => (
          <div key={doc.id} className="flex items-center justify-between p-4 bg-slate-800 rounded-lg border border-slate-700 hover:bg-slate-700/50 transition-colors">
            <div className="flex items-center gap-4 flex-1 min-w-0">
               <Badge className="bg-purple-600 gap-1.5 flex-shrink-0">
                 <BookOpen className="w-3 h-3"/> Knowledge
               </Badge>
               <div className="flex-1 min-w-0">
                 <p className="text-white font-medium truncate" title={doc.file_name}>{doc.file_name}</p>
                 <p className="text-xs text-slate-400">
                   Uploaded by: <span className="font-medium">{doc.user_email || 'Unknown'}</span> on {new Date(doc.created_date).toLocaleDateString()}
                 </p>
                 {doc.analysis_summary && (
                   <p className="text-xs text-slate-500 mt-1 truncate">{doc.analysis_summary}</p>
                 )}
               </div>
            </div>
            <div className="flex items-center gap-3 flex-shrink-0 ml-4">
              {getStatusBadge(doc.status)}
              <Button
                onClick={() => handleDelete(doc.id, doc.file_name)}
                variant="destructive"
                size="icon"
                className="w-9 h-9"
                title="Delete this knowledge document"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <Card className="covoria-card bg-slate-900/50">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-white text-xl">Knowledge Base Documents</CardTitle>
            <CardDescription className="text-slate-400">
              Manage uploaded knowledge base documents and training materials.
            </CardDescription>
          </div>
          <Button onClick={fetchDocuments} variant="ghost" size="icon" disabled={isLoading}>
            <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {renderContent()}
      </CardContent>
    </Card>
  );
}