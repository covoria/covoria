import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import {
  Brain,
  Users,
  MessageSquare,
  TrendingUp,
  Download,
  RefreshCw,
  Eye,
  RotateCcw,
  BarChart3
} from 'lucide-react';
import {
  getKnowledgeCore,
  getKnowledgeStats,
  getRecentInsights,
  exportKnowledgeCore,
  resetKnowledgeCore
} from '../services/CovoriaLearningSystem';

export default function KnowledgeDashboard() {
  const [stats, setStats] = useState(null);
  const [insights, setInsights] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = () => {
    setIsLoading(true);
    try {
      const knowledgeStats = getKnowledgeStats();
      const recentInsights = getRecentInsights(10);
      
      setStats(knowledgeStats);
      setInsights(recentInsights);
    } catch (error) {
      console.error('Failed to load knowledge dashboard:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    if (confirm('Are you sure? This will reset all AI learning data.')) {
      resetKnowledgeCore();
      loadDashboardData();
    }
  };

  const StatCard = ({ title, value, icon: Icon, description, trend }) => (
    <Card className="bg-slate-800 border-slate-700">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-400">{title}</p>
            <p className="text-2xl font-bold text-white">
              {isLoading ? '...' : value?.toLocaleString() || '0'}
            </p>
            {description && (
              <p className="text-xs text-slate-500 mt-1">{description}</p>
            )}
          </div>
          <div className="flex flex-col items-end">
            {Icon && <Icon className="w-8 h-8 text-cyan-400 mb-2" />}
            {trend && (
              <Badge variant="outline" className="text-xs">
                {trend}
              </Badge>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-slate-800 rounded-lg p-6 animate-pulse">
            <div className="h-4 bg-slate-700 rounded mb-4"></div>
            <div className="h-8 bg-slate-700 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Interactions"
          value={stats?.totalInteractions}
          icon={MessageSquare}
          description="AI conversations processed"
        />
        <StatCard
          title="Unique Users"
          value={stats?.uniqueUsers}
          icon={Users}
          description="Users who interacted with AI"
        />
        <StatCard
          title="AI Insights"
          value={stats?.aiInsights}
          icon={Brain}
          description="Learned insights generated"
        />
        <StatCard
          title="System Health"
          value={stats?.systemHealth ? `${Math.round(stats.systemHealth * 100)}%` : 'N/A'}
          icon={TrendingUp}
          description="Success rate"
          trend={stats?.systemHealth > 0.9 ? "Excellent" : stats?.systemHealth > 0.7 ? "Good" : "Needs attention"}
        />
      </div>

      {/* Controls */}
      <div className="flex gap-4 flex-wrap">
        <Button onClick={loadDashboardData} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh Data
        </Button>
        <Button onClick={exportKnowledgeCore} variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Export Knowledge
        </Button>
        <Button onClick={handleReset} variant="destructive">
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset AI Memory
        </Button>
      </div>

      {/* Top Topics */}
      {stats?.topTopics && stats.topTopics.length > 0 && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Top Discussion Topics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {stats.topTopics.map((topic, index) => (
                <div key={topic.topic} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-mono text-slate-400">#{index + 1}</span>
                    <span className="text-white capitalize">{topic.topic.replace('_', ' ')}</span>
                  </div>
                  <Badge variant="outline" className="text-slate-300">
                    {topic.count} conversations
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent AI Insights */}
      {insights.length > 0 && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Brain className="w-5 h-5" />
              Recent AI Learning Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {insights.map((insight, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-4 bg-slate-700 rounded-lg border-l-4 border-cyan-500"
                >
                  <p className="text-white text-sm mb-2">{insight.insight}</p>
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>Source: {insight.source}</span>
                    <span>{new Date(insight.timestamp).toLocaleDateString()}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* System Status */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Eye className="w-5 h-5" />
            System Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-slate-400">Last Updated:</span>
              <span className="text-white ml-2">
                {stats?.lastUpdated ? new Date(stats.lastUpdated).toLocaleString() : 'Never'}
              </span>
            </div>
            <div>
              <span className="text-slate-400">Storage Status:</span>
              <span className="text-green-400 ml-2">Active</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}