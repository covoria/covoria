import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Trash2, RefreshCw, FileText, AlertCircle, Upload } from 'lucide-react';
import { Document } from '@/api/entities';
import { Skeleton } from '@/components/ui/skeleton';

export default function SourceDocumentManager({ onUploadClick }) {
  const [documents, setDocuments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchDocuments();
  }, []);

  const fetchDocuments = async () => {
    setIsLoading(true);
    setError('');
    try {
      const knowledgeDocs = await Document.filter({ document_type: 'knowledge_source' }, '-created_date');
      setDocuments(knowledgeDocs);
    } catch (err) {
      setError('Failed to load source documents.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (docId, fileName) => {
    if (!confirm(`Are you sure you want to delete source file "${fileName}"? This will NOT delete knowledge entries parsed from it.`)) {
      return;
    }

    const originalDocuments = [...documents];
    setDocuments(documents.filter(doc => doc.id !== docId));
    
    try {
      await Document.delete(docId);
    } catch (err)
      {
      setError(`Failed to delete document. Please refresh and try again.`);
      setDocuments(originalDocuments); 
      console.error(err);
    }
  };
  
  const renderContent = () => {
    if (isLoading) {
      return <Skeleton className="h-20 w-full bg-slate-700" />;
    }

    if (error) {
      return (
        <div className="text-center py-4 text-red-400">
          <AlertCircle className="mx-auto w-6 h-6 mb-2" />
          <p className="text-sm">{error}</p>
        </div>
      );
    }

    if (documents.length === 0) {
      return (
        <div className="text-center py-6">
          <p className="text-sm text-slate-400">No source documents uploaded yet.</p>
        </div>
      );
    }

    return (
      <div className="space-y-2">
        {documents.map(doc => (
          <div key={doc.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 bg-slate-800 rounded-md border border-slate-700 gap-2">
            <div className="flex items-center gap-3 flex-1 min-w-0">
               <FileText className="w-5 h-5 text-slate-400 flex-shrink-0"/>
               <div className="flex-1 min-w-0">
                 <p className="text-white font-medium truncate" title={doc.file_name}>{doc.file_name}</p>
                 <p className="text-xs text-slate-500">
                   Uploaded on {new Date(doc.created_date).toLocaleDateString()}
                 </p>
               </div>
            </div>
            <div className="flex-shrink-0 self-end sm:self-center">
              <Button
                size="icon"
                variant="ghost"
                className="text-red-500 hover:bg-red-500/10 hover:text-red-400 h-8 w-8"
                onClick={() => handleDelete(doc.id, doc.file_name)}
              >
                  <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
            <CardTitle className="text-lg text-white">Knowledge Source Files</CardTitle>
            <CardDescription className="text-slate-400">Manage uploaded expert documents (e.g., Golden Guide).</CardDescription>
        </div>
        <div className="flex gap-2">
             <Button variant="outline" size="icon" onClick={fetchDocuments} className="text-slate-400 border-slate-600 hover:bg-slate-700">
                <RefreshCw className="w-4 h-4" />
             </Button>
             <Button onClick={onUploadClick} className="covoria-gradient text-white">
                <Upload className="w-4 h-4 mr-2" /> Upload
             </Button>
        </div>
      </CardHeader>
      <CardContent>
        {renderContent()}
      </CardContent>
    </Card>
  );
}