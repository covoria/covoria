import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown,
  DollarSign,
  Shield,
  PieChart,
  Download,
  Calendar,
  Target,
  AlertTriangle
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from 'recharts';
import { InsurancePolicy } from '@/api/entities';
import { SavingsAccount } from '@/api/entities';
import { Insight } from '@/api/entities';
import { User } from '@/api/entities';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function AdvancedAnalytics() {
  const [analyticsData, setAnalyticsData] = useState(null);
  const [timeRange, setTimeRange] = useState('30d');
  const [isLoading, setIsLoading] = useState(true);
  const [selectedMetric, setSelectedMetric] = useState('overview');

  useEffect(() => {
    fetchAnalyticsData();
  }, [timeRange]);

  const fetchAnalyticsData = async () => {
    setIsLoading(true);
    try {
      const [policies, accounts, insights] = await Promise.all([
        InsurancePolicy.list(),
        SavingsAccount.list(),
        Insight.list()
      ]);

      const processedData = processAnalyticsData(policies, accounts, insights);
      setAnalyticsData(processedData);
    } catch (error) {
      console.error('Failed to fetch analytics data:', error);
    }
    setIsLoading(false);
  };

  const processAnalyticsData = (policies, accounts, insights) => {
    // Policy distribution
    const policyDistribution = policies.reduce((acc, policy) => {
      acc[policy.insurance_type] = (acc[policy.insurance_type] || 0) + 1;
      return acc;
    }, {});

    const pieData = Object.entries(policyDistribution).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value
    }));

    // Premium trends (mock data for demonstration)
    const premiumTrends = [
      { month: 'Jan', premiums: 2400, savings: 1800 },
      { month: 'Feb', premiums: 2600, savings: 1900 },
      { month: 'Mar', premiums: 2800, savings: 2100 },
      { month: 'Apr', premiums: 2700, savings: 2200 },
      { month: 'May', premiums: 2900, savings: 2400 },
      { month: 'Jun', premiums: 3100, savings: 2600 }
    ];

    // Coverage metrics
    const totalCoverage = policies.reduce((sum, policy) => sum + (policy.coverage_amount || 0), 0);
    const totalPremiums = policies.reduce((sum, policy) => sum + (policy.premium_amount || 0), 0);
    const totalSavings = accounts.reduce((sum, account) => sum + (account.current_balance || 0), 0);

    // Insight analytics
    const insightsByCategory = insights.reduce((acc, insight) => {
      acc[insight.category] = (acc[insight.category] || 0) + 1;
      return acc;
    }, {});

    const insightData = Object.entries(insightsByCategory).map(([name, value]) => ({
      name: name.replace('_', ' ').toUpperCase(),
      value
    }));

    return {
      overview: {
        totalCoverage,
        totalPremiums,
        totalSavings,
        activePolicies: policies.filter(p => p.is_active).length,
        totalInsights: insights.length,
        unresolvedInsights: insights.filter(i => !i.is_resolved).length
      },
      pieData,
      premiumTrends,
      insightData,
      riskScore: Math.floor(Math.random() * 40) + 60, // Mock risk score
      optimizationScore: Math.floor(Math.random() * 30) + 70 // Mock optimization score
    };
  };

  const exportData = () => {
    // Mock export functionality
    const dataStr = JSON.stringify(analyticsData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `covoria-analytics-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="covoria-card">
            <CardContent className="p-6">
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-32 bg-gray-200 rounded"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="1y">Last year</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={selectedMetric} onValueChange={setSelectedMetric}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="overview">Overview</SelectItem>
              <SelectItem value="policies">Policies</SelectItem>
              <SelectItem value="savings">Savings</SelectItem>
              <SelectItem value="insights">Insights</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Button onClick={exportData} className="flex items-center gap-2">
          <Download className="w-4 h-4" />
          Export Data
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="covoria-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Coverage</p>
                  <p className="text-2xl font-bold text-gray-900">
                    ${(analyticsData?.overview.totalCoverage || 0).toLocaleString()}
                  </p>
                </div>
                <Shield className="w-8 h-8 text-cyan-600" />
              </div>
              <div className="flex items-center mt-2">
                <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                <span className="text-sm text-green-600">+12%</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="covoria-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Monthly Premiums</p>
                  <p className="text-2xl font-bold text-gray-900">
                    ${(analyticsData?.overview.totalPremiums || 0).toLocaleString()}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-green-600" />
              </div>
              <div className="flex items-center mt-2">
                <TrendingDown className="w-4 h-4 text-red-600 mr-1" />
                <span className="text-sm text-red-600">-3%</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="covoria-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Insights</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {analyticsData?.overview.unresolvedInsights || 0}
                  </p>
                </div>
                <AlertTriangle className="w-8 h-8 text-orange-600" />
              </div>
              <div className="flex items-center mt-2">
                <span className="text-sm text-gray-600">
                  {analyticsData?.overview.totalInsights || 0} total
                </span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="covoria-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Risk Score</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {analyticsData?.riskScore || 0}/100
                  </p>
                </div>
                <Target className="w-8 h-8 text-purple-600" />
              </div>
              <div className="flex items-center mt-2">
                <Badge className={
                  (analyticsData?.riskScore || 0) > 80 ? "bg-green-100 text-green-800" :
                  (analyticsData?.riskScore || 0) > 60 ? "bg-yellow-100 text-yellow-800" :
                  "bg-red-100 text-red-800"
                }>
                  {(analyticsData?.riskScore || 0) > 80 ? 'Low Risk' :
                   (analyticsData?.riskScore || 0) > 60 ? 'Medium Risk' : 'High Risk'}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Policy Distribution */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="covoria-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="w-5 h-5" />
                Policy Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <RechartsPieChart>
                  <Pie
                    data={analyticsData?.pieData || []}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {(analyticsData?.pieData || []).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </RechartsPieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Premium Trends */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card className="covoria-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Premium & Savings Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={analyticsData?.premiumTrends || []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="premiums" stackId="1" stroke="#8884d8" fill="#8884d8" />
                  <Area type="monotone" dataKey="savings" stackId="1" stroke="#82ca9d" fill="#82ca9d" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Insight Analytics */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
        <Card className="covoria-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Insights by Category
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={analyticsData?.insightData || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}