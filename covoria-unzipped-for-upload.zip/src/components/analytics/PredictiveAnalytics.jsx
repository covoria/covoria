import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { motion } from 'framer-motion';
import { 
    TrendingUp, 
    Calendar, 
    AlertTriangle, 
    Target,
    Brain,
    Clock,
    DollarSign,
    Lightbulb
} from 'lucide-react';
import { predictiveAnalytics } from '@/api/functions/predictiveAnalytics';

export default function PredictiveAnalytics({ refreshTrigger }) {
    const [predictions, setPredictions] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [selectedPrediction, setSelectedPrediction] = useState(null);

    useEffect(() => {
        loadPredictions();
    }, [refreshTrigger]);

    const loadPredictions = async () => {
        setIsLoading(true);
        try {
            const { data } = await predictiveAnalytics({ 
                analysis_type: 'comprehensive' 
            });
            
            if (data?.success) {
                setPredictions(data.data);
            }
        } catch (error) {
            console.error('Failed to load predictions:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const getProbabilityColor = (probability) => {
        if (probability >= 0.7) return 'text-red-600 bg-red-100';
        if (probability >= 0.5) return 'text-orange-600 bg-orange-100';
        return 'text-blue-600 bg-blue-100';
    };

    const getEventIcon = (event) => {
        switch (event) {
            case 'marriage': return '💒';
            case 'home_purchase': return '🏠';
            case 'first_child': return '👶';
            case 'career_advancement': return '📈';
            default: return '🎯';
        }
    };

    if (isLoading) {
        return (
            <Card className="covoria-card">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Brain className="w-5 h-5 text-purple-600" />
                        Predictive Analytics
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="animate-pulse space-y-3">
                        <div className="h-4 bg-gray-200 rounded"></div>
                        <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                        <div className="h-20 bg-gray-200 rounded"></div>
                    </div>
                </CardContent>
            </Card>
        );
    }

    if (!predictions || !predictions.life_event_predictions?.length) {
        return (
            <Card className="covoria-card">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Brain className="w-5 h-5 text-purple-600" />
                        Predictive Analytics
                    </CardTitle>
                </CardHeader>
                <CardContent className="text-center py-8">
                    <TrendingUp className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">Complete your profile to unlock predictive insights</p>
                    <Button 
                        onClick={loadPredictions} 
                        className="mt-4"
                        variant="outline"
                    >
                        Analyze Now
                    </Button>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="covoria-card">
            <CardHeader>
                <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Brain className="w-5 h-5 text-purple-600" />
                        Predictive Analytics
                    </div>
                    <Badge variant="outline" className="text-xs">
                        Life Stage: {predictions.user_profile_summary.life_stage?.replace('_', ' ')}
                    </Badge>
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                {/* Priority Predictions */}
                <div className="space-y-4">
                    <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                        <Target className="w-4 h-4 text-orange-500" />
                        Predicted Life Events
                    </h3>
                    
                    {predictions.life_event_predictions.map((prediction, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                            onClick={() => setSelectedPrediction(
                                selectedPrediction?.event === prediction.event ? null : prediction
                            )}
                        >
                            <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-3">
                                    <span className="text-2xl">{getEventIcon(prediction.event)}</span>
                                    <div>
                                        <h4 className="font-medium capitalize">
                                            {prediction.event.replace('_', ' ')}
                                        </h4>
                                        <div className="flex items-center gap-2 text-sm text-gray-600">
                                            <Clock className="w-3 h-3" />
                                            {prediction.timeline}
                                        </div>
                                    </div>
                                </div>
                                <Badge className={`${getProbabilityColor(prediction.probability)} text-xs`}>
                                    {Math.round(prediction.probability * 100)}% likely
                                </Badge>
                            </div>
                            
                            <Progress 
                                value={prediction.probability * 100} 
                                className="h-1 mb-2"
                            />
                            
                            {selectedPrediction?.event === prediction.event && (
                                <motion.div
                                    initial={{ opacity: 0, height: 0 }}
                                    animate={{ opacity: 1, height: 'auto' }}
                                    className="mt-4 pt-4 border-t space-y-3"
                                >
                                    <div>
                                        <h5 className="font-medium text-sm mb-2">Insurance Implications:</h5>
                                        <ul className="text-sm text-gray-600 space-y-1">
                                            {prediction.insurance_implications.map((impl, i) => (
                                                <li key={i} className="flex items-start gap-2">
                                                    <span className="text-orange-500 mt-1">•</span>
                                                    {impl}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    
                                    <div>
                                        <h5 className="font-medium text-sm mb-2">Recommended Actions:</h5>
                                        <ul className="text-sm text-gray-600 space-y-1">
                                            {prediction.recommended_actions.map((action, i) => (
                                                <li key={i} className="flex items-start gap-2">
                                                    <span className="text-green-500 mt-1">✓</span>
                                                    {action}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </motion.div>
                            )}
                        </motion.div>
                    ))}
                </div>

                {/* Market Trends */}
                {predictions.market_analysis && (
                    <div className="pt-4 border-t">
                        <h3 className="font-semibold text-gray-900 flex items-center gap-2 mb-3">
                            <TrendingUp className="w-4 h-4 text-blue-500" />
                            Market Trends
                        </h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {Object.entries(predictions.market_analysis.trends).map(([type, trend]) => (
                                <div key={type} className="bg-gray-50 rounded-lg p-3">
                                    <div className="flex items-center justify-between mb-2">
                                        <span className="font-medium capitalize text-sm">{type}</span>
                                        <Badge 
                                            variant="outline" 
                                            className={`text-xs ${
                                                parseFloat(trend.projected_change) > 0 
                                                    ? 'text-red-600' 
                                                    : 'text-green-600'
                                            }`}
                                        >
                                            {trend.projected_change > 0 ? '+' : ''}{trend.projected_change}%
                                        </Badge>
                                    </div>
                                    <p className="text-xs text-gray-600">
                                        {trend.current_rate_trend === 'increasing' ? '📈' : '📊'} 
                                        {' '}{trend.current_rate_trend}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* AI Insights */}
                {predictions.ai_insights && (
                    <div className="pt-4 border-t">
                        <h3 className="font-semibold text-gray-900 flex items-center gap-2 mb-3">
                            <Lightbulb className="w-4 h-4 text-yellow-500" />
                            AI Expert Analysis
                        </h3>
                        <div className="bg-blue-50 rounded-lg p-4">
                            <p className="text-sm text-gray-700 leading-relaxed">
                                {predictions.ai_insights}
                            </p>
                        </div>
                    </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2 pt-4">
                    <Button 
                        onClick={loadPredictions} 
                        disabled={isLoading}
                        className="flex-1"
                        variant="outline"
                    >
                        Refresh Analysis
                    </Button>
                    <Button 
                        className="flex-1 covoria-gradient text-white"
                        onClick={() => {/* Navigate to detailed view */}}
                    >
                        View Full Report
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}