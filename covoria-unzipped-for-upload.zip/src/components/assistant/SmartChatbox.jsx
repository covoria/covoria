import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  MessageCircle, 
  X, 
  Send, 
  Minimize2, 
  Maximize2,
  Lightbulb,
  DollarSign,
  Shield
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { InvokeLLM } from '@/api/integrations';

const SuggestedQuestions = ({ onQuestionClick, context }) => {
  const getContextualQuestions = () => {
    const base = [
      "What coverage gaps do I have?",
      "How can I reduce my monthly costs?",
      "Are my premiums competitive?"
    ];

    if (context?.hasExpiring) {
      base.unshift("I have policies expiring soon, what should I do?");
    }
    
    if (context?.hasHighSavings) {
      base.unshift("Show me my biggest savings opportunities");
    }

    return base.slice(0, 3);
  };

  return (
    <div className="space-y-2 mb-4">
      <p className="text-xs text-gray-500 mb-2">Suggested questions:</p>
      {getContextualQuestions().map((question, index) => (
        <button
          key={index}
          onClick={() => onQuestionClick(question)}
          className="w-full text-left p-2 text-sm bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
        >
          {question}
        </button>
      ))}
    </div>
  );
};

const ChatMessage = ({ message, isUser }) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className={`flex gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}
  >
    <div className={`max-w-[80%] p-3 rounded-lg ${
      isUser 
        ? 'bg-cyan-600 text-white' 
        : 'bg-gray-100 text-gray-900'
    }`}>
      <p className="text-sm">{message}</p>
    </div>
  </motion.div>
);

export default function SmartChatbox({ 
  userData, 
  isVisible = false, 
  onToggle,
  contextualTriggers = {}
}) {
  const [isOpen, setIsOpen] = useState(isVisible);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([{
        text: "Hi! I'm your AI assistant. I can help you with questions about your coverage, savings opportunities, and financial protection. What would you like to know?",
        isUser: false,
        timestamp: new Date()
      }]);
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (messageText = inputValue) => {
    if (!messageText.trim()) return;

    const userMessage = {
      text: messageText,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const context = `
        User's Insurance Policies: ${JSON.stringify(userData?.policies || [])}
        User's Savings Accounts: ${JSON.stringify(userData?.accounts || [])}
        User's Current Insights: ${JSON.stringify(userData?.insights || [])}
      `;

      const prompt = `
        You are Covoria's AI assistant. Answer the user's question based on their specific data.
        Keep responses conversational, helpful, and under 100 words.
        
        Context: ${context}
        
        User's question: ${messageText}
        
        If you identify specific coverage gaps or savings opportunities, mention them clearly.
        If the user asks about duplicates, analyze their policies for potential overlaps.
      `;

      const response = await InvokeLLM({ prompt });

      const assistantMessage = {
        text: response,
        isUser: false,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage = {
        text: "I'm having trouble right now. Please try again in a moment.",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }

    setIsLoading(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
    onToggle && onToggle(!isOpen);
  };

  const getContext = () => ({
    hasExpiring: userData?.policies?.some(p => {
      if (!p.end_date) return false;
      const endDate = new Date(p.end_date);
      const now = new Date();
      const daysUntilExpiry = (endDate - now) / (1000 * 60 * 60 * 24);
      return daysUntilExpiry <= 90 && daysUntilExpiry > 0;
    }),
    hasHighSavings: userData?.insights?.some(i => 
      !i.is_resolved && (i.potential_savings || 0) > 500
    )
  });

  return (
    <>
      {/* Chat Widget */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 right-6 w-80 bg-white rounded-2xl shadow-2xl border border-gray-200 z-50"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-cyan-100 rounded-lg">
                  <MessageCircle className="w-4 h-4 text-cyan-600" />
                </div>
                <span className="font-medium text-gray-900">AI Assistant</span>
              </div>
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsMinimized(!isMinimized)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleChat}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Chat Content */}
            <AnimatePresence>
              {!isMinimized && (
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: 'auto' }}
                  exit={{ height: 0 }}
                  className="overflow-hidden"
                >
                  {/* Messages */}
                  <div className="h-64 overflow-y-auto p-4 space-y-3">
                    {messages.map((message, index) => (
                      <ChatMessage
                        key={index}
                        message={message.text}
                        isUser={message.isUser}
                      />
                    ))}
                    
                    {isLoading && (
                      <div className="flex gap-2 justify-start">
                        <div className="bg-gray-100 p-3 rounded-lg">
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Suggested Questions (only show at start) */}
                  {messages.length <= 2 && (
                    <div className="px-4 pb-2">
                      <SuggestedQuestions 
                        onQuestionClick={handleSendMessage}
                        context={getContext()}
                      />
                    </div>
                  )}

                  {/* Input */}
                  <div className="p-4 border-t border-gray-100">
                    <div className="flex gap-2">
                      <Input
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder="Ask me anything..."
                        className="flex-1 text-sm"
                        disabled={isLoading}
                      />
                      <Button
                        onClick={() => handleSendMessage()}
                        disabled={!inputValue.trim() || isLoading}
                        size="sm"
                        className="bg-cyan-600 hover:bg-cyan-700 text-white"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Button */}
      {!isOpen && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="fixed bottom-6 right-6 z-50"
        >
          <Button
            onClick={toggleChat}
            className="w-14 h-14 rounded-full bg-cyan-600 hover:bg-cyan-700 text-white shadow-lg hover:shadow-xl transition-all duration-200"
          >
            <MessageCircle className="w-6 h-6" />
          </Button>
        </motion.div>
      )}
    </>
  );
}