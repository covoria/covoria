import React, { useState, useEffect } from 'react';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';

const emptyProduct = {
    name: '',
    category: 'life_insurance',
    description: '',
    target_audience: '',
    unique_selling_points: [],
    price_range: '',
    commission_rate: 0,
    is_active: true
};

export default function AddProductDialog({ open, onOpenChange, product, onSubmit }) {
    const [formData, setFormData] = useState(emptyProduct);
    const [uspInput, setUspInput] = useState('');

    useEffect(() => {
        if (product) {
            setFormData({ ...emptyProduct, ...product });
        } else {
            setFormData(emptyProduct);
        }
    }, [product, open]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSelectChange = (name, value) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleAddUsp = () => {
        if (uspInput.trim()) {
            setFormData(prev => ({
                ...prev,
                unique_selling_points: [...(prev.unique_selling_points || []), uspInput.trim()]
            }));
            setUspInput('');
        }
    };

    const handleRemoveUsp = (index) => {
        setFormData(prev => ({
            ...prev,
            unique_selling_points: prev.unique_selling_points.filter((_, i) => i !== index)
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(formData);
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[525px]">
                <DialogHeader>
                    <DialogTitle>{product ? 'Edit Product' : 'Add New Product'}</DialogTitle>
                    <DialogDescription>
                        Fill in the details for the new product.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="name">Product Name</Label>
                            <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="category">Category</Label>
                             <Select onValueChange={(v) => handleSelectChange('category', v)} value={formData.category}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select a category" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="life_insurance">Life Insurance</SelectItem>
                                    <SelectItem value="health_insurance">Health Insurance</SelectItem>
                                    <SelectItem value="auto_insurance">Auto Insurance</SelectItem>
                                    <SelectItem value="home_insurance">Home Insurance</SelectItem>
                                    <SelectItem value="disability_insurance">Disability Insurance</SelectItem>
                                    <SelectItem value="savings_plan">Savings Plan</SelectItem>
                                    <SelectItem value="retirement_plan">Retirement Plan</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} />
                    </div>
                    <div className="space-y-2">
                        <Label>Unique Selling Points</Label>
                        <div className="flex gap-2">
                            <Input value={uspInput} onChange={(e) => setUspInput(e.target.value)} placeholder="Add a feature..." />
                            <Button type="button" variant="outline" onClick={handleAddUsp}>Add</Button>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-2">
                            {formData.unique_selling_points?.map((usp, index) => (
                                <div key={index} className="flex items-center gap-1 bg-gray-100 rounded-full px-2 py-1 text-xs">
                                    <span>{usp}</span>
                                    <button type="button" onClick={() => handleRemoveUsp(index)}>&times;</button>
                                </div>
                            ))}
                        </div>
                    </div>
                     <div className="grid grid-cols-2 gap-4">
                         <div className="space-y-2">
                            <Label htmlFor="commission_rate">Commission Rate (%)</Label>
                            <Input id="commission_rate" name="commission_rate" type="number" value={formData.commission_rate} onChange={handleChange} />
                        </div>
                         <div className="flex items-center space-x-2 pt-6">
                            <Switch id="is_active" checked={formData.is_active} onCheckedChange={(c) => handleSelectChange('is_active', c)} />
                            <Label htmlFor="is_active">Product is Active</Label>
                        </div>
                    </div>
                     <DialogFooter>
                        <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button type="submit">{product ? 'Save Changes' : 'Create Product'}</Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}