import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Edit2, Save, FileText } from 'lucide-react';

export default function ProductCard({ product, onEdit, onNoteUpdate }) {
  const [internalNotes, setInternalNotes] = useState(product.internal_notes || '');
  const [isEditingNotes, setIsEditingNotes] = useState(false);

  const handleSaveNotes = () => {
    onNoteUpdate(product.id, internalNotes);
    setIsEditingNotes(false);
  };
  
  const categoryColors = {
    life_insurance: 'bg-blue-900/50 text-blue-300',
    health_insurance: 'bg-green-900/50 text-green-300',
    auto_insurance: 'bg-orange-900/50 text-orange-300',
    home_insurance: 'bg-purple-900/50 text-purple-300',
    disability_insurance: 'bg-indigo-900/50 text-indigo-300',
    savings_plan: 'bg-teal-900/50 text-teal-300',
    retirement_plan: 'bg-cyan-900/50 text-cyan-300',
  };

  return (
    <Card className="covoria-card flex flex-col h-full">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-white mb-2">{product.name}</CardTitle>
            <Badge className={categoryColors[product.category] || 'bg-slate-700 text-slate-300'}>
              {product.category.replace('_', ' ')}
            </Badge>
          </div>
          <Button variant="ghost" size="icon" onClick={() => onEdit(product)} className="text-slate-400 hover:text-white">
            <Edit2 className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="flex-grow space-y-4">
        <p className="text-sm text-slate-300 line-clamp-3">{product.description}</p>
        
        {product.target_market && (
          <div>
            <h4 className="text-xs text-slate-400 font-semibold mb-1">Target Market</h4>
            <Badge variant="outline" className="text-slate-300 border-slate-600">
              {product.target_market.replace('_', ' ')}
            </Badge>
          </div>
        )}

        <div>
            <h4 className="text-xs text-slate-400 font-semibold mb-2">Internal Notes</h4>
            {isEditingNotes ? (
              <Textarea 
                value={internalNotes}
                onChange={(e) => setInternalNotes(e.target.value)}
                className="bg-slate-800 border-slate-600 text-white text-sm"
              />
            ) : (
              <p className="text-sm text-slate-300 bg-slate-800/50 p-3 rounded-md min-h-[60px]">
                {internalNotes || 'No notes added.'}
              </p>
            )}
        </div>
      </CardContent>
      <CardFooter>
        {isEditingNotes ? (
          <Button onClick={handleSaveNotes} size="sm" className="w-full bg-green-600 hover:bg-green-700 text-white">
            <Save className="w-4 h-4 mr-2" />
            Save Notes
          </Button>
        ) : (
          <Button onClick={() => setIsEditingNotes(true)} size="sm" variant="outline" className="w-full text-slate-300 border-slate-600 hover:bg-slate-700">
            <FileText className="w-4 h-4 mr-2" />
            Edit Notes
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}