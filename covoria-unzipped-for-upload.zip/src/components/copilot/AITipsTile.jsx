import React from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Brain } from 'lucide-react';
import AITipsContent from './AITipsContent';

export default function AITipsTile({ insights }) {
  const tipInsights = insights.filter(i => 
    !i.is_resolved && (
      i.category === 'tip' || 
      i.category === 'advice' ||
      i.title?.toLowerCase().includes('tip') ||
      i.title?.toLowerCase().includes('advice')
    )
  );

  return (
    <Dialog>
      <DialogTrigger asChild>
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: 0.6, duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          whileHover={{ 
            scale: 1.05,
            boxShadow: "0 20px 40px -12px rgba(148, 163, 184, 0.5)"
          }}
          whileTap={{ scale: 0.98 }}
          className="bg-gradient-to-br from-gray-900 to-slate-700 text-white h-32 w-32 flex flex-col items-center justify-center text-center rounded-2xl shadow-lg hover:shadow-slate-500/50 transition-all duration-300 cursor-pointer border border-slate-600/30 relative overflow-hidden group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          <Brain className="w-7 h-7 mb-2 text-slate-100 drop-shadow-lg" strokeWidth={2.5} />
          <div className="text-sm font-semibold mt-1 px-2 leading-tight">AI Tips</div>
          {tipInsights.length > 0 ? (
            <div className="text-lg font-bold">{tipInsights.length}</div>
          ) : (
            <div className="text-md font-bold text-slate-200">New</div>
          )}
        </motion.div>
      </DialogTrigger>
      <DialogContent className="max-w-4xl h-[90vh] bg-slate-900/95 backdrop-blur-xl border border-slate-700/50 text-white shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-3">
             <Brain className="w-8 h-8 text-purple-400" />
             AI Tips & Recommendations
          </DialogTitle>
        </DialogHeader>
        <div className="overflow-y-auto custom-scrollbar pr-4 -mr-4">
          <AITipsContent insights={tipInsights} />
        </div>
      </DialogContent>
    </Dialog>
  );
}