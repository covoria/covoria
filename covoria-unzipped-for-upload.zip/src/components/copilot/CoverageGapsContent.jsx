import React from 'react';
import { ShieldAlert, ShieldCheck, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CoverageGapsContent({ insights, policies }) {
  const navigate = useNavigate();

  if (insights.length === 0) {
    return (
      <div className="text-center py-20 flex flex-col items-center">
        <ShieldCheck className="w-16 h-16 text-green-500 mb-4" />
        <h3 className="text-xl font-bold text-white mb-2">Great Coverage Profile!</h3>
        <p className="text-slate-400 mb-6">
          Based on your current policies, we haven't identified any critical coverage gaps. 
          Your protection strategy appears well-rounded.
        </p>
        <div className="bg-slate-800/50 rounded-xl p-4 max-w-md">
          <h4 className="text-white font-semibold mb-2">What We Analyzed:</h4>
          <ul className="text-sm text-slate-300 space-y-1">
            <li>• Life insurance adequacy</li>
            <li>• Income protection coverage</li>
            <li>• Health insurance coordination</li>
            <li>• Property protection levels</li>
          </ul>
        </div>
        <Button
          onClick={() => navigate(createPageUrl('Assistant') + '?prompt=Can you review my coverage one more time and suggest any optimizations?')}
          className="mt-6 bg-green-600 hover:bg-green-700"
        >
          Ask AI for Optimization Tips
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-rose-900/20 border border-rose-800/50 rounded-xl p-4 mb-6">
        <div className="flex items-center gap-3 mb-2">
          <ShieldAlert className="w-5 h-5 text-rose-400" />
          <h3 className="text-lg font-semibold text-white">Coverage Gaps Detected</h3>
        </div>
        <p className="text-rose-200 text-sm">
          We've identified {insights.length} potential gap{insights.length > 1 ? 's' : ''} in your coverage. 
          Review these recommendations to strengthen your protection.
        </p>
      </div>

      {insights.map((insight, index) => (
        <div key={insight.id} className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-rose-900/50 flex items-center justify-center">
                <span className="text-rose-400 font-bold text-sm">{index + 1}</span>
              </div>
              <div>
                <h4 className="text-white font-semibold">{insight.title}</h4>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  insight.priority === 'critical' ? 'bg-red-900/50 text-red-300' :
                  insight.priority === 'high' ? 'bg-orange-900/50 text-orange-300' :
                  'bg-yellow-900/50 text-yellow-300'
                }`}>
                  {insight.priority} priority
                </span>
              </div>
            </div>
          </div>
          
          <p className="text-slate-300 mb-4">{insight.description}</p>
          
          {insight.action_required && (
            <div className="bg-slate-900/50 rounded-lg p-3 mb-4">
              <h5 className="text-cyan-400 font-medium text-sm mb-1">Recommended Action:</h5>
              <p className="text-slate-300 text-sm">{insight.action_required}</p>
            </div>
          )}
          
          <div className="flex gap-2">
            <Button
              size="sm"
              onClick={() => navigate(createPageUrl('Assistant') + `?prompt=Tell me more about this coverage gap: ${insight.title}`)}
              className="bg-cyan-600 hover:bg-cyan-700 text-white"
            >
              Get AI Advice
            </Button>
            {insight.related_policies && insight.related_policies.length > 0 && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => navigate(createPageUrl('Insurance'))}
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                View Related Policies
              </Button>
            )}
          </div>
        </div>
      ))}
      
      <div className="mt-8 text-center">
        <Button
          onClick={() => navigate(createPageUrl('Assistant') + '?prompt=Help me create a plan to address all my coverage gaps')}
          className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500"
        >
          Create Action Plan with AI
        </Button>
      </div>
    </div>
  );
}