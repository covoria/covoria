import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ShieldAlert, ShieldCheck } from 'lucide-react';
import CoverageGapsContent from './CoverageGapsContent';
import { Skeleton } from '@/components/ui/skeleton';

export default function CoverageGapsTile({ count, isLoading, insights = [] }) {
  const gapInsights = Array.isArray(insights) ? insights.filter(i => !i.is_resolved && i.category === 'coverage_gap') : [];
  const gapCount = count !== undefined ? count : gapInsights.length;

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card className="h-full bg-slate-800/50 border border-slate-700 hover:border-slate-600 transition-colors flex flex-col justify-between cursor-pointer">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-300">Coverage Gaps</CardTitle>
            {isLoading ? <div className="w-4 h-4 rounded-full bg-slate-700 animate-pulse"></div> : (gapCount > 0 ? <ShieldAlert className="w-4 h-4 text-rose-400" /> : <ShieldCheck className="w-4 h-4 text-green-400" />)}
          </CardHeader>
          <CardContent>
            {isLoading ? (
                <>
                    <Skeleton className="h-8 w-12 mb-2 bg-slate-700" />
                    <Skeleton className="h-4 w-24 bg-slate-700" />
                </>
            ) : (
                <>
                    <div className="text-2xl font-bold text-white">{gapCount}</div>
                    <p className="text-xs text-slate-400">
                        {gapCount > 0 ? `${gapCount} potential gap${gapCount > 1 ? 's' : ''} found` : 'No coverage gaps found'}
                    </p>
                </>
            )}
          </CardContent>
        </Card>
      </DialogTrigger>
      <DialogContent className="max-w-4xl h-[90vh] bg-slate-900/95 backdrop-blur-xl border border-slate-700/50 text-white shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-3">
             <ShieldAlert className="w-8 h-8 text-rose-400" />
             Coverage Gap Analysis
          </DialogTitle>
        </DialogHeader>
        <div className="overflow-y-auto custom-scrollbar pr-4 -mr-4">
          <CoverageGapsContent insights={gapInsights} />
        </div>
      </DialogContent>
    </Dialog>
  );
}