import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Lightbulb, ArrowRight, RefreshCw } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function CurrentInsightsTile({ insights, isLoading }) {
    const activeInsights = insights.filter(i => !i.is_resolved);

    return (
        <Card className="h-full bg-slate-800/50 border border-slate-700 hover:border-slate-600 transition-colors">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">Current Insights</CardTitle>
                <Lightbulb className="w-4 h-4 text-slate-500" />
            </CardHeader>
            <CardContent>
                {isLoading ? (
                    <>
                        <Skeleton className="h-12 w-1/2 mb-2 bg-slate-700" />
                        <Skeleton className="h-4 w-3/4 bg-slate-700" />
                    </>
                ) : (
                    <>
                        <div className="text-2xl font-bold text-white">{activeInsights.length}</div>
                        <p className="text-xs text-slate-400">
                            {activeInsights.length > 0 ? `${activeInsights.filter(i => i.priority === 'critical').length} critical issues` : 'All clear! No new insights.'}
                        </p>
                    </>
                )}
            </CardContent>
        </Card>
    );
}