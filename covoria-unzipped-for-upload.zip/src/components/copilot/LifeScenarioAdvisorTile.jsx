import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { Layers, Home, UserPlus, Briefcase, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

export default function LifeScenarioAdvisorTile({ isLoading }) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card className="h-full bg-slate-800/50 border border-slate-700 hover:border-slate-600 transition-colors flex flex-col justify-between cursor-pointer">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-300">Life Scenarios</CardTitle>
            <Layers className="w-4 h-4 text-slate-500" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
                <>
                    <Skeleton className="h-8 w-12 mb-2 bg-slate-700" />
                    <Skeleton className="h-4 w-24 bg-slate-700" />
                </>
            ) : (
                <>
                    <div className="text-2xl font-bold text-white">Simulate</div>
                    <p className="text-xs text-slate-400">Prepare for what's next</p>
                </>
            )}
          </CardContent>
        </Card>
      </DialogTrigger>
      <DialogContent className="max-w-md bg-slate-900/95 backdrop-blur-xl border border-slate-700/50 text-white shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-3">
             <Layers className="w-8 h-8 text-cyan-400" />
             Life Scenario Advisor
          </DialogTitle>
           <DialogDescription className="text-slate-400 pt-2">
            Choose a scenario to see how your coverage adapts and what new risks might emerge.
           </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
            <Button variant="outline" className="w-full justify-start h-14 border-slate-700 hover:bg-slate-800 text-base">
                <Home className="w-5 h-5 mr-4 text-slate-400"/>
                Buying a House
            </Button>
            <Button variant="outline" className="w-full justify-start h-14 border-slate-700 hover:bg-slate-800 text-base">
                <UserPlus className="w-5 h-5 mr-4 text-slate-400"/>
                Having a Child
            </Button>
            <Button variant="outline" className="w-full justify-start h-14 border-slate-700 hover:bg-slate-800 text-base">
                <Briefcase className="w-5 h-5 mr-4 text-slate-400"/>
                Losing a Job
            </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}