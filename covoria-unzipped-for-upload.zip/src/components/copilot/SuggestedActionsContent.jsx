import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle, ArrowRight, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

// This is the content for the Suggested Actions Dialog
export default function SuggestedActionsContent({ insights }) {
  const actionInsights = insights.filter(i => !i.is_resolved && i.action_required);

  return (
    <div className="space-y-4">
      {actionInsights.length > 0 ? (
        actionInsights.map((insight, index) => (
          <motion.div
            key={insight.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="covoria-card">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-yellow-500/10 rounded-full flex-shrink-0">
                    <Zap className="w-4 h-4 text-yellow-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-white font-semibold mb-2">{insight.title}</h3>
                    <p className="text-slate-300 text-sm mb-3">{insight.description}</p>
                    
                    <div className="p-3 bg-cyan-900/20 border border-cyan-700/30 rounded-lg">
                      <h4 className="text-cyan-300 font-semibold mb-2 flex items-center gap-2">
                        <ArrowRight className="w-4 h-4" />
                        Recommended Action
                      </h4>
                      <p className="text-slate-200 text-sm">
                        {insight.action_required}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))
      ) : (
        <div className="text-center py-20 flex flex-col items-center">
          <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
          <h3 className="text-xl font-bold text-white">All Caught Up!</h3>
          <p className="text-slate-400">No pending actions at this time. Great job staying on top of your financial health!</p>
        </div>
      )}
    </div>
  );
}