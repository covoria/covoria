import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageCircle, Sparkles, Brain } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function AssistantCTA() {
  const navigate = useNavigate();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="mb-8"
    >
      <Card className="relative overflow-hidden bg-slate-800/50 border border-slate-700/50 backdrop-blur-sm">
        <CardContent className="relative p-4 sm:p-6 text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <motion.div
                animate={{
                  scale: [1, 1.05, 1],
                  filter: ['brightness(1)', 'brightness(1.5)', 'brightness(1)'],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="relative bg-slate-700 p-3 rounded-full"
              >
                <Brain className="w-6 h-6 sm:w-8 sm:h-8 text-cyan-400" />
              </motion.div>
            </div>
          </div>
          
          <h3 className="text-lg sm:text-xl font-bold text-white mb-2 flex items-center justify-center gap-2">
            AI Financial Advisor
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400" />
          </h3>
          
          <p className="text-slate-300 mb-4 mobile-safe-text text-sm sm:text-base leading-relaxed">
            Get personalized insurance advice based on your profile and policies
          </p>
          
          <Button 
            onClick={() => navigate(createPageUrl('Assistant'))}
            className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold px-4 py-2 sm:px-6 sm:py-3 rounded-xl shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 transform hover:scale-105 text-sm sm:text-base"
          >
            <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
            Chat with AI Advisor
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}