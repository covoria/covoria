import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  AlertTriangle, 
  CheckCircle, 
  DollarSign,
  PieChart,
  TrendingDown,
  TrendingUp
} from 'lucide-react';
import { motion } from 'framer-motion';
import { User } from '@/api/entities';
import { InsurancePolicy } from '@/api/entities';
import { SavingsAccount } from '@/api/entities';
import { Insight } from '@/api/entities';

export default function ConversationalSnapshot({ onComplete, trigger = 'manual' }) {
  const [snapshot, setSnapshot] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showSnapshot, setShowSnapshot] = useState(false);

  useEffect(() => {
    if (trigger === 'auto') {
      generateSnapshot();
    }
  }, [trigger]);

  const generateSnapshot = async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      const [policies, accounts, insights] = await Promise.all([
        InsurancePolicy.filter({ created_by: user.email }),
        SavingsAccount.filter({ created_by: user.email }),
        Insight.filter({ created_by: user.email, is_resolved: false })
      ]);

      const analysis = analyzeUserPortfolio(policies, accounts, insights);
      setSnapshot(analysis);
      setShowSnapshot(true);
      
      if (onComplete) onComplete(analysis);
    } catch (error) {
      console.error('Failed to generate snapshot:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const analyzeUserPortfolio = (policies, accounts, insights) => {
    const activePolicies = policies.filter(p => p.is_active !== false);
    const totalCoverage = activePolicies.reduce((sum, p) => sum + (p.coverage_amount || 0), 0);
    const monthlyPremiums = activePolicies.reduce((sum, p) => {
      const monthly = p.premium_frequency === 'annually' ? (p.premium_amount || 0) / 12 : (p.premium_amount || 0);
      return sum + monthly;
    }, 0);

    const totalSavings = accounts.reduce((sum, a) => sum + (a.current_balance || 0), 0);
    const potentialSavings = insights
      .filter(i => i.potential_savings && i.potential_savings > 0)
      .reduce((sum, i) => sum + i.potential_savings, 0);

    // Detect gaps and overlaps
    const coverageGaps = detectCoverageGaps(activePolicies);
    const overlaps = detectOverlaps(activePolicies);

    return {
      summary: generateConversationalSummary(activePolicies, accounts, insights),
      metrics: {
        totalPolicies: activePolicies.length,
        totalCoverage: totalCoverage,
        monthlyPremiums: monthlyPremiums,
        totalSavings: totalSavings,
        potentialSavings: potentialSavings
      },
      insights: {
        gaps: coverageGaps,
        overlaps: overlaps,
        optimizations: insights.filter(i => i.category === 'optimization').length
      },
      scorecard: calculateCoverageScore(activePolicies, coverageGaps, overlaps)
    };
  };

  const generateConversationalSummary = (policies, accounts, insights) => {
    const policyCount = policies.length;
    const accountCount = accounts.length;
    const urgentInsights = insights.filter(i => i.priority === 'high' || i.priority === 'critical').length;

    if (policyCount === 0 && accountCount === 0) {
      return "You're just getting started! Let's build your financial protection foundation together.";
    }

    if (policyCount > 0 && urgentInsights === 0) {
      return `Looking good! You have ${policyCount} active ${policyCount === 1 ? 'policy' : 'policies'} and your coverage appears well-balanced.`;
    }

    if (urgentInsights > 0) {
      return `You have ${policyCount} ${policyCount === 1 ? 'policy' : 'policies'}, but I found ${urgentInsights} important ${urgentInsights === 1 ? 'area' : 'areas'} that need your attention.`;
    }

    return `You have ${policyCount} ${policyCount === 1 ? 'policy' : 'policies'} and ${accountCount} savings ${accountCount === 1 ? 'account' : 'accounts'}. Your financial foundation is taking shape!`;
  };

  const detectCoverageGaps = (policies) => {
    const essentialTypes = ['health', 'life', 'auto', 'home'];
    const coveredTypes = policies.map(p => p.insurance_type);
    return essentialTypes.filter(type => !coveredTypes.includes(type));
  };

  const detectOverlaps = (policies) => {
    const typeCounts = {};
    policies.forEach(p => {
      typeCounts[p.insurance_type] = (typeCounts[p.insurance_type] || 0) + 1;
    });
    return Object.entries(typeCounts).filter(([type, count]) => count > 1);
  };

  const calculateCoverageScore = (policies, gaps, overlaps) => {
    let score = 70; // Base score
    score += policies.length * 5; // +5 for each policy
    score -= gaps.length * 10; // -10 for each gap
    score -= overlaps.length * 5; // -5 for each overlap
    return Math.max(0, Math.min(100, score));
  };

  if (!showSnapshot && !isLoading) {
    return (
      <Card className="covoria-card">
        <CardContent className="p-6 text-center">
          <PieChart className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">
            Get Your Coverage Snapshot
          </h3>
          <p className="text-slate-400 text-sm mb-4">
            Instant analysis of your insurance portfolio with personalized insights.
          </p>
          <Button
            onClick={generateSnapshot}
            disabled={isLoading}
            className="covoria-gradient text-white"
          >
            {isLoading ? 'Analyzing...' : 'Generate My Snapshot'}
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="covoria-card">
        <CardContent className="p-6 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-slate-400">Analyzing your coverage...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="space-y-4"
    >
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <PieChart className="w-5 h-5 text-cyan-400" />
            Your Coverage Snapshot
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Conversational Summary */}
          <div className="p-4 bg-cyan-900/20 border border-cyan-700/30 rounded-lg">
            <p className="text-cyan-100 leading-relaxed">
              {snapshot.summary}
            </p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">
                {snapshot.metrics.totalPolicies}
              </div>
              <div className="text-xs text-slate-400">Active Policies</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">
                ${Math.round(snapshot.metrics.totalCoverage / 1000)}K
              </div>
              <div className="text-xs text-slate-400">Total Coverage</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-400">
                ${Math.round(snapshot.metrics.monthlyPremiums)}
              </div>
              <div className="text-xs text-slate-400">Monthly Premiums</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">
                {snapshot.scorecard}
              </div>
              <div className="text-xs text-slate-400">Coverage Score</div>
            </div>
          </div>

          {/* Insights Summary */}
          <div className="space-y-3">
            {snapshot.insights.gaps.length > 0 && (
              <div className="flex items-center gap-3 p-3 bg-red-900/20 border border-red-700/30 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-400" />
                <div>
                  <div className="text-sm font-medium text-red-300">
                    {snapshot.insights.gaps.length} Coverage Gap{snapshot.insights.gaps.length > 1 ? 's' : ''} Found
                  </div>
                  <div className="text-xs text-red-400">
                    Missing: {snapshot.insights.gaps.join(', ')}
                  </div>
                </div>
              </div>
            )}

            {snapshot.insights.overlaps.length > 0 && (
              <div className="flex items-center gap-3 p-3 bg-yellow-900/20 border border-yellow-700/30 rounded-lg">
                <TrendingDown className="w-5 h-5 text-yellow-400" />
                <div>
                  <div className="text-sm font-medium text-yellow-300">
                    {snapshot.insights.overlaps.length} Potential Overlap{snapshot.insights.overlaps.length > 1 ? 's' : ''}
                  </div>
                  <div className="text-xs text-yellow-400">
                    May be costing you extra
                  </div>
                </div>
              </div>
            )}

            {snapshot.metrics.potentialSavings > 0 && (
              <div className="flex items-center gap-3 p-3 bg-green-900/20 border border-green-700/30 rounded-lg">
                <TrendingUp className="w-5 h-5 text-green-400" />
                <div>
                  <div className="text-sm font-medium text-green-300">
                    ${Math.round(snapshot.metrics.potentialSavings)} Potential Annual Savings
                  </div>
                  <div className="text-xs text-green-400">
                    From optimization opportunities
                  </div>
                </div>
              </div>
            )}

            {snapshot.insights.gaps.length === 0 && snapshot.insights.overlaps.length === 0 && (
              <div className="flex items-center gap-3 p-3 bg-green-900/20 border border-green-700/30 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <div className="text-sm font-medium text-green-300">
                  Your coverage looks well-balanced!
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}