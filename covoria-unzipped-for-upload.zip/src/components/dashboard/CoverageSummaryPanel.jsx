import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Shield, Lightbulb, ArrowRight, X, AlertTriangle, DollarSign, Target } from 'lucide-react';
import { InsurancePolicy, SavingsAccount, Insight, User } from '@/api/entities';
import { Skeleton } from '@/components/ui/skeleton';
import { motion, AnimatePresence } from 'framer-motion';

const InteractivePieChart = ({ data, onSliceClick }) => {
  const { policiesByType } = data;
  const total = Object.values(policiesByType).reduce((sum, count) => sum + count, 0);
  
  if (total === 0) {
    return (
      <div className="relative w-48 h-48 mx-auto cursor-pointer" onClick={() => onSliceClick()}>
        <svg width="192" height="192" viewBox="0 0 192 192" className="transform -rotate-90">
          <circle
            cx="96"
            cy="96"
            r="80"
            fill="none"
            stroke="#e5e7eb"
            strokeWidth="32"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <Shield className="w-8 h-8 text-gray-400 mb-2" />
          <div className="text-sm text-gray-500 text-center">No Policies</div>
        </div>
      </div>
    );
  }

  const colors = {
    health: '#10b981',
    auto: '#3b82f6', 
    life: '#8b5cf6',
    home: '#f59e0b',
    disability: '#ef4444',
    other: '#6b7280'
  };

  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  let currentAngle = 0;

  const slices = Object.entries(policiesByType).map(([type, count]) => {
    const percentage = count / total;
    const sliceAngle = percentage * 360;
    const strokeDasharray = `${percentage * circumference} ${circumference}`;
    const strokeDashoffset = -currentAngle * (circumference / 360);
    
    const slice = {
      type,
      count,
      percentage,
      color: colors[type] || colors.other,
      strokeDasharray,
      strokeDashoffset,
      startAngle: currentAngle,
      endAngle: currentAngle + sliceAngle
    };
    
    currentAngle += sliceAngle;
    return slice;
  });

  return (
    <div className="relative w-48 h-48 mx-auto cursor-pointer group" onClick={() => onSliceClick()}>
      <svg width="192" height="192" viewBox="0 0 192 192" className="transform -rotate-90">
        {slices.map((slice, index) => (
          <circle
            key={slice.type}
            cx="96"
            cy="96"
            r="80"
            fill="none"
            stroke={slice.color}
            strokeWidth="32"
            strokeDasharray={slice.strokeDasharray}
            strokeDashoffset={slice.strokeDashoffset}
            className="transition-all duration-300 hover:stroke-width-[36]"
            style={{
              filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.1))'
            }}
          />
        ))}
      </svg>
      
      {/* Center content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-3xl font-bold text-gray-900">{total}</div>
        <div className="text-sm text-gray-500 text-center">Active Policies</div>
      </div>
      
      {/* Hover effect */}
      <div className="absolute inset-0 bg-black/5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
    </div>
  );
};

const PolicyTypeLegend = ({ policiesByType }) => {
  const colors = {
    health: '#10b981',
    auto: '#3b82f6',
    life: '#8b5cf6', 
    home: '#f59e0b',
    disability: '#ef4444',
    other: '#6b7280'
  };

  const typeLabels = {
    health: 'Health',
    auto: 'Auto',
    life: 'Life',
    home: 'Home',
    disability: 'Disability',
    other: 'Other'
  };

  return (
    <div className="grid grid-cols-2 gap-3 mt-6">
      {Object.entries(policiesByType).map(([type, count]) => (
        <div key={type} className="flex items-center gap-2">
          <div 
            className="w-4 h-4 rounded-full"
            style={{ backgroundColor: colors[type] || colors.other }}
          />
          <span className="text-sm text-gray-700">{typeLabels[type] || type}</span>
          <span className="text-sm font-semibold text-gray-900">({count})</span>
        </div>
      ))}
    </div>
  );
};

const ExpandedPanel = ({ data, isOpen, onClose }) => {
  const { summaryData, policiesByType } = data;
  
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40"
            onClick={onClose}
          />
          
          {/* Panel */}
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 bg-white rounded-t-3xl shadow-2xl z-50 max-h-[80vh] overflow-y-auto"
          >
            <div className="p-6">
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-900">Coverage Details</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="rounded-full"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Policy Type Breakdown */}
              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Policy Breakdown</h4>
                <PolicyTypeLegend policiesByType={policiesByType} />
              </div>

              {/* Key Metrics */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-blue-50 rounded-xl p-4 text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    ${(summaryData.monthlyPremiums || 0).toLocaleString()}
                  </div>
                  <div className="text-sm text-blue-700">Monthly Premiums</div>
                </div>
                
                <div className="bg-green-50 rounded-xl p-4 text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {summaryData.activePolicies || 0}
                  </div>
                  <div className="text-sm text-green-700">Active Policies</div>
                </div>
              </div>

              {/* Alerts */}
              <div className="space-y-3 mb-8">
                {(summaryData.coverageGaps > 0 || summaryData.duplicatePolicies > 0) && (
                  <div className="bg-orange-50 border border-orange-200 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="w-5 h-5 text-orange-600" />
                      <span className="font-semibold text-orange-800">Attention Required</span>
                    </div>
                    <div className="space-y-1 text-sm text-orange-700">
                      {summaryData.coverageGaps > 0 && (
                        <div>• {summaryData.coverageGaps} coverage gap{summaryData.coverageGaps > 1 ? 's' : ''} detected</div>
                      )}
                      {summaryData.duplicatePolicies > 0 && (
                        <div>• {summaryData.duplicatePolicies} duplicate polic{summaryData.duplicatePolicies > 1 ? 'ies' : 'y'} found</div>
                      )}
                    </div>
                  </div>
                )}

                {summaryData.potentialSavings > 0 && (
                  <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <DollarSign className="w-5 h-5 text-green-600" />
                      <span className="font-semibold text-green-800">Savings Opportunity</span>
                    </div>
                    <div className="text-sm text-green-700">
                      Potential annual savings: ${summaryData.potentialSavings.toLocaleString()}
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Link to={createPageUrl('CoverageAnalysis')} className="block">
                  <Button className="w-full bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white gap-2 py-6 text-lg rounded-xl">
                    <Target className="w-5 h-5" />
                    🔍 View Full Analysis
                  </Button>
                </Link>
                
                <Link to={createPageUrl('Assistant')} className="block">
                  <Button variant="outline" className="w-full gap-2 py-4 rounded-xl border-2">
                    <Lightbulb className="w-5 h-5" />
                    💡 Get AI Recommendations
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default function CoverageSummaryPanel() {
  const [summaryData, setSummaryData] = useState(null);
  const [userName, setUserName] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    loadSummaryData();
    loadUserName();
  }, []);

  const loadUserName = async () => {
    try {
      const user = await User.me();
      const firstName = user.full_name ? user.full_name.split(' ')[0] : 'there';
      setUserName(firstName);
    } catch (error) {
      setUserName('there');
    }
  };

  const loadSummaryData = async () => {
    setIsLoading(true);
    try {
      const [policies, accounts, insights] = await Promise.all([
        InsurancePolicy.list(),
        SavingsAccount.list(),
        Insight.list()
      ]);

      const activePolicies = policies.filter(p => p.is_active).length;

      const monthlyPremiums = policies
        .filter(p => p.is_active)
        .reduce((sum, policy) => {
          const monthlyPremium = policy.premium_frequency === 'annually'
            ? (policy.premium_amount || 0) / 12
            : policy.premium_frequency === 'quarterly'
            ? (policy.premium_amount || 0) / 3
            : (policy.premium_amount || 0);
          return sum + monthlyPremium;
        }, 0);

      const coverageGaps = insights.filter(i =>
        i.category === 'coverage_gap' && !i.is_resolved
      ).length;

      const duplicatePolicies = findDuplicatePolicies(policies);
      
      const potentialSavings = insights
        .filter(i => !i.is_resolved && i.potential_savings)
        .reduce((sum, insight) => sum + (insight.potential_savings || 0), 0);

      // Group policies by type for pie chart
      const policiesByType = {};
      policies.filter(p => p.is_active).forEach(policy => {
        const type = policy.insurance_type || 'other';
        policiesByType[type] = (policiesByType[type] || 0) + 1;
      });

      setSummaryData({
        activePolicies,
        monthlyPremiums,
        coverageGaps,
        duplicatePolicies,
        potentialSavings,
        policiesByType
      });
    } catch (error) {
      console.error("Error loading summary data:", error);
      setSummaryData({
        activePolicies: 0,
        monthlyPremiums: 0,
        coverageGaps: 0,
        duplicatePolicies: 0,
        potentialSavings: 0,
        policiesByType: {}
      });
    }
    setIsLoading(false);
  };

  const findDuplicatePolicies = (policies) => {
    const typeGroups = {};
    policies.forEach(policy => {
      if (policy.insurance_type) {
        if (!typeGroups[policy.insurance_type]) {
          typeGroups[policy.insurance_type] = [];
        }
        typeGroups[policy.insurance_type].push(policy);
      }
    });

    let duplicateCount = 0;
    Object.values(typeGroups).forEach(group => {
      if (group.length > 1) {
        duplicateCount += (group.length - 1);
      }
    });
    return duplicateCount;
  };

  const handleChartClick = () => {
    setIsExpanded(true);
  };

  if (isLoading) {
    return (
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="covoria-card p-6 md:p-8 mb-8 bg-gradient-to-r from-teal-50 to-cyan-50 border-teal-200">
          <div className="text-center">
            <Skeleton className="w-48 h-48 rounded-full mx-auto mb-6" />
            <Skeleton className="h-8 w-64 mx-auto mb-4" />
            <div className="grid grid-cols-2 gap-3 max-w-xs mx-auto">
              {Array(4).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-6 w-full" />
              ))}
            </div>
          </div>
        </Card>
      </motion.div>
    );
  }

  return (
    <>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="covoria-card p-6 md:p-8 mb-8 bg-gradient-to-r from-teal-50 to-cyan-50 border-teal-200 hover:shadow-xl transition-all duration-300">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Hi {userName}, here is your Coverage Summary
            </h2>
            
            <InteractivePieChart 
              data={{ 
                summaryData, 
                policiesByType: summaryData?.policiesByType || {} 
              }}
              onSliceClick={handleChartClick}
            />
            
            <PolicyTypeLegend policiesByType={summaryData?.policiesByType || {}} />

            <div className="pt-6 mt-6 border-t border-teal-200">
              <Button 
                onClick={handleChartClick}
                className="bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 px-6 rounded-lg text-lg transition-colors shadow-lg"
              >
                <Lightbulb className="w-6 h-6 mr-3" />
                💡 Tap here for full AI Recommendations
              </Button>
            </div>
          </div>
        </Card>
      </motion.div>

      <ExpandedPanel
        data={{ 
          summaryData: summaryData || {}, 
          policiesByType: summaryData?.policiesByType || {} 
        }}
        isOpen={isExpanded}
        onClose={() => setIsExpanded(false)}
      />
    </>
  );
}