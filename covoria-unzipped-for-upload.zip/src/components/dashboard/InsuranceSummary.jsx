
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, TrendingUp, DollarSign, Eye, AlertTriangle, FileText } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { InsurancePolicy } from '@/api/entities';
import { User } from '@/api/entities';

export default function InsuranceSummary() {
  const [policies, setPolicies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    loadPolicies();
    
    // Auto-refresh when data changes
    const handleDataUpdate = () => {
      console.log('🚀 [InsuranceSummary] Data update detected, refreshing policies');
      loadPolicies();
    };
    
    window.addEventListener('storage', handleDataUpdate);
    window.addEventListener('focus', handleDataUpdate);
    
    return () => {
      window.removeEventListener('storage', handleDataUpdate);
      window.removeEventListener('focus', handleDataUpdate);
    };
  }, []);

  const loadPolicies = async () => {
    setIsLoading(true);
    setError(null);
    try {
      console.log('🚀 [InsuranceSummary] Loading policies...');
      const user = await User.me();
      const userPolicies = await InsurancePolicy.filter({ created_by: user.email });
      console.log('🚀 [InsuranceSummary] Loaded policies:', userPolicies.length);
      setPolicies(Array.isArray(userPolicies) ? userPolicies : []);
    } catch (error) {
      console.error('🚀 [InsuranceSummary] Failed to load policies:', error);
      setError('Failed to load policies');
      setPolicies([]);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <Card className="covoria-card">
        <CardHeader>
          <Skeleton className="h-6 w-3/4" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  // Ensure policies is always an array
  const safePolicies = Array.isArray(policies) ? policies : [];
  const activePolicies = safePolicies.filter(p => p.is_active !== false);
  
  const totalCoverage = activePolicies.reduce((sum, p) => sum + (p.coverage_amount || 0), 0);
  const monthlyPremiums = activePolicies.reduce((sum, p) => {
    const monthly = p.premium_frequency === 'annually'
      ? (p.premium_amount || 0) / 12
      : p.premium_frequency === 'quarterly'
      ? (p.premium_amount || 0) / 3
      : (p.premium_amount || 0);
    return sum + monthly;
  }, 0);
  
  const coverageGaps = 0; // No fake gap detection
  const recentPolicies = safePolicies.slice(0, 3);

  const formatCurrency = (amount) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`;
    return `$${amount}`;
  };

  const getInsuranceTypeIcon = (type) => {
    switch(type) {
      case 'health': return '🏥';
      case 'auto': return '🚗';
      case 'life': return '👤';
      case 'home': return '🏠';
      case 'disability': return '🛡️';
      default: return '📋';
    }
  };

  if (error) {
    return (
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="w-6 h-6 text-cyan-400" />
            Insurance Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <AlertTriangle className="w-8 h-8 text-red-400 mx-auto mb-2" />
            <p className="text-red-400 text-sm">{error}</p>
            <Button onClick={loadPolicies} variant="outline" className="mt-3" size="sm">
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="covoria-card overflow-hidden">
        <CardHeader>
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-3 min-w-0 flex-1">
              <Shield className="w-6 h-6 text-cyan-400 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                  <CardTitle className="text-white text-lg sm:text-xl">Insurance Overview</CardTitle>
                  <p className="text-slate-400 text-xs sm:text-sm">Policies & Coverage Summary</p>
              </div>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <Button 
                variant="outline" 
                onClick={() => navigate(createPageUrl('Insurance'))}
                className="bg-slate-700 text-slate-200 hover:bg-slate-600 border-slate-600 rounded-lg"
              >
                <Eye className="w-4 h-4 mr-2" />
                View All
              </Button>
            </div>
          </div>
        </CardHeader>

        {safePolicies.length > 0 ? (
          <CardContent className="space-y-6">
            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-xl border border-blue-200 dark:border-blue-700/30">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <p className="text-xs font-medium text-blue-700 dark:text-blue-300">Total Coverage</p>
                </div>
                <p className="text-lg font-bold text-blue-900 dark:text-blue-100">{formatCurrency(totalCoverage)}</p>
              </div>

              <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-xl border border-green-200 dark:border-green-700/30">
                <div className="flex items-center gap-2 mb-2">
                  <DollarSign className="w-4 h-4 text-green-600 dark:text-green-400" />
                  <p className="text-xs font-medium text-green-700 dark:text-green-300">Monthly Premiums</p>
                </div>
                <p className="text-lg font-bold text-green-900 dark:text-green-100">${Math.round(monthlyPremiums).toLocaleString()}</p>
              </div>

              <div className="p-4 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900/20 dark:to-gray-800/20 border-gray-200 dark:border-gray-700/30 border rounded-xl col-span-2 md:col-span-1">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                  <p className="text-xs font-medium text-gray-700 dark:text-gray-300">Coverage Gaps</p>
                </div>
                <div className="flex items-center gap-2">
                  <p className="text-lg font-bold text-gray-900 dark:text-gray-100">{coverageGaps}</p>
                  <span className="text-xs text-green-600 dark:text-green-400 font-medium">All covered ✓</span>
                </div>
              </div>
            </div>

            {/* Recent Policies */}
            <div>
              <h3 className="text-lg font-semibold text-slate-200 mb-4">Recent Policies</h3>
              <div className="space-y-3">
                {recentPolicies.length > 0 ? (
                  recentPolicies.map((policy, index) => (
                    <motion.div
                      key={policy.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <div className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
                        <div className="text-2xl">{getInsuranceTypeIcon(policy.insurance_type)}</div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-slate-100 truncate" title={policy.policy_name}>
                            {policy.policy_name}
                          </h4>
                          <p className="text-sm text-slate-400 capitalize truncate">
                            {policy.provider} • {policy.insurance_type}
                          </p>
                        </div>
                        <Badge
                          variant="outline"
                          className="text-xs font-mono text-green-300 bg-green-900/40 border-green-700/60 flex-shrink-0"
                        >
                          {formatCurrency(policy.coverage_amount || 0)}
                        </Badge>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="text-center py-6 px-4 bg-slate-700/50 rounded-lg">
                    <FileText className="w-8 h-8 mx-auto text-slate-500 mb-2" />
                    <p className="text-sm text-slate-400">No recent policies found.</p>
                    <p className="text-xs text-slate-500">Upload documents to see them here.</p>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        ) : (
          <CardContent>
            <div className="text-center py-10 px-4">
              <FileText className="w-12 h-12 mx-auto text-slate-500 mb-4" />
              <p className="text-lg text-slate-300 font-semibold">No Insurance Policies Found</p>
              <p className="text-sm text-slate-400 mt-2">
                It looks like you don't have any policies added yet.
              </p>
              <p className="text-sm text-slate-400 mt-1">
                Click 'Go to Policies' to add your first policy or explore your options.
              </p>
              <div className="flex justify-center gap-3 mt-6">
                <Button
                  onClick={() => navigate(createPageUrl('Insurance'))} 
                  className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
                >
                  Go to Policies
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    </motion.div>
  );
}
