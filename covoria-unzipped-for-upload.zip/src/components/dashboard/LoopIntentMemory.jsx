import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Eye, TrendingUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '@/api/entities';
import { UserActivity } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function LoopIntentMemory() {
  const [suggestion, setSuggestion] = useState(null);
  const [isVisible, setIsVisible] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    analyzeUserBehavior();
  }, []);

  const analyzeUserBehavior = async () => {
    try {
      const user = await User.me();
      const recentActivities = await UserActivity.filter(
        { user_email: user.email },
        '-activity_date',
        50
      );

      const behaviorAnalysis = analyzeBehaviorPatterns(recentActivities);
      if (behaviorAnalysis.shouldSuggest) {
        setSuggestion(behaviorAnalysis);
        setIsVisible(true);
      }
    } catch (error) {
      console.error('Failed to analyze user behavior:', error);
    }
  };

  const analyzeBehaviorPatterns = (activities) => {
    const pageViews = activities.filter(a => a.activity_type === 'navigation');
    const categories = ['Insurance', 'Savings', 'Assistant', 'Dashboard'];
    
    const viewCounts = {};
    categories.forEach(cat => {
      viewCounts[cat] = pageViews.filter(a => 
        a.page_url?.includes(cat) || a.title?.includes(cat)
      ).length;
    });

    // Find least explored areas
    const leastExplored = Object.entries(viewCounts)
      .sort(([,a], [,b]) => a - b)
      .slice(0, 2);

    const mostExplored = Object.entries(viewCounts)
      .sort(([,a], [,b]) => b - a)[0];

    // Check for imbalance
    const totalViews = Object.values(viewCounts).reduce((sum, count) => sum + count, 0);
    const hasImbalance = leastExplored[0][1] < totalViews * 0.15; // Less than 15% of activity

    if (hasImbalance && totalViews > 10) {
      return {
        shouldSuggest: true,
        unexploredArea: leastExplored[0][0],
        exploredArea: mostExplored[0],
        suggestion: generateSuggestion(leastExplored[0][0], mostExplored[0])
      };
    }

    return { shouldSuggest: false };
  };

  const generateSuggestion = (unexplored, mostExplored) => {
    const suggestions = {
      Insurance: {
        title: "Explore Your Insurance Coverage",
        message: `You've been active with ${mostExplored} — want to check your Insurance policies for optimization opportunities?`,
        cta: "Review Coverage",
        icon: Eye
      },
      Savings: {
        title: "Check Your Savings Strategy", 
        message: `You've explored ${mostExplored} — how about reviewing your Savings and retirement planning?`,
        cta: "View Savings",
        icon: TrendingUp
      },
      Assistant: {
        title: "Ask Your AI Advisor",
        message: `You've been managing your ${mostExplored} — want to ask our AI advisor some questions?`,
        cta: "Chat with AI",
        icon: ArrowRight
      }
    };

    return suggestions[unexplored] || suggestions.Insurance;
  };

  const handleSuggestionClick = () => {
    navigate(createPageUrl(suggestion.unexploredArea));
    setIsVisible(false);
  };

  const handleDismiss = () => {
    setIsVisible(false);
  };

  if (!suggestion || !isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, x: 300 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 300 }}
        className="fixed bottom-6 right-6 z-50 max-w-sm"
      >
        <Card className="bg-gradient-to-r from-indigo-900/90 to-purple-900/90 backdrop-blur-lg border border-indigo-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-indigo-600/30 rounded-lg">
                <suggestion.suggestion.icon className="w-5 h-5 text-indigo-300" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-white text-sm mb-1">
                  {suggestion.suggestion.title}
                </h4>
                <p className="text-indigo-100 text-xs leading-relaxed mb-3">
                  {suggestion.suggestion.message}
                </p>
                <div className="flex gap-2">
                  <Button
                    onClick={handleSuggestionClick}
                    size="sm"
                    className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs"
                  >
                    {suggestion.suggestion.cta}
                  </Button>
                  <Button
                    onClick={handleDismiss}
                    variant="ghost"
                    size="sm"
                    className="text-indigo-300 hover:text-white text-xs"
                  >
                    Later
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}