import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Target, Lightbulb, Zap, AlertTriangle, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Skeleton } from '@/components/ui/skeleton';
import { Insight } from '@/api/entities';
import { User } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function OptimizationOpportunities() {
  const [opportunities, setOpportunities] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    loadOpportunities();
  }, []);

  const loadOpportunities = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const user = await User.me();
      const insights = await Insight.filter({ 
        created_by: user.email, 
        is_resolved: false,
        category: { $in: ['optimization', 'cost_saving'] }
      });
      setOpportunities(Array.isArray(insights) ? insights : []);
    } catch (err) {
      console.error("Failed to load optimization opportunities:", err);
      setError("Could not load opportunities.");
    } finally {
      setIsLoading(false);
    }
  };

  const getIcon = (category) => {
    switch (category) {
      case 'cost_saving': return <Zap className="w-5 h-5 text-green-400" />;
      case 'optimization': return <Target className="w-5 h-5 text-purple-400" />;
      default: return <Lightbulb className="w-5 h-5 text-yellow-400" />;
    }
  };

  if (isLoading) {
    return (
      <Card className="covoria-card">
        <CardHeader>
          <Skeleton className="h-6 w-3/4" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="covoria-card">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-white flex items-center gap-2">
            <Target className="w-6 h-6 text-purple-400" />
            Optimization
          </CardTitle>
          {opportunities.length > 0 && (
            <Badge variant="secondary" className="bg-purple-500/20 text-purple-300 border-purple-500/30">
              {opportunities.length} Found
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {error ? (
          <div className="text-center py-4 text-red-400">
            <AlertTriangle className="mx-auto w-8 h-8 mb-2" />
            <p>{error}</p>
          </div>
        ) : opportunities.length > 0 ? (
          <div className="space-y-4">
            {opportunities.slice(0, 3).map((opp, index) => (
              <motion.div
                key={opp.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-3 bg-slate-700/50 rounded-lg"
              >
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 mt-1">{getIcon(opp.category)}</div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-slate-100">{opp.title}</h4>
                    <p className="text-sm text-slate-300">{opp.description}</p>
                    {opp.potential_savings > 0 && (
                        <Badge className="mt-2 bg-green-500/20 text-green-300 border-green-500/30">
                            Save ~${opp.potential_savings.toLocaleString()}/year
                        </Badge>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
            <Button
              variant="outline"
              className="w-full mt-4 bg-slate-700 text-slate-200 hover:bg-slate-600 border-slate-600"
              onClick={() => navigate(createPageUrl('MyInsuranceCopilot'))}
            >
              View All Opportunities in Copilot
            </Button>
          </div>
        ) : (
          <div className="text-center py-6">
            <CheckCircle className="mx-auto w-10 h-10 text-green-500 mb-3" />
            <h4 className="font-semibold text-white">Fully Optimized!</h4>
            <p className="text-sm text-slate-400 mt-1">No immediate cost-saving or optimization opportunities found.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}