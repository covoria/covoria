
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Shield, 
  PiggyBank, 
  Lightbulb, 
  ArrowRight,
  FileText,
  Eye,
  TrendingUp
} from 'lucide-react';
import { InsurancePolicy } from '@/api/entities';
import { SavingsAccount } from '@/api/entities';
import { Insight } from '@/api/entities';
import { User } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function OverviewCards() {
  const [data, setData] = useState({
    policies: [],
    accounts: [],
    insights: []
  });
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const loadData = async () => {
    try {
      console.log('🚀 [OverviewCards] Loading fresh data...');
      const user = await User.me();
      const [policies, accounts, insights] = await Promise.all([
        InsurancePolicy.filter({ created_by: user.email }),
        SavingsAccount.filter({ created_by: user.email }),
        Insight.filter({ created_by: user.email, is_resolved: false })
      ]);
      
      console.log('🚀 [OverviewCards] Data loaded:', {
        policies: policies.length,
        accounts: accounts.length, 
        insights: insights.length
      });
      
      setData({ policies, accounts, insights });
    } catch (error) {
      console.error('🚀 [OverviewCards] Failed to load data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    
    // Listen for data changes from multiple sources
    const handleStorageChange = () => {
      console.log('🚀 [OverviewCards] Storage change detected, refreshing data');
      loadData();
    };
    
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        console.log('🚀 [OverviewCards] Page became visible, refreshing data');
        loadData();
      }
    };
    
    // Also listen for custom events
    const handleDataUpdate = () => {
      console.log('🚀 [OverviewCards] Custom data update event, refreshing');
      loadData();
    };
    
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('focus', loadData);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('covoriaDataUpdate', handleDataUpdate);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('focus', loadData);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('covoriaDataUpdate', handleDataUpdate);
    };
  }, []);

  const cards = [
    {
      title: 'Insurance Coverage',
      icon: Shield,
      color: 'from-blue-500 to-cyan-500',
      value: data.policies.length,
      subtitle: data.policies.length === 0 ? 'Upload policies to get started' : `$${data.policies.reduce((sum, p) => sum + (p.coverage_amount || 0), 0).toLocaleString()} total coverage`,
      action: () => navigate(createPageUrl('Insurance')),
      actionText: data.policies.length === 0 ? 'Add Policies' : 'View Coverage',
      hasData: data.policies.length > 0
    },
    {
      title: 'Savings & Retirement',
      icon: PiggyBank,
      color: 'from-green-500 to-emerald-500',
      value: data.accounts.length,
      subtitle: data.accounts.length === 0 ? 'Track your savings progress' : `$${data.accounts.reduce((sum, acc) => sum + (acc.current_balance || 0), 0).toLocaleString()} total saved`,
      action: () => navigate(createPageUrl('Savings')),
      actionText: data.accounts.length === 0 ? 'Add Accounts' : 'View Savings',
      hasData: data.accounts.length > 0
    },
    {
      title: 'AI Insights',
      icon: Lightbulb,
      color: 'from-purple-500 to-pink-500',
      value: data.insights.length,
      subtitle: data.insights.length === 0 ? 'Upload documents for personalized insights' : `${data.insights.filter(i => i.priority === 'high' || i.priority === 'critical').length} high priority actions`,
      action: () => navigate(createPageUrl('MyInsuranceCopilot')),
      actionText: data.insights.length === 0 ? 'Generate Insights' : 'View Insights',
      hasData: data.insights.length > 0
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {cards.map((card, index) => (
        <motion.div
          key={card.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className="covoria-card bg-slate-800/50 border-slate-700 hover:border-slate-600 transition-colors h-full">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-300">
                {card.title}
              </CardTitle>
              <div className={`p-2 rounded-lg bg-gradient-to-r ${card.color}`}>
                <card.icon className="w-4 h-4 text-white" />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-2xl font-bold text-white">
                  {isLoading ? '...' : card.value}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {isLoading ? 'Loading...' : card.subtitle}
                </p>
              </div>
              
              {card.hasData && (
                <div className="flex items-center justify-between pt-2 border-t border-slate-700">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-400" />
                    <span className="text-xs text-green-400">Active & Updated</span>
                  </div>
                  <Eye className="w-4 h-4 text-slate-500" />
                </div>
              )}
              
              <Button
                onClick={card.action}
                variant="ghost"
                size="sm"
                className="w-full justify-between text-slate-300 hover:text-white hover:bg-slate-700/50 mt-4"
              >
                {card.actionText}
                <ArrowRight className="w-4 h-4" />
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
