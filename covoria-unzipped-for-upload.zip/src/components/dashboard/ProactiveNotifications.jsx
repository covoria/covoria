import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Brain, 
  MessageCircle, 
  X, 
  ArrowRight,
  Lightbulb,
  AlertTriangle,
  Info
} from 'lucide-react';
import { AssistantConversation } from '@/api/entities';
import { User } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function ProactiveNotifications() {
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadProactiveNotifications();
  }, []);

  const loadProactiveNotifications = async () => {
    try {
      const user = await User.me();
      
      // Load proactive AI messages
      const proactiveMessages = await AssistantConversation.filter({
        user_email: user.email,
        message_type: 'proactive_ai'
      }, '-created_date', 5);

      // Filter unread/unacted notifications
      const activeNotifications = proactiveMessages.filter(msg => {
        const contextData = msg.context_data ? JSON.parse(msg.context_data) : {};
        return !contextData.dismissed && !contextData.acted_upon;
      });

      setNotifications(activeNotifications);
    } catch (error) {
      console.error('Failed to load proactive notifications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNotificationClick = async (notification) => {
    // Mark as acted upon
    try {
      const contextData = notification.context_data ? JSON.parse(notification.context_data) : {};
      contextData.acted_upon = true;
      
      await AssistantConversation.update(notification.id, {
        context_data: JSON.stringify(contextData)
      });

      // Navigate to assistant with this message as context
      navigate(createPageUrl('Assistant'), {
        state: { 
          proactiveMessage: notification.content,
          conversationId: notification.id 
        }
      });
    } catch (error) {
      console.error('Failed to update notification:', error);
      // Still navigate even if update fails
      navigate(createPageUrl('Assistant'));
    }
  };

  const handleDismiss = async (notificationId, event) => {
    event.stopPropagation();
    
    try {
      const notification = notifications.find(n => n.id === notificationId);
      if (!notification) return;

      const contextData = notification.context_data ? JSON.parse(notification.context_data) : {};
      contextData.dismissed = true;
      
      await AssistantConversation.update(notificationId, {
        context_data: JSON.stringify(contextData)
      });

      setNotifications(prev => prev.filter(n => n.id !== notificationId));
    } catch (error) {
      console.error('Failed to dismiss notification:', error);
    }
  };

  const getPriorityIcon = (priority) => {
    switch (priority) {
      case 'critical': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'high': return <Lightbulb className="w-4 h-4 text-orange-500" />;
      default: return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'border-red-500/30 bg-red-500/10';
      case 'high': return 'border-orange-500/30 bg-orange-500/10';
      default: return 'border-blue-500/30 bg-blue-500/10';
    }
  };

  if (isLoading || notifications.length === 0) {
    return null;
  }

  return (
    <div className="space-y-3 mb-6">
      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
        <Brain className="w-5 h-5 text-cyan-400" />
        AI Suggestions
      </h3>
      
      <AnimatePresence>
        {notifications.map((notification, index) => {
          const contextData = notification.context_data ? JSON.parse(notification.context_data) : {};
          const priority = contextData.priority || 'medium';
          
          return (
            <motion.div
              key={notification.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card 
                className={`cursor-pointer transition-all duration-200 hover:scale-[1.02] border ${getPriorityColor(priority)}`}
                onClick={() => handleNotificationClick(notification)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-0.5">
                      {getPriorityIcon(priority)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-cyan-900/30 text-cyan-300 text-xs">
                          AI Coach
                        </Badge>
                        {priority === 'critical' && (
                          <Badge className="bg-red-900/30 text-red-300 text-xs">
                            Urgent
                          </Badge>
                        )}
                      </div>
                      
                      <p className="text-white text-sm leading-relaxed mb-3">
                        {notification.content}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-xs text-slate-400">
                          <MessageCircle className="w-3 h-3" />
                          <span>Click to chat about this</span>
                        </div>
                        
                        <ArrowRight className="w-4 h-4 text-cyan-400" />
                      </div>
                    </div>
                    
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => handleDismiss(notification.id, e)}
                      className="h-6 w-6 text-slate-500 hover:text-white hover:bg-slate-700"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}