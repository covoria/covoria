import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, PiggyBank, FileText, MessageCircle, BarChart3, Target } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';

export default function QuickActions() {
  const navigate = useNavigate();

  const actions = [
    {
      title: "Add Policy",
      description: "Upload new insurance policy",
      icon: Shield,
      color: "text-blue-600",
      bg: "bg-blue-50 hover:bg-blue-100",
      onClick: () => navigate(createPageUrl('Insurance'))
    },
    {
      title: "Upload Documents",
      description: "Add insurance documents",
      icon: FileText,
      color: "text-green-600",
      bg: "bg-green-50 hover:bg-green-100",
      onClick: () => navigate(createPageUrl('DocumentVault'))
    },
    {
      title: "AI Analysis",
      description: "Get smart recommendations",
      icon: MessageCircle,
      color: "text-purple-600",
      bg: "bg-purple-50 hover:bg-purple-100",
      onClick: () => navigate(createPageUrl('Assistant'))
    },
    {
      title: "Coverage Analysis",
      description: "Detailed coverage review",
      icon: BarChart3,
      color: "text-orange-600",
      bg: "bg-orange-50 hover:bg-orange-100",
      onClick: () => navigate(createPageUrl('CoverageAnalysis'))
    }
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-cyan-600" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {actions.map((action, index) => (
              <Button
                key={index}
                variant="ghost"
                className={`h-auto p-4 flex flex-col items-center gap-2 ${action.bg} transition-colors`}
                onClick={action.onClick}
              >
                <action.icon className={`w-6 h-6 ${action.color}`} />
                <div className="text-center">
                  <p className="font-semibold text-sm text-gray-900">{action.title}</p>
                  <p className="text-xs text-gray-600">{action.description}</p>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}