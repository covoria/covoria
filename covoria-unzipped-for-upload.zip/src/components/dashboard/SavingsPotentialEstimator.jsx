import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { DollarSign, TrendingUp, PiggyBank, Target, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { InsurancePolicy, SavingsAccount, Insight, User } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export const analyzeUserPortfolio = async (user) => {
    try {
        const [policies, accounts, existingInsights] = await Promise.all([
            InsurancePolicy.filter({ created_by: user.email }),
            SavingsAccount.filter({ created_by: user.email }),
            Insight.filter({ created_by: user.email, is_resolved: false })
        ]);

        const userData = await User.get(user.id);

        const portfolioPrompt = `
Analyze this comprehensive user portfolio and generate actionable financial insights.

USER PROFILE:
- Age: ${userData.age}, Location: ${userData.location}
- Marital Status: ${userData.marital_status}, Dependents: ${userData.dependents}
- Employment: ${userData.employment_status}, Income: ${userData.income_bracket}

INSURANCE PORTFOLIO (${policies.length} policies):
${policies.map(p => `- ${p.insurance_type}: $${p.coverage_amount?.toLocaleString()} coverage, $${p.premium_amount}/month`).join('\n')}

SAVINGS PORTFOLIO (${accounts.length} accounts):
${accounts.map(a => `- ${a.account_type}: $${a.current_balance?.toLocaleString()} balance`).join('\n')}

EXISTING INSIGHTS: ${existingInsights.length} unresolved insights already identified.

Based on this analysis, provide a JSON response with:
1. 'portfolio_health_score': Overall financial health (0-100)
2. 'savings_opportunities': Array of specific savings opportunities with amounts
3. 'coverage_gaps': Array of identified coverage gaps
4. 'optimization_recommendations': Array of actionable optimization steps
5. 'insights_to_create': Array of new insights to add to the database (max 3)
`;

        const response = await InvokeLLM({
            prompt: portfolioPrompt,
            response_json_schema: {
                type: "object",
                properties: {
                    portfolio_health_score: { type: "number" },
                    savings_opportunities: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                description: { type: "string" },
                                potential_savings: { type: "number" }
                            }
                        }
                    },
                    coverage_gaps: {
                        type: "array",
                        items: { type: "string" }
                    },
                    optimization_recommendations: {
                        type: "array",
                        items: { type: "string" }
                    },
                    insights_to_create: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                title: { type: "string" },
                                description: { type: "string" },
                                category: { type: "string" },
                                priority: { type: "string" },
                                potential_savings: { type: "number" },
                                action_required: { type: "string" }
                            }
                        }
                    }
                }
            }
        });

        if (response.insights_to_create && response.insights_to_create.length > 0) {
            const insightsToCreate = response.insights_to_create.map(insight => ({
                ...insight,
                date_identified: new Date().toISOString().split('T')[0],
                is_resolved: false,
                created_by: user.email
            }));
            
            await Insight.bulkCreate(insightsToCreate);
        }

        return {
            success: true,
            portfolio_health_score: response.portfolio_health_score || 75,
            insights_created: response.insights_to_create?.length || 0,
            savings_opportunities: response.savings_opportunities || [],
            coverage_gaps: response.coverage_gaps || [],
            optimization_recommendations: response.optimization_recommendations || []
        };

    } catch (error) {
        console.error('Portfolio analysis failed:', error);
        return {
            success: false,
            portfolio_health_score: 0,
            insights_created: 0,
            error: error.message
        };
    }
};

export default function SavingsPotentialEstimator() {
    const [analysis, setAnalysis] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const runAnalysis = async () => {
            try {
                const user = await User.me();
                const result = await analyzeUserPortfolio(user);
                setAnalysis(result);
            } catch (error) {
                console.error('Failed to run analysis:', error);
                setAnalysis({ success: false, error: 'Analysis failed' });
            } finally {
                setIsLoading(false);
            }
        };

        runAnalysis();
    }, []);

    if (isLoading) {
        return (
            <Card className="covoria-card">
                <CardHeader>
                    <Skeleton className="h-6 w-3/4" />
                </CardHeader>
                <CardContent>
                    <Skeleton className="h-32 w-full" />
                </CardContent>
            </Card>
        );
    }

    if (!analysis?.success) {
        return (
            <Card className="covoria-card border-orange-200">
                <CardContent className="text-center py-8">
                    <DollarSign className="w-12 h-12 text-orange-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Analysis Temporarily Unavailable</h3>
                    <p className="text-gray-600">Please try again later or contact support.</p>
                </CardContent>
            </Card>
        );
    }

    const totalPotentialSavings = analysis.savings_opportunities?.reduce((sum, opp) => sum + (opp.potential_savings || 0), 0) || 0;

    return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="covoria-card">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-600" />
                        Smart Portfolio Analysis
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-3 bg-green-50 rounded-lg">
                            <div className="text-2xl font-bold text-green-600">{analysis.portfolio_health_score}</div>
                            <div className="text-sm text-green-700">Health Score</div>
                        </div>
                        <div className="text-center p-3 bg-blue-50 rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">${totalPotentialSavings.toLocaleString()}</div>
                            <div className="text-sm text-blue-700">Potential Savings</div>
                        </div>
                    </div>

                    {analysis.savings_opportunities?.length > 0 && (
                        <div className="space-y-2">
                            <h4 className="font-semibold text-gray-900">Top Savings Opportunities:</h4>
                            {analysis.savings_opportunities.slice(0, 3).map((opp, index) => (
                                <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                                    <span className="text-sm text-gray-700">{opp.description}</span>
                                    <span className="font-semibold text-green-600">${opp.potential_savings?.toLocaleString()}</span>
                                </div>
                            ))}
                        </div>
                    )}

                    <Button 
                        onClick={() => navigate(createPageUrl('Insights'))} 
                        className="w-full covoria-gradient text-white"
                    >
                        View All Insights
                    </Button>
                </CardContent>
            </Card>
        </motion.div>
    );
}