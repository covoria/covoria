import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  AlertTriangle, 
  Shield, 
  Target,
  RefreshCw,
  X,
  ChevronRight,
  Zap
} from 'lucide-react';
import { InsurancePolicy } from '@/api/entities';
import { SavingsAccount } from '@/api/entities';
import { Insight } from '@/api/entities';
import { opportunityDetector } from '@/api/functions';

const AlertIcon = ({ icon: Icon, type }) => {
  const colorClasses = {
    critical: 'text-red-500',
    warning: 'text-orange-500',
    opportunity: 'text-blue-500',
    info: 'text-gray-500',
  };
  return <Icon className={`w-5 h-5 ${colorClasses[type]}`} />;
};

export default function SmartAlertPanel({ userProfile, refreshTrigger }) {
  const [alerts, setAlerts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [dismissedAlerts, setDismissedAlerts] = useState(() => new Set(JSON.parse(localStorage.getItem('dismissedAlerts_v2') || '[]')));
  const [expandedAlert, setExpandedAlert] = useState(null);

  const saveDismissed = (newSet) => {
    localStorage.setItem('dismissedAlerts_v2', JSON.stringify(Array.from(newSet)));
  };

  const generateSmartAlerts = useCallback(async () => {
    setIsLoading(true);
    let allAlerts = [];

    try {
      const [policies, accounts, insights, opportunitiesResult] = await Promise.all([
        InsurancePolicy.list().catch(() => []),
        SavingsAccount.list().catch(() => []),
        Insight.filter({ is_resolved: false }, '-priority', 5).catch(() => []),
        opportunityDetector({ analysis_type: 'quick', generate_insights: true }).catch(() => ({ data: { success: false } }))
      ]);

      // 1. Renewal Alerts from Policies
      const renewalAlerts = (policies || []).map(p => {
        if (!p.end_date) return null;
        const now = new Date();
        const endDate = new Date(p.end_date);
        const daysUntil = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));
        if (daysUntil > 0 && daysUntil <= 30) {
          return {
            id: `renewal_${p.id}`,
            type: daysUntil <= 7 ? 'critical' : 'warning',
            icon: Shield,
            title: 'Policy Renewal Due',
            description: `Your ${p.policy_name} policy expires in ${daysUntil} days.`,
            details: [`Provider: ${p.provider}`, `Expires on: ${endDate.toLocaleDateString()}`],
            action: 'Review Renewal Options',
          };
        }
        return null;
      }).filter(Boolean);
      allAlerts.push(...renewalAlerts);

      // 2. High-Priority Insight Alerts
      const insightAlerts = (insights || []).map(i => ({
        id: `insight_${i.id}`,
        type: i.priority === 'critical' ? 'critical' : 'warning',
        icon: AlertTriangle,
        title: i.title,
        description: i.description,
        details: [`Category: ${i.category.replace('_', ' ')}`, `Potential Savings: $${i.potential_savings || 0}`],
        action: i.action_required || 'View Insight',
      }));
      allAlerts.push(...insightAlerts);

      // 3. Opportunity Alerts from Detector
      if (opportunitiesResult.data?.success && opportunitiesResult.data.data.opportunities) {
        const opportunityAlerts = opportunitiesResult.data.data.opportunities.slice(0, 2).map(opp => ({
          id: `opp_${opp.title.replace(/\s+/g, '_')}`,
          type: 'opportunity',
          icon: Zap,
          title: opp.title,
          description: opp.description,
          details: [`Category: ${opp.category}`, `Potential Savings: $${opp.potential_savings || 0}`],
          action: 'Explore Opportunity',
        }));
        allAlerts.push(...opportunityAlerts);
      }

      // 4. Life Stage Alerts
      if (userProfile && policies) {
        const hasLifeInsurance = policies.some(p => p.insurance_type === 'life');
        if ((userProfile.dependents || 0) > 0 && !hasLifeInsurance) {
          allAlerts.push({
            id: 'life_stage_life_insurance',
            type: 'critical',
            icon: Shield,
            title: 'Critical Gap: Life Insurance',
            description: 'Protect your family\'s future. As a parent, life insurance is essential.',
            details: ['Secure your dependents\' financial stability.', 'Cover debts and future expenses.'],
            action: 'Get a Life Insurance Quote',
          });
        }
      }
      
    } catch (error) {
      console.error("Failed to generate smart alerts:", error);
    }
    
    // Sort and set alerts
    const priorityOrder = { critical: 1, warning: 2, opportunity: 3, info: 4 };
    allAlerts.sort((a, b) => priorityOrder[a.type] - priorityOrder[b.type]);
    
    setAlerts(allAlerts);
    setIsLoading(false);
  }, [userProfile]);

  useEffect(() => {
    generateSmartAlerts();
  }, [userProfile, refreshTrigger, generateSmartAlerts]);

  const handleDismiss = (alertId, e) => {
    e.stopPropagation();
    const newDismissed = new Set(dismissedAlerts);
    newDismissed.add(alertId);
    setDismissedAlerts(newDismissed);
    saveDismissed(newDismissed);
  };
  
  const handleToggleExpand = (alertId) => {
    setExpandedAlert(prev => (prev === alertId ? null : alertId));
  };

  const visibleAlerts = alerts.filter(alert => !dismissedAlerts.has(alert.id));

  if (isLoading) {
    return (
      <Card className="covoria-card">
        <CardContent className="p-4 flex items-center gap-3">
          <RefreshCw className="w-5 h-5 animate-spin text-gray-500" />
          <p className="text-sm text-gray-600">Scanning for smart alerts...</p>
        </CardContent>
      </Card>
    );
  }

  if (visibleAlerts.length === 0) {
    return (
      <Card className="covoria-card bg-green-50 border-green-200">
        <CardContent className="p-4 flex items-center gap-3">
          <Shield className="w-5 h-5 text-green-600" />
          <p className="text-sm text-green-800 font-medium">All clear! No critical alerts for your attention right now.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="covoria-card overflow-hidden">
      <CardHeader className="bg-gray-50/50 p-4">
        <CardTitle className="text-base font-semibold flex items-center justify-between">
          <div className="flex items-center gap-2">
             <Target className="w-5 h-5 text-cyan-600" />
             Smart Alerts & Opportunities
          </div>
          <Badge variant="destructive">{visibleAlerts.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <AnimatePresence>
          {visibleAlerts.slice(0, 3).map((alert, index) => (
            <motion.div
              key={alert.id}
              layout
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className={`border-b border-gray-100 last:border-b-0 cursor-pointer hover:bg-gray-50 transition-colors`}
              onClick={() => handleToggleExpand(alert.id)}
            >
              <div className="p-4 flex items-start gap-4">
                <div className="pt-0.5">
                  <AlertIcon icon={alert.icon} type={alert.type} />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-sm text-gray-800">{alert.title}</p>
                  <p className="text-xs text-gray-600">{alert.description}</p>
                </div>
                <div className="flex items-center gap-1">
                   <Button variant="ghost" size="icon" className="h-7 w-7 text-gray-400 hover:text-gray-600" onClick={(e) => handleDismiss(alert.id, e)}>
                    <X className="w-4 h-4" />
                  </Button>
                  <ChevronRight className={`w-4 h-4 text-gray-400 transition-transform ${expandedAlert === alert.id ? 'rotate-90' : ''}`} />
                </div>
              </div>
              
              <AnimatePresence>
                {expandedAlert === alert.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="pb-4 px-4 pl-12 space-y-3">
                       <ul className="list-disc list-inside text-xs text-gray-700 space-y-1">
                         {alert.details.map((detail, i) => <li key={i}>{detail}</li>)}
                       </ul>
                       <Button size="sm" className="h-8 covoria-gradient text-white text-xs">
                          {alert.action}
                       </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}