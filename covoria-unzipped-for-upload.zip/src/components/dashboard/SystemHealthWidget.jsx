import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { 
  Activity, 
  CheckCircle, 
  AlertTriangle, 
  XCircle,
  RefreshCw,
  Server,
  Database,
  Zap
} from 'lucide-react';
import { systemTelemetry } from '@/api/functions';
import { selfHealingSystem } from '@/api/functions';

export default function SystemHealthWidget() {
  const [healthData, setHealthData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(null);

  useEffect(() => {
    fetchHealthData();
    const interval = setInterval(fetchHealthData, 60000); // Update every minute
    return () => clearInterval(interval);
  }, []);

  const fetchHealthData = async () => {
    setIsLoading(true);
    try {
      const response = await systemTelemetry();
      if (response.data?.success) {
        setHealthData(response.data.data);
        setLastUpdate(new Date());
      }
    } catch (error) {
      console.error('Failed to fetch health data:', error);
    }
    setIsLoading(false);
  };

  const triggerHealing = async () => {
    try {
      await selfHealingSystem({ trigger_type: 'manual' });
      await fetchHealthData(); // Refresh after healing
    } catch (error) {
      console.error('Failed to trigger healing:', error);
    }
  };

  const getHealthStatus = () => {
    if (!healthData) return { status: 'unknown', color: 'gray' };
    
    const hasErrors = healthData.database_metrics?.error || 
                     healthData.processing_metrics?.success_rate < 80;
    
    if (hasErrors) return { status: 'warning', color: 'yellow' };
    return { status: 'healthy', color: 'green' };
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'error': return <XCircle className="w-4 h-4 text-red-600" />;
      default: return <Activity className="w-4 h-4 text-gray-600" />;
    }
  };

  const healthStatus = getHealthStatus();

  if (isLoading && !healthData) {
    return (
      <Card className="covoria-card">
        <CardContent className="p-4 flex items-center justify-center">
          <RefreshCw className="w-5 h-5 animate-spin text-gray-500 mr-2" />
          <span className="text-sm text-gray-600">Loading system health...</span>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="covoria-card">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between text-lg">
            <div className="flex items-center gap-2">
              <Server className="w-5 h-5 text-cyan-600" />
              System Health
            </div>
            <div className="flex items-center gap-2">
              <Badge className={`bg-${healthStatus.color}-100 text-${healthStatus.color}-800`}>
                {getStatusIcon(healthStatus.status)}
                <span className="ml-1 capitalize">{healthStatus.status}</span>
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {healthData && (
            <>
              {/* Database Metrics */}
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium">Database</span>
                </div>
                <div className="text-right">
                  {healthData.database_metrics?.error ? (
                    <Badge variant="destructive" className="text-xs">Error</Badge>
                  ) : (
                    <Badge className="bg-green-100 text-green-800 text-xs">
                      {healthData.database_metrics?.total_policies || 0} policies
                    </Badge>
                  )}
                </div>
              </div>

              {/* Processing Metrics */}
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium">Processing</span>
                </div>
                <div className="text-right">
                  <Badge className={
                    (healthData.processing_metrics?.success_rate || 0) > 80 
                      ? "bg-green-100 text-green-800 text-xs"
                      : "bg-yellow-100 text-yellow-800 text-xs"
                  }>
                    {Math.round(healthData.processing_metrics?.success_rate || 0)}% success
                  </Badge>
                </div>
              </div>

              {/* AI Metrics */}
              {healthData.ai_metrics && (
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-orange-600" />
                    <span className="text-sm font-medium">AI Performance</span>
                  </div>
                  <div className="text-right">
                    <Badge className="bg-blue-100 text-blue-800 text-xs">
                      {Math.round(healthData.ai_metrics.average_confidence || 0)}% avg conf.
                    </Badge>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Actions */}
          <div className="flex items-center justify-between pt-3 border-t border-gray-100">
            <div className="text-xs text-gray-500">
              {lastUpdate && `Last update: ${lastUpdate.toLocaleTimeString()}`}
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={fetchHealthData}
                disabled={isLoading}
                className="text-xs"
              >
                <RefreshCw className={`w-3 h-3 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              {healthStatus.status === 'warning' && (
                <Button
                  size="sm"
                  onClick={triggerHealing}
                  className="bg-orange-600 hover:bg-orange-700 text-white text-xs"
                >
                  <Zap className="w-3 h-3 mr-1" />
                  Heal
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}