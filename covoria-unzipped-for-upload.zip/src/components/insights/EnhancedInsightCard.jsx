
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Lightbulb,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Eye,
  ChevronDown,
  ChevronUp,
  Bookmark,
  BookmarkCheck,
  CheckCircle,
  Info,
  Zap,
  RefreshCw,
  Brain // Added Brain icon for AI transparency
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { InvokeLLM } from '@/api/integrations';
import { User } from '@/api/entities';
import KnowledgeTooltip from '@/components/shared/KnowledgeTooltip';
import HyperTipsEngine from './HyperTipsEngine'; // New import for HyperTipsEngine

export default function EnhancedInsightCard({ insight, onResolve, onBookmarkToggle }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [deepDiveContent, setDeepDiveContent] = useState(null);
  const [isLoadingDeepDive, setIsLoadingDeepDive] = useState(false);
  const [deepDiveError, setDeepDiveError] = useState(null);
  const [showReasoning, setShowReasoning] = useState(false); // New state for AI transparency engine

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'coverage_gap': return <AlertTriangle className="w-5 h-5 text-red-400" />;
      case 'risk_alert': return <AlertTriangle className="w-5 h-5 text-orange-400" />;
      case 'optimization': return <TrendingUp className="w-5 h-5 text-blue-400" />;
      case 'cost_saving': return <DollarSign className="w-5 h-5 text-green-400" />;
      case 'overlap': return <Eye className="w-5 h-5 text-purple-400" />;
      default: return <Lightbulb className="w-5 h-5 text-cyan-400" />;
    }
  };

  const getPriorityBadge = (priority) => {
    const styles = {
      critical: 'bg-red-900/30 text-red-300 border-red-700/50',
      high: 'bg-orange-900/30 text-orange-300 border-orange-700/50',
      medium: 'bg-yellow-900/30 text-yellow-300 border-yellow-700/50',
      low: 'bg-blue-900/30 text-blue-300 border-blue-700/50'
    };
    return (
      <Badge className={`${styles[priority] || styles.medium} font-medium px-2 py-1`}>
        {priority?.toUpperCase() || 'MEDIUM'}
      </Badge>
    );
  };

  const generatePersonalizedDeepDive = async () => {
    setIsLoadingDeepDive(true);
    setDeepDiveError(null);

    try {
      const user = await User.me();
      const userContext = `
        User Profile:
        - Age: ${user.age || 'Not specified'}
        - Location: ${user.location || 'Not specified'}
        - Marital Status: ${user.marital_status || 'Not specified'}
        - Dependents: ${user.dependents || 0}
        - Income Bracket: ${user.income_bracket || 'Not specified'}
        - Financial Goals: ${user.financial_goals?.join(', ') || 'Not specified'}
        - Risk Concerns: ${user.risk_concerns?.join(', ') || 'Not specified'}
      `;

      const prompt = `
        You are Covoria's expert insurance advisor. Provide a detailed, personalized explanation for this insight.

        INSIGHT TO EXPLAIN:
        Title: ${insight.title}
        Description: ${insight.description}
        Category: ${insight.category}
        Priority: ${insight.priority}
        Action Required: ${insight.action_required}
        Reasoning: ${insight.reasoning || 'Not provided'}

        ${userContext}

        Please provide:
        1. **Why This Matters to You**: Explain specifically why this insight is important for this user's situation
        2. **Real-World Impact**: What could happen if they don't act on this insight?
        3. **Step-by-Step Action Plan**: Break down the "action required" into specific, actionable micro-steps
        4. **Timeline**: When should they ideally act on this?
        5. **Potential Savings/Benefits**: If relevant, estimate potential financial impact
        6. **Common Mistakes to Avoid**: What pitfalls should they be aware of?

        Tone: Empathetic, professional, encouraging. Make it feel like personal advice from a trusted advisor who knows their situation.
        Length: Comprehensive but scannable (use bullet points where helpful).
      `;

      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            why_this_matters: { type: "string" },
            real_world_impact: { type: "string" },
            action_plan: { type: "array", items: { type: "string" } },
            timeline: { type: "string" },
            potential_benefits: { type: "string" },
            common_mistakes: { type: "array", items: { type: "string" } }
          },
          required: ["why_this_matters", "real_world_impact", "action_plan", "timeline"]
        }
      });

      setDeepDiveContent(response);
    } catch (error) {
      console.error('Failed to generate deep dive:', error);
      setDeepDiveError('Unable to generate personalized explanation. Please try again.');
    } finally {
      setIsLoadingDeepDive(false);
    }
  };

  const handleExpandClick = async () => {
    if (!isExpanded && !deepDiveContent) {
      await generatePersonalizedDeepDive();
    }
    setIsExpanded(!isExpanded);
  };

  const formatActionPlan = (steps) => {
    if (!Array.isArray(steps)) return null;
    return steps.map((step, index) => (
      <div key={index} className="flex items-start gap-3 p-3 bg-slate-700/30 rounded-lg">
        <div className="w-6 h-6 bg-cyan-500 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0 mt-0.5">
          {index + 1}
        </div>
        <p className="text-slate-200 text-sm leading-relaxed">{step}</p>
      </div>
    ));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-4"
    >
      <Card className="covoria-card hover:shadow-lg transition-all duration-300">
        <CardContent className="p-4 space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3 flex-1 min-w-0">
              {getCategoryIcon(insight.category)}
              <div className="flex-1 min-w-0">
                <CardTitle className="text-lg font-bold text-white leading-tight mb-2 break-words">
                  {insight.title}
                </CardTitle>
                <div className="flex flex-wrap items-center gap-2">
                  {getPriorityBadge(insight.priority)}
                  <Badge variant="outline" className="text-xs text-slate-400 border-slate-600 capitalize">
                    {insight.category?.replace('_', ' ') || 'General'}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onBookmarkToggle(insight.id)}
                className="text-slate-400 hover:text-yellow-400 transition-colors"
              >
                {insight.is_bookmarked ?
                  <BookmarkCheck className="w-4 h-4" /> :
                  <Bookmark className="w-4 h-4" />
                }
              </Button>
              {!insight.is_resolved && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onResolve(insight.id)}
                  className="text-slate-400 hover:text-green-400 transition-colors"
                >
                  <CheckCircle className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>

          <p className="text-slate-300 leading-relaxed">
            {insight.description}
          </p>

          {/* AI Transparency Engine - New Section */}
          {insight.insight_suggestion_origin === 'ai_generated' && insight.reasoning && (
            <div className="mt-3">
              <button
                onClick={() => setShowReasoning(!showReasoning)}
                className="flex items-center gap-2 text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                <Brain className="w-3 h-3" />
                How did I get this?
                {showReasoning ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>

              <AnimatePresence>
                {showReasoning && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-2 p-3 bg-cyan-900/20 border border-cyan-700/30 rounded-lg"
                  >
                    <p className="text-xs text-cyan-100 leading-relaxed">
                      <strong>AI Reasoning:</strong> {insight.reasoning}
                    </p>
                    <p className="text-xs text-cyan-300 mt-2">
                      Based on your policy details and profile data.
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* Hyper-Tips Engine - New Section */}
          <HyperTipsEngine 
            insightText={insight.description} 
            category={insight.category} 
          />

          {/* Existing Recommended Action */}
          {insight.action_required && (
            <div className="p-3 bg-cyan-900/20 border border-cyan-700/30 rounded-lg">
              <h4 className="text-cyan-300 font-semibold mb-2 flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Recommended Action
              </h4>
              <p className="text-slate-200 text-sm leading-relaxed">
                {insight.action_required}
              </p>
            </div>
          )}

          <Button
            onClick={handleExpandClick}
            variant="outline"
            className="w-full bg-slate-700/50 border-slate-600 text-slate-200 hover:bg-slate-600/50 hover:text-white transition-all"
            disabled={isLoadingDeepDive}
          >
            {isLoadingDeepDive ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Generating Personalized Explanation...
              </>
            ) : (
              <>
                <Info className="w-4 h-4 mr-2" />
                {isExpanded ? 'Hide' : 'Get'} Personalized Deep Dive
                {isExpanded ? <ChevronUp className="w-4 h-4 ml-2" /> : <ChevronDown className="w-4 h-4 ml-2" />}
              </>
            )}
          </Button>

          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                {/* Existing Deep Dive Content / Error / Skeleton */}
                <div className={'mt-4'}>
                  {deepDiveError ? (
                    <div className="p-4 bg-red-900/20 border border-red-700/30 rounded-lg">
                      <p className="text-red-300 text-sm">{deepDiveError}</p>
                      <Button
                        onClick={generatePersonalizedDeepDive}
                        variant="outline"
                        size="sm"
                        className="mt-3 text-red-300 border-red-700/50 hover:bg-red-900/30"
                      >
                        Try Again
                      </Button>
                    </div>
                  ) : deepDiveContent ? (
                    <div className="space-y-6 p-4 bg-slate-700/20 rounded-lg border border-slate-600/30">
                      <div>
                        <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-orange-400" />
                          Why This Matters to You
                        </h4>
                        <p className="text-slate-200 text-sm leading-relaxed">
                          {deepDiveContent.why_this_matters}
                        </p>
                      </div>

                      <div>
                        <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-red-400" />
                          Real-World Impact
                        </h4>
                        <p className="text-slate-200 text-sm leading-relaxed">
                          {deepDiveContent.real_world_impact}
                        </p>
                      </div>

                      {deepDiveContent.action_plan && deepDiveContent.action_plan.length > 0 && (
                        <div>
                          <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                            <Zap className="w-4 h-4 text-cyan-400" />
                            Your Step-by-Step Action Plan
                          </h4>
                          <div className="space-y-3">
                            {formatActionPlan(deepDiveContent.action_plan)}
                          </div>
                        </div>
                      )}

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {deepDiveContent.timeline && (
                          <div className="p-3 bg-blue-900/20 border border-blue-700/30 rounded-lg">
                            <h5 className="text-blue-300 font-semibold mb-2">Timeline</h5>
                            <p className="text-slate-200 text-sm">{deepDiveContent.timeline}</p>
                          </div>
                        )}

                        {deepDiveContent.potential_benefits && (
                          <div className="p-3 bg-green-900/20 border border-green-700/30 rounded-lg">
                            <h5 className="text-green-300 font-semibold mb-2">Potential Benefits</h5>
                            <p className="text-slate-200 text-sm">{deepDiveContent.potential_benefits}</p>
                          </div>
                        )}
                      </div>

                      {deepDiveContent.common_mistakes && deepDiveContent.common_mistakes.length > 0 && (
                        <div>
                          <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4 text-yellow-400" />
                            Common Mistakes to Avoid
                          </h4>
                          <ul className="space-y-2">
                            {deepDiveContent.common_mistakes.map((mistake, index) => (
                              <li key={index} className="flex items-start gap-3">
                                <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2 flex-shrink-0"></div>
                                <p className="text-slate-200 text-sm leading-relaxed">{mistake}</p>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="p-4">
                      <Skeleton className="h-4 w-full mb-2 bg-slate-700" />
                      <Skeleton className="h-4 w-3/4 mb-2 bg-slate-700" />
                      <Skeleton className="h-4 w-1/2 bg-slate-700" />
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
}
