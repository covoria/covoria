import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { 
  Filter, 
  X, 
  Shield, 
  DollarSign, 
  TrendingUp, 
  AlertTriangle, 
  Target,
  Brain,
  Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const INSIGHT_TYPES = {
  gap: { label: 'Coverage Gaps', icon: Shield, color: 'bg-red-100 text-red-800' },
  forecast: { label: 'Future Risks', icon: TrendingUp, color: 'bg-blue-100 text-blue-800' },
  trap: { label: 'Potential Traps', icon: AlertTriangle, color: 'bg-orange-100 text-orange-800' },
  tax: { label: 'Tax Benefits', icon: DollarSign, color: 'bg-green-100 text-green-800' },
  tip: { label: 'Expert Tips', icon: Brain, color: 'bg-purple-100 text-purple-800' },
  optimization: { label: 'Optimizations', icon: Zap, color: 'bg-cyan-100 text-cyan-800' }
};

const PERSONA_FILTERS = {
  senior: { label: 'Senior (65+)', icon: '👴', description: 'Medicare & retirement focus' },
  family: { label: 'Family', icon: '👨‍👩‍👧‍👦', description: 'Family protection focus' },
  freelancer: { label: 'Freelancer', icon: '💼', description: 'Self-employed needs' },
  young_professional: { label: 'Young Professional', icon: '🎓', description: 'Career building' },
  general: { label: 'General', icon: '👤', description: 'Standard advice' }
};

export default function EnhancedInsightFilters({ 
  onFilterChange, 
  totalInsights = 0, 
  filteredInsights = 0,
  userProfile = null 
}) {
  const [selectedInsuranceType, setSelectedInsuranceType] = useState('all');
  const [selectedInsightType, setSelectedInsightType] = useState('all');
  const [selectedPersona, setSelectedPersona] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [riskScore, setRiskScore] = useState([0]);
  const [confidenceScore, setConfidenceScore] = useState([0]);
  const [showAdvanced, setShowAdvanced] = useState(false);

  useEffect(() => {
    const filters = {
      insuranceType: selectedInsuranceType,
      insightType: selectedInsightType,
      persona: selectedPersona,
      search: searchTerm.trim(),
      minRiskScore: riskScore[0],
      minConfidenceScore: confidenceScore[0]
    };
    
    onFilterChange(filters);
  }, [selectedInsuranceType, selectedInsightType, selectedPersona, searchTerm, riskScore, confidenceScore, onFilterChange]);

  const clearAllFilters = () => {
    setSelectedInsuranceType('all');
    setSelectedInsightType('all');
    setSelectedPersona('all');
    setSearchTerm('');
    setRiskScore([0]);
    setConfidenceScore([0]);
  };

  const hasActiveFilters = selectedInsuranceType !== 'all' || selectedInsightType !== 'all' || 
                         selectedPersona !== 'all' || searchTerm.trim() !== '' || 
                         riskScore[0] > 0 || confidenceScore[0] > 0;

  return (
    <div className="space-y-4">
      {/* Search and Quick Stats */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex-1 max-w-md">
          <Input
            placeholder="Search insights..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-800 border-slate-600 text-white placeholder-slate-400"
          />
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-400">
          <span>Showing {filteredInsights} of {totalInsights} insights</span>
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearAllFilters}
              className="h-8 px-2 text-slate-400 hover:text-slate-200 hover:bg-slate-700"
            >
              <X className="w-4 h-4 mr-1" />
              Clear
            </Button>
          )}
        </div>
      </div>

      {/* Insurance Type Filter */}
      <div className="flex flex-wrap gap-2 items-center">
        <span className="text-sm font-medium text-slate-300">Insurance Type:</span>
        <Button
          variant={selectedInsuranceType === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSelectedInsuranceType('all')}
          className={`h-8 ${selectedInsuranceType === 'all'
            ? 'bg-cyan-600 text-white hover:bg-cyan-700'
            : 'bg-slate-700 text-slate-200 border-slate-600 hover:bg-slate-600'
          }`}
        >
          All Types
        </Button>
        {['health', 'auto', 'life', 'home', 'disability'].map(type => (
          <Button
            key={type}
            variant={selectedInsuranceType === type ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedInsuranceType(type)}
            className={`h-8 capitalize ${selectedInsuranceType === type
              ? 'bg-cyan-600 text-white hover:bg-cyan-700'
              : 'bg-slate-700 text-slate-200 border-slate-600 hover:bg-slate-600'
            }`}
          >
            {type}
          </Button>
        ))}
      </div>

      {/* Insight Type Filter */}
      <div className="flex flex-nowrap gap-2 horizontal-scroll-container pb-2 overflow-x-auto">
        <Button
          variant={selectedInsightType === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSelectedInsightType('all')}
          className={`h-8 flex-shrink-0 ${selectedInsightType === 'all' 
            ? 'bg-cyan-600 text-white hover:bg-cyan-700' 
            : 'bg-slate-700 text-slate-200 border-slate-600 hover:bg-slate-600'
          }`}
        >
          All Types
        </Button>
        {Object.entries(INSIGHT_TYPES).map(([key, type]) => {
          const IconComponent = type.icon;
          const isSelected = selectedInsightType === key;
          return (
            <Button
              key={key}
              variant={isSelected ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedInsightType(key)}
              className={`h-8 flex-shrink-0 ${isSelected
                ? 'bg-cyan-600 text-white hover:bg-cyan-700'
                : 'bg-slate-700 text-slate-200 border-slate-600 hover:bg-slate-600'
              }`}
            >
              <IconComponent className="w-3 h-3 mr-1" />
              {type.label}
            </Button>
          );
        })}
      </div>

      {/* Persona Filter */}
      <div className="space-y-2">
        <span className="text-sm font-medium text-slate-300">Target Persona:</span>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedPersona === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedPersona('all')}
            className={`h-8 ${selectedPersona === 'all'
              ? 'bg-cyan-600 text-white hover:bg-cyan-700'
              : 'bg-slate-700 text-slate-200 border-slate-600 hover:bg-slate-600'
            }`}
          >
            All Personas
          </Button>
          {Object.entries(PERSONA_FILTERS).map(([key, persona]) => {
            const isSelected = selectedPersona === key;
            return (
              <Button
                key={key}
                variant={isSelected ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPersona(key)}
                className={`h-8 ${isSelected
                  ? 'bg-cyan-600 text-white hover:bg-cyan-700'
                  : 'bg-slate-700 text-slate-200 border-slate-600 hover:bg-slate-600'
                }`}
              >
                <span className="mr-1">{persona.icon}</span>
                {persona.label}
              </Button>
            );
          })}
        </div>
      </div>

      {/* Advanced Filters Toggle */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setShowAdvanced(!showAdvanced)}
        className="h-8 text-slate-400 hover:text-slate-200 hover:bg-slate-700"
      >
        <Filter className="w-4 h-4 mr-2" />
        Advanced Filters
        {showAdvanced ? <X className="w-4 h-4 ml-2" /> : <TrendingUp className="w-4 h-4 ml-2" />}
      </Button>

      {/* Advanced Filter Panel */}
      <AnimatePresence>
        {showAdvanced && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="bg-slate-800/50 rounded-lg p-4 space-y-4 border border-slate-700"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="text-sm font-medium text-slate-300 mb-2 block">
                  Risk Score: {riskScore[0]}+
                </label>
                <Slider
                  value={riskScore}
                  onValueChange={setRiskScore}
                  max={100}
                  step={10}
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-slate-300 mb-2 block">
                  Confidence Score: {confidenceScore[0]}+
                </label>
                <Slider
                  value={confidenceScore}
                  onValueChange={setConfidenceScore}
                  max={100}
                  step={10}
                  className="w-full"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Active Filter Summary */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2 p-3 bg-blue-900/20 rounded-lg border border-blue-700/30">
          <span className="text-sm font-medium text-blue-300">Active filters:</span>
          {selectedInsuranceType !== 'all' && (
            <Badge className="bg-blue-800/50 text-blue-200 border-blue-600">
              Type: {selectedInsuranceType}
            </Badge>
          )}
          {selectedInsightType !== 'all' && (
            <Badge className="bg-blue-800/50 text-blue-200 border-blue-600">
              Insight: {INSIGHT_TYPES[selectedInsightType]?.label}
            </Badge>
          )}
          {selectedPersona !== 'all' && (
            <Badge className="bg-blue-800/50 text-blue-200 border-blue-600">
              Persona: {PERSONA_FILTERS[selectedPersona]?.label}
            </Badge>
          )}
          {searchTerm.trim() && (
            <Badge className="bg-blue-800/50 text-blue-200 border-blue-600">
              Search: "{searchTerm}"
            </Badge>
          )}
          {riskScore[0] > 0 && (
            <Badge className="bg-blue-800/50 text-blue-200 border-blue-600">
              Risk: {riskScore[0]}+
            </Badge>
          )}
          {confidenceScore[0] > 0 && (
            <Badge className="bg-blue-800/50 text-blue-200 border-blue-600">
              Confidence: {confidenceScore[0]}+
            </Badge>
          )}
        </div>
      )}
    </div>
  );
}