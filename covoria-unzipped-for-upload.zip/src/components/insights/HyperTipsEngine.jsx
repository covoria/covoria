import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Lightbulb, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { InsuranceKnowledgeBase } from '@/api/entities';

export default function HyperTipsEngine({ insightText, category }) {
  const [relevantTips, setRelevantTips] = useState([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (insightText && category) {
      loadContextualTips();
    }
  }, [insightText, category]);

  const loadContextualTips = async () => {
    setIsLoading(true);
    try {
      // Extract key terms from insight text
      const keyTerms = extractKeyTerms(insightText);
      
      // Search knowledge base for relevant tips
      const tips = await InsuranceKnowledgeBase.filter({
        insightType: 'tip',
        insuranceType: category,
        visibleToAI: true
      }, null, 3);

      // Filter tips that match key terms
      const contextualTips = tips.filter(tip => 
        keyTerms.some(term => 
          tip.content.toLowerCase().includes(term.toLowerCase()) ||
          tip.tags.some(tag => tag.toLowerCase().includes(term.toLowerCase()))
        )
      );

      setRelevantTips(contextualTips.slice(0, 2)); // Max 2 tips per insight
    } catch (error) {
      console.error('Failed to load contextual tips:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const extractKeyTerms = (text) => {
    const insuranceTerms = [
      'premium', 'deductible', 'coverage', 'copay', 'coinsurance', 
      'out-of-pocket', 'network', 'claim', 'beneficiary', 'term life',
      'whole life', 'collision', 'comprehensive', 'liability', 'umbrella'
    ];
    
    return insuranceTerms.filter(term => 
      text.toLowerCase().includes(term.toLowerCase())
    );
  };

  if (!relevantTips.length || isLoading) return null;

  return (
    <div className="mt-3 border-t border-slate-700/50 pt-3">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center gap-2 text-sm text-amber-400 hover:text-amber-300 transition-colors"
      >
        <Lightbulb className="w-4 h-4" />
        <span>Smart Tips ({relevantTips.length})</span>
        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
      </button>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-2 space-y-2"
          >
            {relevantTips.map((tip, index) => (
              <div
                key={tip.id}
                className="p-3 bg-amber-900/20 border border-amber-700/30 rounded-lg"
              >
                <div className="flex items-start gap-2 mb-1">
                  <Badge className="bg-amber-800/30 text-amber-200 text-xs">
                    Tip
                  </Badge>
                  <span className="text-xs text-amber-400 font-medium">
                    {tip.sectionTitle}
                  </span>
                </div>
                <p className="text-sm text-amber-100 leading-relaxed">
                  {tip.content.length > 120 ? `${tip.content.slice(0, 120)}...` : tip.content}
                </p>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}