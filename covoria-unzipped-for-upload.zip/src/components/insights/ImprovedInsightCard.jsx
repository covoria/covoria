import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  AlertTriangle, 
  Lightbulb, 
  TrendingUp, 
  TrendingDown, 
  Shield,
  DollarSign,
  ArrowRight,
  X,
  Zap
} from 'lucide-react';
import { motion } from 'framer-motion';

const InsightIcon = ({ category, priority }) => {
  const iconMap = {
    coverage_gap: AlertTriangle,
    optimization: Zap,
    cost_saving: TrendingDown,
    risk_alert: Shield,
    overlap: TrendingUp
  };

  const Icon = iconMap[category] || Lightbulb;
  
  const colorMap = {
    critical: 'text-red-500 bg-red-100',
    high: 'text-orange-500 bg-orange-100',
    medium: 'text-yellow-500 bg-yellow-100',
    low: 'text-blue-500 bg-blue-100'
  };

  const colorClass = colorMap[priority] || colorMap.medium;

  return (
    <div className={`p-3 rounded-xl ${colorClass}`}>
      <Icon className="w-6 h-6" />
    </div>
  );
};

const ImpactIndicator = ({ potential_savings, category }) => {
  if (potential_savings > 0) {
    return (
      <div className="flex items-center gap-1 text-green-600">
        <TrendingDown className="w-4 h-4" />
        <span className="text-sm font-medium">-${potential_savings.toLocaleString()}/year</span>
      </div>
    );
  }

  const impactLabels = {
    coverage_gap: { icon: TrendingUp, text: '+Coverage', color: 'text-blue-600' },
    optimization: { icon: Zap, text: 'Optimize', color: 'text-purple-600' },
    risk_alert: { icon: Shield, text: '+Protection', color: 'text-red-600' }
  };

  const impact = impactLabels[category] || impactLabels.optimization;
  const Icon = impact.icon;

  return (
    <div className={`flex items-center gap-1 ${impact.color}`}>
      <Icon className="w-4 h-4" />
      <span className="text-sm font-medium">{impact.text}</span>
    </div>
  );
};

const ActionButton = ({ action, onClick, variant = "default" }) => {
  const variants = {
    primary: "bg-cyan-600 hover:bg-cyan-700 text-white",
    secondary: "bg-gray-100 hover:bg-gray-200 text-gray-700",
    danger: "bg-red-100 hover:bg-red-200 text-red-700"
  };

  return (
    <Button 
      onClick={onClick}
      className={`flex-1 text-sm ${variants[variant] || variants.primary}`}
    >
      {action}
    </Button>
  );
};

export default function ImprovedInsightCard({ 
  insight, 
  onResolve, 
  onDismiss, 
  onAdjust,
  delay = 0 
}) {
  const priorityColors = {
    critical: 'bg-red-100 text-red-800 border-red-200',
    high: 'bg-orange-100 text-orange-800 border-orange-200',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    low: 'bg-blue-100 text-blue-800 border-blue-200'
  };

  const handleAction = (actionType) => {
    switch(actionType) {
      case 'adjust':
        onAdjust && onAdjust(insight);
        break;
      case 'resolve':
        onResolve && onResolve(insight.id);
        break;
      case 'dismiss':
        onDismiss && onDismiss(insight.id);
        break;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.3 }}
      whileHover={{ y: -2 }}
    >
      <Card className="covoria-card h-full group hover:shadow-lg transition-all duration-300">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-start gap-3 flex-1">
              <InsightIcon category={insight.category} priority={insight.priority} />
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-cyan-700 transition-colors">
                  {insight.title}
                </h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {insight.description}
                </p>
              </div>
            </div>
            <Badge className={`${priorityColors[insight.priority]} text-xs font-medium`}>
              {insight.priority}
            </Badge>
          </div>

          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <Shield className="w-3 h-3" />
              <span className="capitalize">{insight.category.replace('_', ' ')}</span>
            </div>
            <ImpactIndicator 
              potential_savings={insight.potential_savings}
              category={insight.category}
            />
          </div>

          {insight.action_required && (
            <div className="bg-gray-50 p-3 rounded-lg mb-4">
              <p className="text-sm text-gray-700">
                <strong>Recommended:</strong> {insight.action_required}
              </p>
            </div>
          )}

          <div className="flex gap-2">
            <ActionButton 
              action="Take Action"
              onClick={() => handleAction('resolve')}
              variant="primary"
            />
            <ActionButton 
              action="Review"
              onClick={() => handleAction('adjust')}
              variant="secondary"
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleAction('dismiss')}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}