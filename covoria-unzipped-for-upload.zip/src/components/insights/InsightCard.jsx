
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle, TrendingUp, DollarSign, Edit, CheckSquare, ThumbsUp, ThumbsDown, MessageSquare } from 'lucide-react';
import { motion } from 'framer-motion';
import { Insight } from '@/api/entities'; // Assuming this path is correct for your project

const insightTypesConfig = {
    coverage_gap: { icon: AlertTriangle, color: 'text-orange-500', bg: 'bg-orange-50' },
    optimization: { icon: TrendingUp, color: 'text-blue-500', bg: 'bg-blue-50' },
    cost_saving: { icon: DollarSign, color: 'text-green-500', bg: 'bg-green-50' },
    risk_alert: { icon: AlertTriangle, color: 'text-red-500', bg: 'bg-red-50' },
    overlap: { icon: CheckCircle, color: 'text-purple-500', bg: 'bg-purple-50' },
    default: { icon: AlertTriangle, color: 'text-gray-500', bg: 'bg-gray-50' }
};

const priorityConfig = {
    high: 'bg-red-200 text-red-800',
    critical: 'bg-red-500 text-white',
    medium: 'bg-yellow-200 text-yellow-800',
    low: 'bg-blue-200 text-blue-800'
};

export default function InsightCard({ insight, delay = 0, onEdit }) {
  const [isResolved, setIsResolved] = useState(insight.is_resolved);
  const [feedback, setFeedback] = useState(null);

  const config = insightTypesConfig[insight.category] || insightTypesConfig.default;
  const Icon = config.icon;

  const handleMarkAsResolved = async () => {
    setIsResolved(true);
    try {
      // Assuming insight has an 'id' field
      await Insight.update(insight.id, { is_resolved: true });
      // You might want to trigger a parent component's re-fetch or state update here
    } catch (error) {
      console.error('Failed to update insight:', error);
      setIsResolved(insight.is_resolved); // Revert on error
      // Optionally, show a toast or error message to the user
    }
  };

  const handleFeedback = (feedbackType) => {
    setFeedback(feedbackType);
    // Here you would call a function to submit feedback to your backend
    // e.g., submitFeedback({ insightId: insight.id, feedback: feedbackType });
    console.log(`Feedback for insight ${insight.id}: ${feedbackType}`);
    // You might also want to prevent further feedback after one is given, or allow changing it.
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <Card className={`covoria-card overflow-hidden border-l-4 dark:bg-slate-800`} style={{borderColor: config.color.replace('text-', 'border-')}}>
        <CardHeader className="flex flex-row items-start justify-between pb-2">
            <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${config.bg} dark:${config.bg.replace('bg-', 'dark:bg-').replace('-50', '-900/30')}`}>
                    <Icon className={`w-6 h-6 ${config.color} dark:${config.color.replace('-500', '-400')}`} />
                </div>
                <CardTitle className="text-lg font-bold text-gray-900 dark:text-[var(--covoria-text-primary)]">{insight.title}</CardTitle>
            </div>
            <div className="flex gap-2 flex-wrap">
                <Badge className={`${priorityConfig[insight.priority]} capitalize`}>{insight.priority}</Badge>
                <Badge variant="outline" className="capitalize text-gray-600 dark:text-gray-300 border-gray-300 dark:border-slate-600">{insight.category.replace('_', ' ')}</Badge>
            </div>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 dark:text-[var(--covoria-text-secondary)] mb-4 text-sm leading-relaxed">{insight.description}</p>
          
          {insight.potential_savings > 0 && (
            <div className="my-3 p-2 bg-green-50 dark:bg-green-900/20 rounded-lg flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-green-600 dark:text-green-400"/>
              <p className="text-sm text-green-800 dark:text-green-300 font-medium">
                Potential Savings: ${insight.potential_savings.toLocaleString()}/year
              </p>
            </div>
          )}

          <div className="bg-white dark:bg-slate-900/50 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
            <h4 className="font-semibold text-gray-800 dark:text-[var(--covoria-text-primary)] mb-2">Recommended Action</h4>
            <p className="text-sm text-gray-600 dark:text-[var(--covoria-text-secondary)]">{insight.action_required}</p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between items-center pt-3 border-t border-gray-100 dark:border-slate-700">
          <div className="flex items-center gap-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className={`w-8 h-8 rounded-full hover:bg-green-100 dark:hover:bg-green-900/30 ${feedback === 'useful' ? 'bg-green-100 dark:bg-green-900/40' : ''}`} 
              onClick={() => handleFeedback('useful')}
            >
              <ThumbsUp className="w-4 h-4 text-green-600" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className={`w-8 h-8 rounded-full hover:bg-red-100 dark:hover:bg-red-900/30 ${feedback === 'not_useful' ? 'bg-red-100 dark:bg-red-900/40' : ''}`} 
              onClick={() => handleFeedback('not_useful')}
            >
              <ThumbsDown className="w-4 h-4 text-red-600" />
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => onEdit(insight)}>
              <Edit className="w-3 h-3 mr-1" /> Edit
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleMarkAsResolved}
              disabled={isResolved}
            >
              <CheckSquare className="w-4 h-4 mr-2" /> {isResolved ? "Resolved" : "Mark as Resolved"}
            </Button>
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
