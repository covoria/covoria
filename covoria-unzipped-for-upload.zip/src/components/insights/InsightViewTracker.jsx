import React, { useEffect } from 'react';
import { BehavioralEvent } from '@/api/entities';
import { User } from '@/api/entities';

export default function InsightViewTracker({ insights }) {
  useEffect(() => {
    const trackInsightViews = async () => {
      try {
        const user = await User.me();
        if (!user || !insights || insights.length === 0) return;

        // Track that user viewed insights
        await BehavioralEvent.create({
          user_email: user.email,
          session_id: `session_${Date.now()}`,
          event_type: 'interaction',
          event_name: 'view_insights',
          event_timestamp: new Date().toISOString(),
          page_url: window.location.href,
          details: {
            insights_count: insights.length,
            insight_categories: [...new Set(insights.map(i => i.category))],
            high_priority_count: insights.filter(i => i.priority === 'high' || i.priority === 'critical').length
          }
        });
      } catch (error) {
        console.error('Failed to track insight views:', error);
      }
    };

    // Track after a short delay to ensure page is loaded
    const timer = setTimeout(trackInsightViews, 2000);
    return () => clearTimeout(timer);
  }, [insights]);

  return null; // This is a tracking component, no UI
}