import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, 
  ChevronDown, 
  ChevronRight, 
  Target, 
  TrendingUp, 
  Database,
  Lightbulb,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

// Component that explains AI reasoning for any insight or recommendation
export default function ReasoningExplainer({ 
  insight, 
  userContext = {}, 
  onReasoningViewed,
  className = "" 
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showDataSources, setShowDataSources] = useState(false);

  if (!insight) return null;

  // Extract reasoning components from insight
  const reasoningBreakdown = analyzeReasoning(insight, userContext);

  const handleToggle = () => {
    setIsExpanded(!isExpanded);
    if (!isExpanded && onReasoningViewed) {
      onReasoningViewed(insight.id);
    }
  };

  return (
    <div className={`border border-gray-200 rounded-lg ${className}`}>
      <div 
        className="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50 transition-colors"
        onClick={handleToggle}
      >
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-purple-600" />
          <span className="text-sm font-medium text-gray-900">Why I'm suggesting this</span>
          <Badge className="bg-purple-100 text-purple-800 text-xs">
            AI Reasoning
          </Badge>
        </div>
        {isExpanded ? (
          <ChevronDown className="w-4 h-4 text-gray-500" />
        ) : (
          <ChevronRight className="w-4 h-4 text-gray-500" />
        )}
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="border-t border-gray-100"
          >
            <div className="p-4 space-y-4">
              
              {/* Main Reasoning */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-blue-600" />
                  <h4 className="font-medium text-blue-900">My Analysis Process</h4>
                </div>
                
                {reasoningBreakdown.steps.map((step, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex gap-3"
                  >
                    <div className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-semibold text-blue-600">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-700">{step.description}</p>
                      {step.evidence && (
                        <div className="mt-1">
                          <Badge variant="outline" className="text-xs text-blue-700 border-blue-200">
                            Evidence: {step.evidence}
                          </Badge>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Data Sources Used */}
              <div className="space-y-2">
                <button
                  onClick={() => setShowDataSources(!showDataSources)}
                  className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors"
                >
                  <Database className="w-4 h-4" />
                  Data Sources I Analyzed
                  {showDataSources ? (
                    <ChevronDown className="w-3 h-3" />
                  ) : (
                    <ChevronRight className="w-3 h-3" />
                  )}
                </button>
                
                <AnimatePresence>
                  {showDataSources && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="ml-6 space-y-2"
                    >
                      {reasoningBreakdown.dataSources.map((source, index) => (
                        <div key={index} className="flex items-center gap-2 text-xs text-gray-600">
                          <CheckCircle className="w-3 h-3 text-green-500" />
                          <span>{source.description}</span>
                          <Badge variant="outline" className="text-xs">
                            {source.value}
                          </Badge>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Risk Assessment */}
              {reasoningBreakdown.riskFactors.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-orange-600" />
                    <h4 className="font-medium text-orange-900">Risk Factors Considered</h4>
                  </div>
                  <div className="space-y-1">
                    {reasoningBreakdown.riskFactors.map((risk, index) => (
                      <div key={index} className="flex items-start gap-2 text-sm text-orange-800">
                        <span className="text-orange-500 text-xs mt-1">▸</span>
                        {risk}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Expected Outcome */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-green-600" />
                  <h4 className="font-medium text-green-900">Expected Outcome</h4>
                </div>
                <p className="text-sm text-green-800 bg-green-50 p-3 rounded-lg">
                  {reasoningBreakdown.expectedOutcome}
                </p>
              </div>

              {/* Confidence Level */}
              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <div className="flex items-center gap-2">
                  <Lightbulb className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium text-gray-700">Confidence Level</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        reasoningBreakdown.confidence >= 80 ? 'bg-green-500' :
                        reasoningBreakdown.confidence >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${reasoningBreakdown.confidence}%` }}
                    />
                  </div>
                  <Badge className={`text-xs ${
                    reasoningBreakdown.confidence >= 80 ? 'bg-green-100 text-green-800' :
                    reasoningBreakdown.confidence >= 60 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {reasoningBreakdown.confidence}%
                  </Badge>
                </div>
              </div>

              {/* Alternative Considerations */}
              {reasoningBreakdown.alternatives.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-gray-100">
                  <h4 className="text-sm font-medium text-gray-700">Alternative Approaches I Considered:</h4>
                  <div className="space-y-1">
                    {reasoningBreakdown.alternatives.map((alt, index) => (
                      <div key={index} className="text-sm text-gray-600 bg-gray-50 p-2 rounded">
                        <span className="font-medium">Option {index + 1}:</span> {alt.description}
                        <div className="text-xs text-gray-500 mt-1">Why not chosen: {alt.reason}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Analyze and break down AI reasoning into comprehensible components
function analyzeReasoning(insight, userContext) {
  const breakdown = {
    steps: [],
    dataSources: [],
    riskFactors: [],
    expectedOutcome: '',
    confidence: 75,
    alternatives: []
  };

  // Generate reasoning steps based on insight category
  switch (insight.category) {
    case 'coverage_gap':
      breakdown.steps = [
        {
          description: "I analyzed your current insurance policies to identify coverage types",
          evidence: `Found ${userContext.policies?.length || 0} active policies`
        },
        {
          description: "I compared your coverage against essential protection needs for your life stage",
          evidence: `Age ${userContext.userData?.age || 'N/A'}, ${userContext.userData?.dependents || 0} dependents`
        },
        {
          description: "I identified this specific gap in your protection portfolio",
          evidence: insight.title
        },
        {
          description: "I calculated the financial risk exposure of this gap",
          evidence: insight.potential_savings ? `$${insight.potential_savings}/year potential impact` : "High risk exposure"
        }
      ];
      
      breakdown.riskFactors = [
        "Unexpected medical expenses could exceed savings",
        "Income loss could affect family financial stability",
        "Insurance premiums increase with age and health changes"
      ];
      
      breakdown.expectedOutcome = "Closing this coverage gap will provide financial security and peace of mind, protecting your family from unexpected financial hardship.";
      break;

    case 'optimization':
      breakdown.steps = [
        {
          description: "I reviewed your existing policies for efficiency opportunities",
          evidence: `Analyzed ${userContext.policies?.length || 0} policies`
        },
        {
          description: "I identified redundancies or suboptimal structures in your coverage",
          evidence: insight.description
        },
        {
          description: "I calculated potential savings from optimization",
          evidence: insight.potential_savings ? `$${insight.potential_savings}/year savings` : "Cost reduction opportunity"
        }
      ];
      
      breakdown.expectedOutcome = "Optimizing your coverage structure will reduce costs while maintaining or improving your protection level.";
      break;

    case 'cost_saving':
      breakdown.steps = [
        {
          description: "I analyzed your premium payments and coverage efficiency",
          evidence: "Current premium structure review"
        },
        {
          description: "I identified opportunities to reduce costs without sacrificing coverage",
          evidence: insight.title
        },
        {
          description: "I estimated the annual savings potential",
          evidence: insight.potential_savings ? `$${insight.potential_savings}/year` : "Significant savings"
        }
      ];
      
      breakdown.expectedOutcome = "Implementing these cost-saving measures will free up budget for other financial goals while maintaining adequate protection.";
      break;

    default:
      breakdown.steps = [
        {
          description: "I analyzed your complete financial profile and insurance portfolio",
          evidence: "Comprehensive portfolio review"
        },
        {
          description: "I identified this opportunity based on your specific situation",
          evidence: insight.title
        },
        {
          description: "I evaluated the potential impact and priority level",
          evidence: `${insight.priority} priority insight`
        }
      ];
      
      breakdown.expectedOutcome = "Taking action on this insight will improve your overall financial security and efficiency.";
  }

  // Generate data sources
  breakdown.dataSources = [
    { description: "Current insurance policies", value: `${userContext.policies?.length || 0} policies` },
    { description: "Savings accounts", value: `${userContext.accounts?.length || 0} accounts` },
    { description: "User profile data", value: `Age ${userContext.userData?.age || 'N/A'}` },
    { description: "Market benchmarks", value: "Industry standards" },
    { description: "Risk assessment models", value: "AI analysis" }
  ];

  // Set confidence based on available data
  const dataQuality = (userContext.policies?.length || 0) + (userContext.accounts?.length || 0);
  breakdown.confidence = Math.min(Math.max(50 + (dataQuality * 10), 50), 95);

  // Generate alternatives for higher-priority insights
  if (insight.priority === 'high' || insight.priority === 'critical') {
    breakdown.alternatives = [
      {
        description: "Gradual implementation over 6-12 months",
        reason: "Immediate action provides better risk protection"
      },
      {
        description: "Lower-cost alternative with reduced coverage",
        reason: "May leave significant gaps in protection"
      }
    ];
  }

  return breakdown;
}