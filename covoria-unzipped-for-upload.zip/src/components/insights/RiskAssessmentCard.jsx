
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'; // Still imported but not used in final render
import { Skeleton } from '@/components/ui/skeleton';
import { InvokeLLM } from '@/api/integrations';
import { InsurancePolicy, SavingsAccount, User } from '@/api/entities';
import { ShieldAlert, ShieldCheck, Shield, AlertTriangle, Brain, Heart, Home, TrendingDown, ChevronDown } from 'lucide-react'; // Added Heart, Home, TrendingDown, ChevronDown
import { Progress } from '@/components/ui/progress'; // Still imported but not used in final render
import { motion } from 'framer-motion';

// Removed getRiskColor and getRiskIcon as they are no longer used in the new design

export default function RiskAssessmentCard() {
    const [assessment, setAssessment] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchAssessment();
    }, []);

    const fetchAssessment = async () => {
        setIsLoading(true);
        setError(null);
        
        try {
            // Get user data for context
            const [user, policies, accounts] = await Promise.all([
                User.me().catch(() => null),
                InsurancePolicy.list().catch(() => []),
                SavingsAccount.list().catch(() => [])
            ]);

            // Build context for AI analysis
            const userContext = {
                profile: {
                    age: user?.age || 30,
                    marital_status: user?.marital_status || 'single',
                    dependents: user?.dependents || 0,
                    health_status: user?.health_status || 'good',
                    income_bracket: user?.income_bracket || '50k-100k',
                    employment_status: user?.employment_status || 'employed'
                },
                financial_snapshot: {
                    total_policies: policies.length,
                    policy_types: [...new Set(policies.map(p => p.insurance_type))],
                    total_coverage: policies.reduce((sum, p) => sum + (p.coverage_amount || 0), 0),
                    total_savings: accounts.reduce((sum, a) => sum + (a.current_balance || 0), 0),
                    has_emergency_fund: accounts.some(a => a.account_type === 'general_savings' && a.current_balance > 10000)
                }
            };

            const prompt = `You are a risk assessment expert. Analyze the user's profile and financial situation to identify potential risks and provide a comprehensive risk score.

USER CONTEXT: ${JSON.stringify(userContext)}

Analyze the following risk categories:
1. Financial Risk (income stability, emergency fund)
2. Health Risk (age, health status, coverage gaps)
3. Life Risk (dependents, life insurance adequacy)
4. Property Risk (home, auto coverage)
5. Retirement Risk (savings rate, timeline)

Provide a risk breakdown with scores (0-100) for each category and overall assessment.`;

            const aiResponse = await InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        overall_risk_score: { type: "number" },
                        risk_level: { 
                            type: "string",
                            enum: ["low", "medium", "high", "critical"]
                        },
                        risk_breakdown: {
                            type: "object",
                            properties: {
                                financial_risk: {
                                    type: "object",
                                    properties: {
                                        score: { type: "number" },
                                        summary: { type: "string" },
                                        factors: { 
                                            type: "array",
                                            items: { type: "string" }
                                        }
                                    },
                                    required: ["score", "summary", "factors"]
                                },
                                health_risk: {
                                    type: "object",
                                    properties: {
                                        score: { type: "number" },
                                        summary: { type: "string" },
                                        factors: { 
                                            type: "array",
                                            items: { type: "string" }
                                        }
                                    },
                                    required: ["score", "summary", "factors"]
                                },
                                life_risk: {
                                    type: "object",
                                    properties: {
                                        score: { type: "number" },
                                        summary: { type: "string" },
                                        factors: { 
                                            type: "array",
                                            items: { type: "string" }
                                        }
                                    },
                                    required: ["score", "summary", "factors"]
                                },
                                property_risk: { // Added property risk
                                    type: "object",
                                    properties: {
                                        score: { type: "number" },
                                        summary: { type: "string" },
                                        factors: { 
                                            type: "array",
                                            items: { type: "string" }
                                        }
                                    },
                                    required: ["score", "summary", "factors"]
                                },
                                retirement_risk: { // Added retirement risk
                                    type: "object",
                                    properties: {
                                        score: { type: "number" },
                                        summary: { type: "string" },
                                        factors: { 
                                            type: "array",
                                            items: { type: "string" }
                                        }
                                    },
                                    required: ["score", "summary", "factors"]
                                }
                            },
                            required: ["financial_risk", "health_risk", "life_risk", "property_risk", "retirement_risk"]
                        },
                        recommendations: {
                            type: "array",
                            items: { type: "string" }
                        },
                        summary: { type: "string" }
                    },
                    required: ["overall_risk_score", "risk_level", "risk_breakdown", "recommendations", "summary"]
                }
            });

            setAssessment(aiResponse);

        } catch (err) {
            console.error("Risk Assessment Error:", err);
            setError('Could not generate risk assessment at this time. Please try again later.');
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading) {
        return (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <Card className="covoria-card">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                            <div className="animate-spin w-6 h-6 border-2 border-orange-300 border-t-orange-600 rounded-full"></div>
                            Analyzing Your Risk Profile...
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            <Skeleton className="h-4 w-full" />
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-4 w-1/2" />
                        </div>
                    </CardContent>
                </Card>
            </motion.div>
        );
    }

    if (error) {
        return (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <Card className="border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-red-700 dark:text-red-400">
                            <AlertTriangle className="w-5 h-5" />
                            Risk Assessment Unavailable
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-red-600 text-sm dark:text-red-300">{error}</p>
                        <button 
                            onClick={fetchAssessment}
                            className="mt-3 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm dark:bg-red-800 dark:text-red-200 dark:hover:bg-red-700"
                        >
                            Try Again
                        </button>
                    </CardContent>
                </Card>
            </motion.div>
        );
    }
    
    // The overallScore display is removed from the new design.
    // const overallScore = assessment?.overall_risk_score || 50;

    const riskCategoriesConfig = [
        { key: 'health_risk', name: 'HEALTH RISK', icon: Heart, color: 'text-red-400', bgColor: 'bg-red-900/20', description: 'Medical coverage gaps' },
        { key: 'life_risk', name: 'LIFE RISK', icon: Shield, color: 'text-orange-400', bgColor: 'bg-orange-900/20', description: 'Life insurance adequacy' },
        { key: 'property_risk', name: 'PROPERTY RISK', icon: Home, color: 'text-yellow-400', bgColor: 'bg-yellow-900/20', description: 'Asset protection level' },
        { key: 'retirement_risk', name: 'RETIREMENT RISK', icon: TrendingDown, color: 'text-green-400', bgColor: 'bg-green-900/20', description: 'Savings adequacy' }
    ];

    const displayCategories = riskCategoriesConfig.map(cat => ({
        ...cat,
        value: assessment?.risk_breakdown?.[cat.key]?.score || 0,
        summary: assessment?.risk_breakdown?.[cat.key]?.summary || '',
        factors: assessment?.risk_breakdown?.[cat.key]?.factors || []
    }));

    return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="covoria-card">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-gray-900 dark:text-[var(--covoria-text-primary)]">
                        <AlertTriangle className="w-5 h-5 text-orange-500 dark:text-orange-400" />
                        AI Risk Assessment
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-4">
                        {displayCategories.map((category) => {
                            const Icon = category.icon;
                            let gradientStartColor, gradientEndColor;

                            // Determine gradient colors based on category.color
                            if (category.color.includes('red')) {
                                gradientStartColor = '#ef4444'; // red-500
                                gradientEndColor = '#dc2626'; // red-600
                            } else if (category.color.includes('orange')) {
                                gradientStartColor = '#f97316'; // orange-500
                                gradientEndColor = '#ea580c'; // orange-600
                            } else if (category.color.includes('yellow')) {
                                gradientStartColor = '#eab308'; // yellow-500
                                gradientEndColor = '#ca8a04'; // yellow-600
                            } else { // green
                                gradientStartColor = '#22c55e'; // green-500
                                gradientEndColor = '#16a34a'; // green-600
                            }

                            return (
                                <div key={category.name} className="space-y-3">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className={`p-2 rounded-lg ${category.bgColor}`}>
                                                <Icon className={`w-4 h-4 ${category.color}`} />
                                            </div>
                                            <div>
                                                <p className="text-sm font-semibold text-gray-900 dark:text-[var(--covoria-text-primary)]">{category.name}</p>
                                                <p className="text-xs text-gray-600 dark:text-[var(--covoria-text-secondary)]">{category.description}</p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="text-2xl font-bold text-gray-900 dark:text-[var(--covoria-text-primary)]">{category.value}</span>
                                            <ChevronDown className="w-4 h-4 text-gray-400 dark:text-slate-500" /> {/* This chevron is decorative in the new layout */}
                                        </div>
                                    </div>
                                    <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2">
                                        <div 
                                            className={`h-2 rounded-full transition-all duration-500`}
                                            style={{
                                                width: `${category.value}%`,
                                                background: `linear-gradient(90deg, ${gradientStartColor} 0%, ${gradientEndColor} 100%)`
                                            }}
                                        />
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                    <div className="space-y-4">
                        {assessment?.recommendations && assessment.recommendations.length > 0 && (
                            <div className="bg-gradient-to-r from-orange-50 to-yellow-50 dark:from-orange-900/20 dark:to-yellow-900/20 p-4 rounded-lg border border-orange-200 dark:border-orange-800/30">
                                <h4 className="font-semibold text-orange-900 dark:text-orange-300 mb-2">Risk Mitigation Recommendations</h4>
                                <ul className="space-y-2 text-sm text-orange-800 dark:text-orange-200">
                                    {assessment.recommendations.map((rec, index) => (
                                        <li key={index} className="flex items-start gap-2">
                                            <span className="text-orange-500 dark:text-orange-400 mt-1">•</span>
                                            <span>{rec}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {assessment?.summary && (
                            <div className="bg-gradient-to-r from-gray-50 to-slate-50 dark:from-slate-800/50 dark:to-slate-700/50 p-4 rounded-lg border border-gray-200 dark:border-slate-600">
                                <h4 className="font-semibold text-gray-900 dark:text-[var(--covoria-text-primary)] mb-2">Assessment Summary</h4>
                                <p className="text-sm text-gray-700 dark:text-[var(--covoria-text-secondary)] leading-relaxed">
                                    {assessment.summary}
                                </p>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>
        </motion.div>
    );
}
