import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Target, 
  TrendingUp, 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  Brain,
  ArrowRight,
  Info
} from 'lucide-react';
import { InvokeLLM } from '@/api/integrations';
import { Product, User, InsurancePolicy, SavingsAccount, Insight } from '@/api/entities';

// Smart Product Matching Engine with Reasoning Transparency
export default function SmartProductMatcher({ userData, userContext = {} }) {
  const [productMatches, setProductMatches] = useState([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [matchingReasons, setMatchingReasons] = useState({});
  const [availableProducts, setAvailableProducts] = useState([]);

  useEffect(() => {
    if (userData && Object.keys(userContext).length > 0) {
      loadAvailableProducts();
    }
  }, [userData, userContext]);

  const loadAvailableProducts = async () => {
    try {
      const products = await Product.filter({ is_active: true });
      setAvailableProducts(products);
      
      if (products.length > 0) {
        analyzeProductMatches(products);
      }
    } catch (error) {
      console.error('Failed to load products:', error);
    }
  };

  const analyzeProductMatches = async (products) => {
    setIsAnalyzing(true);
    
    try {
      // Enhanced context for product matching
      const matchingContext = {
        user_profile: {
          age: userData.age || 35,
          marital_status: userData.marital_status || 'single',
          dependents: userData.dependents || 0,
          income_bracket: userData.income_bracket || '50k-100k',
          employment_status: userData.employment_status || 'employed',
          health_status: userData.health_status || 'good'
        },
        current_portfolio: {
          policies: userContext.policies || [],
          accounts: userContext.accounts || [],
          insights: userContext.insights || []
        },
        available_products: products.map(p => ({
          id: p.id,
          name: p.name,
          category: p.category,
          description: p.description,
          target_audience: p.target_audience,
          unique_selling_points: p.unique_selling_points || []
        }))
      };

      // Identify coverage gaps and opportunities
      const gapAnalysis = analyzeCoverageGaps(userContext);
      
      const matchingPrompt = `You are an expert insurance and financial product advisor. Analyze this user's profile and current portfolio to identify the TOP 3 most suitable products from our catalog.

USER PROFILE & PORTFOLIO:
${JSON.stringify(matchingContext, null, 2)}

IDENTIFIED GAPS:
${JSON.stringify(gapAnalysis, null, 2)}

MATCHING CRITERIA:
1. **Need-Based Matching**: Only recommend products that address genuine gaps or inefficiencies
2. **Life Stage Appropriateness**: Products must fit user's age, family status, and career stage
3. **Financial Fit**: Consider income bracket and existing financial commitments
4. **Priority-Based**: Focus on most critical needs first

For each recommended product, provide:
- **Match Score** (0-100): How well this product fits their needs
- **Primary Need Addressed**: Which specific gap or inefficiency this solves
- **Reasoning**: Detailed explanation of why this product is suitable for this user
- **Expected Impact**: What positive change this would create
- **Implementation Priority**: When they should consider this (immediate/3-6 months/future)
- **Cost-Benefit Analysis**: Brief assessment of value proposition

IMPORTANT: Only recommend products if there's a genuine need. If the user is well-covered, say so and focus on optimization opportunities instead.`;

      const response = await InvokeLLM({
        prompt: matchingPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            overall_assessment: { type: "string" },
            portfolio_health_score: { type: "number", minimum: 0, maximum: 100 },
            product_recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  product_id: { type: "string" },
                  match_score: { type: "number", minimum: 0, maximum: 100 },
                  primary_need: { type: "string" },
                  detailed_reasoning: { type: "string" },
                  expected_impact: { type: "string" },
                  implementation_priority: { type: "string", enum: ["immediate", "3-6_months", "future", "optional"] },
                  cost_benefit_summary: { type: "string" },
                  risk_if_ignored: { type: "string" }
                },
                required: ["product_id", "match_score", "primary_need", "detailed_reasoning"]
              }
            },
            optimization_opportunities: {
              type: "array",
              items: { type: "string" }
            }
          },
          required: ["overall_assessment", "product_recommendations"]
        }
      });

      console.log('Smart Product Matching Result:', response);

      if (response.product_recommendations && response.product_recommendations.length > 0) {
        // Enhance recommendations with product details
        const enhancedMatches = response.product_recommendations.map(rec => {
          const product = products.find(p => p.id === rec.product_id);
          return {
            ...rec,
            product: product,
            reasoning_transparency: {
              why_recommended: rec.detailed_reasoning,
              data_points_used: extractDataPoints(rec.detailed_reasoning, userContext),
              confidence_level: rec.match_score >= 80 ? 'high' : rec.match_score >= 60 ? 'medium' : 'low'
            }
          };
        }).filter(match => match.product); // Only include matches where product exists

        setProductMatches(enhancedMatches);
        
        // Store reasoning for each match
        const reasons = {};
        enhancedMatches.forEach(match => {
          reasons[match.product_id] = match.reasoning_transparency;
        });
        setMatchingReasons(reasons);
      }

    } catch (error) {
      console.error('Product matching analysis failed:', error);
      setProductMatches([]);
    }
    
    setIsAnalyzing(false);
  };

  // Analyze Coverage Gaps
  const analyzeCoverageGaps = (context) => {
    const gaps = [];
    const policies = context.policies || [];
    const accounts = context.accounts || [];
    
    // Essential coverage types
    const essentialTypes = ['health', 'life', 'disability', 'auto'];
    const existingTypes = policies.map(p => p.insurance_type);
    
    essentialTypes.forEach(type => {
      if (!existingTypes.includes(type)) {
        gaps.push({
          type: 'coverage_gap',
          category: type,
          severity: type === 'health' || type === 'life' ? 'critical' : 'important',
          description: `No ${type} insurance coverage detected`
        });
      }
    });
    
    // Retirement planning gap
    const retirementAccounts = accounts.filter(a => 
      ['401k', '403b', 'ira', 'roth_ira'].includes(a.account_type)
    );
    
    if (retirementAccounts.length === 0 && userData.age < 55) {
      gaps.push({
        type: 'savings_gap',
        category: 'retirement',
        severity: 'important',
        description: 'No dedicated retirement savings accounts'
      });
    }
    
    return gaps;
  };

  // Extract Data Points Used in Reasoning
  const extractDataPoints = (reasoning, context) => {
    const dataPoints = [];
    
    if (reasoning.toLowerCase().includes('age')) {
      dataPoints.push(`Age: ${userData.age || 'not specified'}`);
    }
    if (reasoning.toLowerCase().includes('dependent')) {
      dataPoints.push(`Dependents: ${userData.dependents || 0}`);
    }
    if (reasoning.toLowerCase().includes('income')) {
      dataPoints.push(`Income bracket: ${userData.income_bracket || 'not specified'}`);
    }
    if (reasoning.toLowerCase().includes('coverage') || reasoning.toLowerCase().includes('policies')) {
      dataPoints.push(`Current policies: ${context.policies?.length || 0}`);
    }
    
    return dataPoints;
  };

  // Handle Product Interest
  const handleProductInterest = async (match) => {
    setSelectedMatch(match);
    
    try {
      // Track user interest for learning
      await Insight.create({
        title: `Interest in ${match.product.name}`,
        description: `User showed interest in ${match.product.category} product based on AI recommendation`,
        category: 'opportunity',
        priority: match.implementation_priority === 'immediate' ? 'high' : 'medium',
        potential_savings: 0,
        action_required: `Follow up on ${match.product.name} inquiry`,
        business_action_suggestion: `Contact user about ${match.product.name} - match score: ${match.match_score}%`,
        created_by: userData.email
      });
      
      console.log('Product interest tracked for learning');
    } catch (error) {
      console.error('Failed to track product interest:', error);
    }
  };

  const getPriorityColor = (priority) => {
    const colors = {
      immediate: 'bg-red-100 text-red-800 border-red-200',
      '3-6_months': 'bg-orange-100 text-orange-800 border-orange-200',
      future: 'bg-blue-100 text-blue-800 border-blue-200',
      optional: 'bg-gray-100 text-gray-600 border-gray-200'
    };
    return colors[priority] || colors.optional;
  };

  const getMatchScoreColor = (score) => {
    if (score >= 80) return 'text-green-600 bg-green-100';
    if (score >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-gray-600 bg-gray-100';
  };

  if (isAnalyzing) {
    return (
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-purple-600" />
            Smart Product Matching
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="text-center">
              <Brain className="w-12 h-12 text-purple-600 animate-pulse mx-auto mb-4" />
              <p className="text-sm text-gray-600 mb-2">Analyzing your portfolio for product matches...</p>
              <div className="flex gap-1 justify-center">
                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{animationDelay: '100ms'}}></div>
                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{animationDelay: '200ms'}}></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (productMatches.length === 0) {
    return (
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-purple-600" />
            Smart Product Matching
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="font-semibold text-green-800 mb-2">Portfolio Looks Great!</h3>
            <p className="text-sm text-gray-600">
              Based on my analysis, your current coverage appears well-suited to your needs. 
              I'll continue monitoring for optimization opportunities.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-600" />
              Smart Product Matches
            </div>
            <Badge className="bg-purple-100 text-purple-800">
              AI-Recommended
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <AnimatePresence>
            {productMatches.map((match, index) => (
              <motion.div
                key={match.product_id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-gray-900">{match.product.name}</h3>
                      <Badge className={`text-xs ${getMatchScoreColor(match.match_score)}`}>
                        {match.match_score}% match
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">{match.product.description}</p>
                  </div>
                  <Badge className={`text-xs ${getPriorityColor(match.implementation_priority)}`}>
                    {match.implementation_priority.replace('_', '-')}
                  </Badge>
                </div>

                {/* Primary Need Addressed */}
                <div className="mb-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center gap-2 mb-1">
                    <Shield className="w-4 h-4 text-blue-600" />
                    <span className="text-sm font-medium text-blue-900">Addresses Your Need:</span>
                  </div>
                  <p className="text-sm text-blue-800">{match.primary_need}</p>
                </div>

                {/* AI Reasoning Transparency */}
                <div className="mb-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="flex items-center gap-2 mb-2">
                    <Brain className="w-4 h-4 text-yellow-600" />
                    <span className="text-sm font-medium text-yellow-900">Why I'm Recommending This:</span>
                  </div>
                  <p className="text-sm text-yellow-800 mb-2">{match.detailed_reasoning}</p>
                  
                  {/* Data Points Used */}
                  {match.reasoning_transparency.data_points_used.length > 0 && (
                    <div className="mt-2">
                      <p className="text-xs font-medium text-yellow-700 mb-1">Based on your data:</p>
                      <div className="flex flex-wrap gap-1">
                        {match.reasoning_transparency.data_points_used.map((point, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs text-yellow-700 border-yellow-300">
                            {point}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Expected Impact */}
                {match.expected_impact && (
                  <div className="mb-3 p-3 bg-green-50 rounded-lg border border-green-200">
                    <div className="flex items-center gap-2 mb-1">
                      <TrendingUp className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-900">Expected Impact:</span>
                    </div>
                    <p className="text-sm text-green-800">{match.expected_impact}</p>
                  </div>
                )}

                {/* Risk if Ignored */}
                {match.risk_if_ignored && (
                  <div className="mb-3 p-3 bg-red-50 rounded-lg border border-red-200">
                    <div className="flex items-center gap-2 mb-1">
                      <AlertTriangle className="w-4 h-4 text-red-600" />
                      <span className="text-sm font-medium text-red-900">Risk of Not Acting:</span>
                    </div>
                    <p className="text-sm text-red-800">{match.risk_if_ignored}</p>
                  </div>
                )}

                {/* Cost-Benefit Summary */}
                {match.cost_benefit_summary && (
                  <div className="mb-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex items-center gap-2 mb-1">
                      <Info className="w-4 h-4 text-gray-600" />
                      <span className="text-sm font-medium text-gray-900">Value Assessment:</span>
                    </div>
                    <p className="text-sm text-gray-700">{match.cost_benefit_summary}</p>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2 pt-2">
                  <Button
                    onClick={() => handleProductInterest(match)}
                    className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                    size="sm"
                  >
                    I'm Interested
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-gray-600 hover:text-gray-800"
                  >
                    Tell Me More
                  </Button>
                </div>

                {/* Confidence Indicator */}
                <div className="mt-2 pt-2 border-t border-gray-100">
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>Confidence: {match.reasoning_transparency.confidence_level}</span>
                    <span>Priority: {match.implementation_priority}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Learning Notice */}
          <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-900">Continuous Learning</span>
            </div>
            <p className="text-xs text-blue-700 mt-1">
              These recommendations improve over time based on your feedback and portfolio changes.
              Your interactions help me provide better matches for everyone.
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}