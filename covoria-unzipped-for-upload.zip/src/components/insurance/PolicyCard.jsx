
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, Edit, DollarSign, FileText } from 'lucide-react';

const getPolicyTypeIcon = (type) => {
  const icons = {
    health: '❤️',
    life: '👨‍👩‍👧‍👦',
    auto: '🚗',
    home: '🏠',
    disability: '💪'
  };
  return icons[type] || '🛡️';
};

export default function PolicyCard({ policy, delay, onEdit }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: delay || 0 }}
      className="h-full"
    >
      <Card className="covoria-card flex flex-col h-full group p-0">
        <CardHeader className="flex flex-row items-start justify-between gap-4 p-5">
          <div className="flex items-start gap-4 flex-1 min-w-0">
            <div className="text-3xl mt-1">{getPolicyTypeIcon(policy.insurance_type)}</div>
            <div className="flex-1 min-w-0">
              <CardTitle className="text-base text-slate-100 mb-1 text-overflow-safe">{policy.policy_name}</CardTitle>
              <p className="text-sm text-slate-400 capitalize">{policy.provider}</p>
            </div>
          </div>
          <Badge className={`flex-shrink-0 ${policy.is_active ? 'bg-green-500/20 text-green-300' : 'bg-slate-700 text-slate-400'}`}>
            {policy.is_active ? 'Active' : 'Inactive'}
          </Badge>
        </CardHeader>

        <CardContent className="flex-grow p-5 pt-0 space-y-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400 flex items-center gap-2"><DollarSign className="w-4 h-4" />Coverage</span>
            <span className="font-semibold text-white">${(policy.coverage_amount || 0).toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400 flex items-center gap-2"><FileText className="w-4 h-4" />Policy #</span>
            <span className="font-mono text-xs text-slate-300">{policy.policy_number || 'N/A'}</span>
          </div>
        </CardContent>

        <CardFooter className="p-5 bg-slate-800/50 mt-auto flex justify-end">
          <Button onClick={onEdit} variant="ghost" className="text-slate-400 hover:text-white">
            <Edit className="w-4 h-4 mr-2" />
            Edit Policy
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
