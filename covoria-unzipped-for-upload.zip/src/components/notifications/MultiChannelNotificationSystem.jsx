import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bell, 
  Mail, 
  MessageSquare, 
  Send, 
  CheckCircle, 
  XCircle,
  Clock,
  Settings,
  Target,
  Users
} from 'lucide-react';
import { multiChannelNotifier } from '@/api/functions';
import { User } from '@/api/entities';

const NotificationCard = ({ notification, onResend, onDismiss }) => {
  const getStatusIcon = (status) => {
    switch (status) {
      case 'sent': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-600" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-600" />;
      default: return <Bell className="w-4 h-4 text-gray-600" />;
    }
  };

  const getChannelIcon = (channel) => {
    switch (channel) {
      case 'email': return <Mail className="w-4 h-4" />;
      case 'sms': return <MessageSquare className="w-4 h-4" />;
      default: return <Bell className="w-4 h-4" />;
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="p-4 border rounded-lg bg-white hover:shadow-md transition-all"
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            {getChannelIcon(notification.channel)}
            <span className="font-medium text-gray-900">{notification.subject}</span>
            {getStatusIcon(notification.status)}
          </div>
          
          <p className="text-sm text-gray-600 mb-2">{notification.message}</p>
          
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <span>To: {notification.recipient}</span>
            <span>•</span>
            <span>{new Date(notification.timestamp).toLocaleString()}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2 ml-4">
          {notification.status === 'failed' && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => onResend(notification)}
              className="text-xs"
            >
              Resend
            </Button>
          )}
          <Button
            size="sm"
            variant="ghost"
            onClick={() => onDismiss(notification.id)}
            className="text-xs"
          >
            Dismiss
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default function MultiChannelNotificationSystem() {
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [newNotification, setNewNotification] = useState({
    recipient: '',
    subject: '',
    message: '',
    channels: ['email']
  });
  const [users, setUsers] = useState([]);

  useEffect(() => {
    loadUsers();
    loadNotificationHistory();
  }, []);

  const loadUsers = async () => {
    try {
      // In a real implementation, this might be a user list endpoint
      const user = await User.me();
      setUsers([user]);
    } catch (error) {
      console.error('Failed to load users:', error);
    }
  };

  const loadNotificationHistory = () => {
    // Load from localStorage for demo purposes
    const saved = localStorage.getItem('notification_history');
    if (saved) {
      setNotifications(JSON.parse(saved));
    }
  };

  const saveNotificationHistory = (newNotifications) => {
    localStorage.setItem('notification_history', JSON.stringify(newNotifications));
  };

  const sendNotification = async () => {
    if (!newNotification.recipient || !newNotification.subject || !newNotification.message) {
      return;
    }

    setIsLoading(true);
    
    try {
      const response = await multiChannelNotifier({
        recipient: newNotification.recipient,
        subject: newNotification.subject,
        message: newNotification.message,
        channels: newNotification.channels
      });

      const notificationRecord = {
        id: Date.now().toString(),
        ...newNotification,
        status: response.data?.success ? 'sent' : 'failed',
        timestamp: new Date().toISOString(),
        results: response.data?.results || []
      };

      const updatedNotifications = [notificationRecord, ...notifications];
      setNotifications(updatedNotifications);
      saveNotificationHistory(updatedNotifications);

      // Reset form
      setNewNotification({
        recipient: '',
        subject: '',
        message: '',
        channels: ['email']
      });

    } catch (error) {
      console.error('Failed to send notification:', error);
      
      const failedRecord = {
        id: Date.now().toString(),
        ...newNotification,
        status: 'failed',
        timestamp: new Date().toISOString(),
        error: error.message
      };

      const updatedNotifications = [failedRecord, ...notifications];
      setNotifications(updatedNotifications);
      saveNotificationHistory(updatedNotifications);
    }
    
    setIsLoading(false);
  };

  const resendNotification = async (notification) => {
    setIsLoading(true);
    
    try {
      const response = await multiChannelNotifier({
        recipient: notification.recipient,
        subject: notification.subject,
        message: notification.message,
        channels: notification.channels
      });

      const updatedNotifications = notifications.map(n => 
        n.id === notification.id 
          ? { ...n, status: response.data?.success ? 'sent' : 'failed', timestamp: new Date().toISOString() }
          : n
      );
      
      setNotifications(updatedNotifications);
      saveNotificationHistory(updatedNotifications);
      
    } catch (error) {
      console.error('Failed to resend notification:', error);
    }
    
    setIsLoading(false);
  };

  const dismissNotification = (notificationId) => {
    const updatedNotifications = notifications.filter(n => n.id !== notificationId);
    setNotifications(updatedNotifications);
    saveNotificationHistory(updatedNotifications);
  };

  const getStats = () => {
    const total = notifications.length;
    const sent = notifications.filter(n => n.status === 'sent').length;
    const failed = notifications.filter(n => n.status === 'failed').length;
    
    return { total, sent, failed };
  };

  const stats = getStats();

  return (
    <div className="space-y-6">
      {/* Header & Stats */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-blue-100 rounded-xl">
            <Bell className="w-8 h-8 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Notification System</h1>
            <p className="text-gray-600">Multi-channel notification management</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm">
            <Badge className="bg-blue-100 text-blue-800">{stats.total} Total</Badge>
            <Badge className="bg-green-100 text-green-800">{stats.sent} Sent</Badge>
            <Badge className="bg-red-100 text-red-800">{stats.failed} Failed</Badge>
          </div>
        </div>
      </div>

      {/* Send New Notification */}
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" />
            Send New Notification
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Recipient</label>
              <Input
                placeholder="user@example.com"
                value={newNotification.recipient}
                onChange={(e) => setNewNotification(prev => ({ ...prev, recipient: e.target.value }))}
              />
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Channels</label>
              <Select
                value={newNotification.channels[0]}
                onValueChange={(value) => setNewNotification(prev => ({ ...prev, channels: [value] }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="sms">SMS (Coming Soon)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">Subject</label>
            <Input
              placeholder="Notification subject"
              value={newNotification.subject}
              onChange={(e) => setNewNotification(prev => ({ ...prev, subject: e.target.value }))}
            />
          </div>
          
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">Message</label>
            <Textarea
              placeholder="Your notification message..."
              value={newNotification.message}
              onChange={(e) => setNewNotification(prev => ({ ...prev, message: e.target.value }))}
              rows={4}
            />
          </div>
          
          <Button
            onClick={sendNotification}
            disabled={isLoading || !newNotification.recipient || !newNotification.subject}
            className="covoria-gradient text-white"
          >
            {isLoading ? (
              <>
                <Clock className="w-4 h-4 mr-2 animate-spin" />
                Sending...
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Send Notification
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Notification History */}
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Notification History
          </CardTitle>
        </CardHeader>
        <CardContent>
          {notifications.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Bell className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>No notifications sent yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              <AnimatePresence>
                {notifications.map((notification) => (
                  <NotificationCard
                    key={notification.id}
                    notification={notification}
                    onResend={resendNotification}
                    onDismiss={dismissNotification}
                  />
                ))}
              </AnimatePresence>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}