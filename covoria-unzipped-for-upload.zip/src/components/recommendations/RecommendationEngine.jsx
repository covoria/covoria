import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, 
  TrendingUp, 
  Target, 
  Star, 
  ArrowRight,
  Lightbulb,
  Shield,
  DollarSign,
  Clock
} from 'lucide-react';
import { User } from '@/api/entities';
import { InsurancePolicy } from '@/api/entities';
import { SavingsAccount } from '@/api/entities';
import { Insight } from '@/api/entities';
import { intelligentAssistant } from '@/api/functions';

const RecommendationCard = ({ recommendation, onAccept, onDismiss }) => {
  const getIconForCategory = (category) => {
    const icons = {
      'insurance': Shield,
      'savings': DollarSign,
      'optimization': TrendingUp,
      'protection': Shield,
      default: Lightbulb
    };
    const IconComponent = icons[category] || icons.default;
    return <IconComponent className="w-5 h-5" />;
  };

  const getColorForPriority = (priority) => {
    const colors = {
      'high': 'border-red-200 bg-red-50',
      'medium': 'border-yellow-200 bg-yellow-50', 
      'low': 'border-blue-200 bg-blue-50'
    };
    return colors[priority] || 'border-gray-200 bg-gray-50';
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20, transition: { duration: 0.2 } }}
      className={`p-4 border rounded-lg ${getColorForPriority(recommendation.priority)} transition-all hover:shadow-md`}
    >
      <div className="flex items-start gap-3">
        <div className="p-2 bg-white rounded-lg shadow-sm mt-1">
          {getIconForCategory(recommendation.category)}
        </div>
        <div className="flex-1">
          <div className="flex items-start justify-between">
            <h3 className="font-semibold text-gray-900 flex-1 pr-2">{recommendation.title}</h3>
            <div className="flex items-center gap-2 flex-shrink-0">
              <Badge variant="outline" className="text-xs">
                {recommendation.confidence}% conf.
              </Badge>
            </div>
          </div>
          
          <p className="text-sm text-gray-600 mt-2">{recommendation.description}</p>
          
          <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
            <div className="flex items-center gap-1">
              <DollarSign className="w-3 h-3" />
              ${recommendation.potential_savings || 0} savings
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {recommendation.timeframe || 'Immediate'}
            </div>
          </div>

          <div className="flex items-center gap-2 mt-4">
            <Button size="sm" onClick={() => onAccept(recommendation)} className="covoria-gradient text-white">
              <ArrowRight className="w-3 h-3 mr-1" />
              {recommendation.action_text || 'Take Action'}
            </Button>
            <Button size="sm" variant="outline" onClick={() => onDismiss(recommendation.id)}>
              Maybe Later
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default function RecommendationEngine() {
  const [recommendations, setRecommendations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetchUserDataAndRecommendations();
  }, []);

  const fetchUserDataAndRecommendations = async () => {
    setIsLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
      
      const response = await intelligentAssistant({
        message: 'Generate top 5 personalized financial recommendations for me based on my profile.',
        analysis_depth: 'deep'
      });
      
      if (response.data.success && response.data.data.recommendations) {
        setRecommendations(response.data.data.recommendations.map(r => ({ ...r, id: Math.random() })));
      } else {
        // Fallback to mock data if API fails
        generateMockRecommendations();
      }
    } catch (error) {
      console.error("Failed to fetch recommendations, generating mock data.", error);
      generateMockRecommendations();
    }
    setIsLoading(false);
  };
  
  const generateMockRecommendations = () => {
      setRecommendations([
        { id: 1, title: 'Consolidate High-Interest Debt', description: 'Consider a low-interest personal loan to consolidate credit card balances and reduce monthly payments.', category: 'savings', priority: 'high', confidence: 95, potential_savings: 150, timeframe: '1-3 Months', action_text: 'Explore Options' },
        { id: 2, title: 'Increase Life Insurance Coverage', description: 'Your current life insurance may not be sufficient for your family\'s needs. We suggest reviewing your coverage amount.', category: 'insurance', priority: 'high', confidence: 92, potential_savings: 0, timeframe: 'Immediate', action_text: 'Review Coverage' },
        { id: 3, title: 'Optimize Your 401(k) Contributions', description: 'You are not maximizing your employer\'s 401(k) match. Increasing your contribution by 2% could yield significant returns.', category: 'savings', priority: 'medium', confidence: 88, potential_savings: 1200, timeframe: 'Next Paycheck', action_text: 'Adjust Contribution' },
        { id: 4, title: 'Review Auto Insurance Deductibles', description: 'Your auto insurance deductibles are low, leading to higher premiums. Raising them could lower your monthly costs.', category: 'optimization', priority: 'low', confidence: 85, potential_savings: 45, timeframe: 'Immediate', action_text: 'Get Quotes' }
      ]);
  };

  const handleDismiss = (id) => {
    setRecommendations(prev => prev.filter(rec => rec.id !== id));
  };
  
  const handleAccept = (recommendation) => {
    console.log("Action taken for:", recommendation);
    handleDismiss(recommendation.id);
  };

  return (
    <Card className="covoria-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-xl">
          <Brain className="w-6 h-6 text-cyan-600" />
          <span>Personalized Recommendations</span>
        </CardTitle>
        <p className="text-gray-600">AI-powered suggestions to improve your financial health.</p>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
             {[...Array(3)].map((_, i) => <div key={i} className="h-20 bg-gray-100 rounded-lg animate-pulse" />)}
          </div>
        ) : (
          <AnimatePresence>
            {recommendations.length > 0 ? (
              <div className="space-y-4">
                {recommendations.map(rec => (
                  <RecommendationCard
                    key={rec.id}
                    recommendation={rec}
                    onAccept={handleAccept}
                    onDismiss={handleDismiss}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-600">No new recommendations at this time. Check back later!</p>
              </div>
            )}
          </AnimatePresence>
        )}
      </CardContent>
    </Card>
  );
}