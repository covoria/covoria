import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ListFilter, Shield } from 'lucide-react';

export default function AccountFilters({ onFilterChange }) {
  const [filters, setFilters] = React.useState({
    type: 'all',
    status: 'all'
  });

  const handleFilterChange = (filterType, value) => {
    const newFilters = { ...filters, [filterType]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  return (
    <div className="flex gap-2 flex-wrap">
      <Select onValueChange={(value) => handleFilterChange('type', value)} value={filters.type}>
        <SelectTrigger className="w-[140px] bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
          <ListFilter className="w-4 h-4 mr-2" />
          <SelectValue placeholder="All Types" />
        </SelectTrigger>
        <SelectContent className="bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
          <SelectItem value="all">All Types</SelectItem>
          <SelectItem value="401k">401k</SelectItem>
          <SelectItem value="ira">IRA</SelectItem>
          <SelectItem value="roth_ira">Roth IRA</SelectItem>
          <SelectItem value="hsa">HSA</SelectItem>
          <SelectItem value="general_savings">General Savings</SelectItem>
        </SelectContent>
      </Select>

      <Select onValueChange={(value) => handleFilterChange('status', value)} value={filters.status}>
        <SelectTrigger className="w-[140px] bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
          <Shield className="w-4 h-4 mr-2" />
          <SelectValue placeholder="All Status" />
        </SelectTrigger>
        <SelectContent className="bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
          <SelectItem value="all">All Status</SelectItem>
          <SelectItem value="active">Active</SelectItem>
          <SelectItem value="inactive">Inactive</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}