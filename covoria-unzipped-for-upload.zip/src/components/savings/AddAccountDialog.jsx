import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { SavingsAccount } from '@/api/entities';

export default function AddAccountDialog({ onClose, onUpdate, account }) {
  const [formData, setFormData] = useState({
    account_name: '',
    account_type: 'general_savings',
    provider: '',
    current_balance: '',
    contribution_amount: '',
    contribution_frequency: 'monthly',
    interest_rate: '',
    is_active: true,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (account) {
      setFormData({
        ...account,
        current_balance: account.current_balance || '',
        contribution_amount: account.contribution_amount || '',
        interest_rate: account.interest_rate || '',
      });
    }
  }, [account]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const dataToSave = {
        ...formData,
        current_balance: parseFloat(formData.current_balance) || 0,
        contribution_amount: parseFloat(formData.contribution_amount) || 0,
        interest_rate: parseFloat(formData.interest_rate) || 0,
      };
      
      if (account) {
        await SavingsAccount.update(account.id, dataToSave);
      } else {
        await SavingsAccount.create(dataToSave);
      }
      onUpdate();
    } catch (error) {
      console.error('Failed to save account:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
        <DialogHeader>
          <DialogTitle>{account ? 'Edit Account' : 'Add New Account'}</DialogTitle>
          <DialogDescription>
            {account ? 'Update the details for this savings account.' : 'Enter the details for the new savings account.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="account_name" className="text-right">Name</Label>
            <Input id="account_name" name="account_name" value={formData.account_name} onChange={handleChange} className="col-span-3 bg-[var(--covoria-bg-main)] border-[var(--covoria-border-color)]" />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="account_type" className="text-right">Type</Label>
            <Select name="account_type" onValueChange={(value) => handleSelectChange('account_type', value)} value={formData.account_type}>
              <SelectTrigger className="col-span-3 bg-[var(--covoria-bg-main)] border-[var(--covoria-border-color)]">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent className="bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)]">
                <SelectItem value="general_savings">General Savings</SelectItem>
                <SelectItem value="401k">401k</SelectItem>
                <SelectItem value="ira">IRA</SelectItem>
                <SelectItem value="roth_ira">Roth IRA</SelectItem>
                <SelectItem value="hsa">HSA</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="provider" className="text-right">Provider</Label>
            <Input id="provider" name="provider" value={formData.provider} onChange={handleChange} className="col-span-3 bg-[var(--covoria-bg-main)] border-[var(--covoria-border-color)]" />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="current_balance" className="text-right">Balance</Label>
            <Input id="current_balance" name="current_balance" type="number" value={formData.current_balance} onChange={handleChange} className="col-span-3 bg-[var(--covoria-bg-main)] border-[var(--covoria-border-color)]" />
          </div>
          
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="is_active" className="text-right">Active</Label>
            <Switch
              id="is_active"
              checked={formData.is_active}
              onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, is_active: checked }))}
            />
          </div>
        </form>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
          <Button type="submit" onClick={handleSubmit} disabled={isSubmitting} className="covoria-gradient text-white">
            {isSubmitting ? 'Saving...' : 'Save Account'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}