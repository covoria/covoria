import { InvokeLLM } from "@/api/integrations";

class AITermService {
  constructor() {
    this.termCache = new Map();
    this.commonTerms = [
      'deductible', 'premium', 'copay', 'coinsurance', 'out-of-pocket maximum',
      'beneficiary', 'underwriting', 'rider', 'term life', 'whole life',
      'liability', 'comprehensive', 'collision', 'uninsured motorist',
      'HSA', '401k', 'IRA', 'vesting', 'employer match'
    ];
  }

  async explainTerm(term) {
    // Check cache first
    if (this.termCache.has(term.toLowerCase())) {
      return this.termCache.get(term.toLowerCase());
    }

    try {
      const prompt = `
        Explain the insurance/financial term "${term}" in simple, non-technical English.
        Requirements:
        - Maximum 30 words
        - Use everyday language
        - Include a brief practical example if possible
        - Avoid jargon
        
        Term: ${term}
      `;

      const explanation = await InvokeLLM({
        prompt: prompt
      });

      // Cache the explanation
      this.termCache.set(term.toLowerCase(), explanation);
      
      return explanation;
    } catch (error) {
      console.error('Error explaining term:', error);
      return `Sorry, I couldn't explain "${term}" right now. Please try again.`;
    }
  }

  detectTermInMessage(message) {
    const words = message.toLowerCase().split(/\s+/);
    
    // Look for "what is" or "what's" patterns
    const whatIsPattern = /what\s+is\s+(\w+)/i;
    const whatsPattern = /what's\s+(\w+)/i;
    
    let match = message.match(whatIsPattern) || message.match(whatsPattern);
    if (match) {
      return match[1];
    }
    
    // Look for common terms in the message
    for (const term of this.commonTerms) {
      if (words.includes(term)) {
        return term;
      }
    }
    
    return null;
  }

  isTermExplanationRequest(message) {
    const patterns = [
      /what\s+is\s+\w+/i,
      /what's\s+\w+/i,
      /explain\s+\w+/i,
      /define\s+\w+/i,
      /meaning\s+of\s+\w+/i
    ];
    
    return patterns.some(pattern => pattern.test(message));
  }
}

export default new AITermService();