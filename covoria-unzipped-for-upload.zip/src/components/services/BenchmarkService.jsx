class BenchmarkService {
  constructor() {
    this.data = null;
    this.isLoaded = false;
    this.isLoading = false;
    this.fallbackData = {
      auto: { averageMonthly: 142, nationalRange: { min: 89, max: 245 } },
      health: { averageMonthly: 329, nationalRange: { min: 215, max: 520 } },
      life: { averageAnnual: 450, nationalRange: { min: 180, max: 2400 } },
      home: { averageMonthly: 108, nationalRange: { min: 65, max: 285 } },
      disability: { averageMonthly: 67, nationalRange: { min: 25, max: 200 } },
      retirement: { recommendedMonthly: 250 }
    };
  }

  async loadBenchmarks() {
    if (this.isLoaded || this.isLoading) {
      return this.data || this.fallbackData;
    }

    this.isLoading = true;
    try {
      // Using embedded data instead of external fetch for base44 platform
      const benchmarkData = {
        "auto": {
          "averageMonthly": 142,
          "byState": {
            "CA": 162, "TX": 138, "FL": 165, "NY": 178, "IL": 134,
            "PA": 129, "OH": 119, "GA": 155, "NC": 124, "MI": 167
          },
          "nationalRange": { "min": 89, "max": 245 }
        },
        "health": {
          "averageMonthly": 329,
          "byState": {
            "CA": 385, "TX": 298, "FL": 342, "NY": 425, "IL": 315,
            "PA": 289, "OH": 278, "GA": 321, "NC": 267, "MI": 356
          },
          "nationalRange": { "min": 215, "max": 520 }
        },
        "life": {
          "averageAnnual": 450,
          "byAge": {
            "20-29": 215, "30-39": 285, "40-49": 445, "50-59": 685, "60+": 1250
          },
          "nationalRange": { "min": 180, "max": 2400 }
        },
        "home": {
          "averageMonthly": 108,
          "byState": {
            "CA": 95, "TX": 185, "FL": 165, "NY": 125, "IL": 89,
            "PA": 78, "OH": 73, "GA": 145, "NC": 95, "MI": 89
          },
          "nationalRange": { "min": 65, "max": 285 }
        },
        "disability": {
          "averageMonthly": 67,
          "byIncome": {
            "30000-50000": 45, "50000-75000": 65, "75000-100000": 85, "100000+": 125
          },
          "nationalRange": { "min": 25, "max": 200 }
        },
        "retirement": {
          "recommendedMonthly": 250,
          "byAge": {
            "20-29": 150, "30-39": 225, "40-49": 350, "50-59": 525, "60+": 750
          },
          "employerMatch": { "average": 3.5, "range": { "min": 0, "max": 8 } }
        },
        "lastUpdated": "2024-01-15",
        "dataSource": "Covoria Market Research 2024"
      };

      this.data = benchmarkData;
      this.isLoaded = true;
      console.log('✅ Benchmark data loaded successfully');
      return this.data;
    } catch (error) {
      console.warn('⚠️ Using fallback benchmark data:', error.message);
      this.data = this.fallbackData;
      this.isLoaded = true;
      return this.data;
    } finally {
      this.isLoading = false;
    }
  }

  getBenchmarkForCategory(category, userState = null, userAge = null, userIncome = null) {
    if (!this.data) return this.fallbackData[category] || {};
    
    const categoryData = this.data[category];
    if (!categoryData) return {};

    let benchmark = { ...categoryData };
    
    // Add state-specific data if available
    if (userState && categoryData.byState && categoryData.byState[userState]) {
      benchmark.userStateBenchmark = categoryData.byState[userState];
    }
    
    // Add age-specific data if available
    if (userAge && categoryData.byAge) {
      const ageRange = this.getAgeRange(userAge);
      if (categoryData.byAge[ageRange]) {
        benchmark.userAgeBenchmark = categoryData.byAge[ageRange];
      }
    }
    
    // Add income-specific data if available
    if (userIncome && categoryData.byIncome) {
      const incomeRange = this.getIncomeRange(userIncome);
      if (categoryData.byIncome[incomeRange]) {
        benchmark.userIncomeBenchmark = categoryData.byIncome[incomeRange];
      }
    }
    
    return benchmark;
  }

  getAgeRange(age) {
    if (age < 30) return '20-29';
    if (age < 40) return '30-39';
    if (age < 50) return '40-49';
    if (age < 60) return '50-59';
    return '60+';
  }

  getIncomeRange(income) {
    if (income < 50000) return '30000-50000';
    if (income < 75000) return '50000-75000';
    if (income < 100000) return '75000-100000';
    return '100000+';
  }

  compareUserToBenchmark(userAmount, category, frequency = 'monthly', userState = null) {
    const benchmark = this.getBenchmarkForCategory(category, userState);
    let benchmarkAmount;
    
    if (frequency === 'monthly') {
      benchmarkAmount = benchmark.averageMonthly || benchmark.userStateBenchmark || benchmark.recommendedMonthly;
    } else if (frequency === 'annual') {
      benchmarkAmount = benchmark.averageAnnual || (benchmark.averageMonthly * 12);
    }
    
    if (!benchmarkAmount) return null;
    
    const difference = userAmount - benchmarkAmount;
    const percentageDiff = (difference / benchmarkAmount) * 100;
    
    return {
      userAmount,
      benchmarkAmount,
      difference,
      percentageDiff: Math.round(percentageDiff),
      isHigher: difference > 0,
      isSignificant: Math.abs(percentageDiff) > 15
    };
  }
}

export default new BenchmarkService();