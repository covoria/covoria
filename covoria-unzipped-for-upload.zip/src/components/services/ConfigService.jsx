class ConfigService {
  constructor() {
    this.config = null;
    this.isLoaded = false;
    this.fallbackConfig = {
      features: {
        newsComponent: { enabled: true, maxItems: 2, showOnMobile: false },
        benchmarkData: { enabled: true, fallbackMode: true },
        aiTermExplanations: { enabled: true, maxCacheSize: 100 },
        enhancedInsightCards: { enabled: true, showSourceInfo: true, trackDismissed: true },
        documentVault: { enabled: true, maxFileSize: 10485760 },
        smartCheckIn: { enabled: true, reminderIntervals: [180, 365] },
        insightAccuracy: { enabled: true, flagDiscrepancies: true },
        coverageScore: { enabled: true, updateInterval: "realtime" }
      },
      experimental: {}
    };
  }

  async loadConfig() {
    if (this.isLoaded) {
      return this.config;
    }

    try {
      // Using embedded configuration instead of external fetch
      const configData = {
        "features": {
          "newsComponent": {
            "enabled": true,
            "maxItems": 2,
            "showOnMobile": false,
            "refreshInterval": 1800000
          },
          "benchmarkData": {
            "enabled": true,
            "fallbackMode": true,
            "cacheTimeout": 3600000
          },
          "aiTermExplanations": {
            "enabled": true,
            "maxCacheSize": 100,
            "responseMaxWords": 30
          },
          "enhancedInsightCards": {
            "enabled": true,
            "showSourceInfo": true,
            "allowDismiss": true,
            "trackDismissed": true
          },
          "documentVault": {
            "enabled": true,
            "maxFileSize": 10485760,
            "allowedTypes": [".pdf", ".doc", ".docx", ".jpg", ".png", ".xlsx", ".csv"],
            "autoDetectCategory": true
          },
          "smartCheckIn": {
            "enabled": true,
            "reminderIntervals": [180, 365],
            "lifeEventTriggers": ["marriage", "birth", "job_change", "home_purchase"]
          },
          "insightAccuracy": {
            "enabled": true,
            "crossCheckThreshold": 0.8,
            "flagDiscrepancies": true
          },
          "coverageScore": {
            "enabled": true,
            "updateInterval": "realtime",
            "showBreakdown": true
          }
        },
        "experimental": {
          "advancedBenchmarking": {
            "enabled": false,
            "description": "Age and income-based comparisons"
          },
          "smartNotifications": {
            "enabled": false,
            "description": "Proactive policy renewal reminders"
          },
          "voiceAssistant": {
            "enabled": false,
            "description": "Voice-powered insurance queries"
          }
        },
        "environment": "production",
        "lastUpdated": "2024-01-15T10:00:00Z"
      };

      this.config = configData;
      this.isLoaded = true;
      console.log('✅ Configuration loaded successfully');
      return this.config;
    } catch (error) {
      console.warn('⚠️ Using fallback configuration:', error.message);
      this.config = this.fallbackConfig;
      this.isLoaded = true;
      return this.config;
    }
  }

  isFeatureEnabled(featurePath) {
    if (!this.config) return false;
    
    const keys = featurePath.split('.');
    let current = this.config;
    
    for (const key of keys) {
      if (current && typeof current === 'object' && key in current) {
        current = current[key];
      } else {
        return false;
      }
    }
    
    return current && current.enabled === true;
  }

  getFeatureConfig(featurePath) {
    if (!this.config) return null;
    
    const keys = featurePath.split('.');
    let current = this.config;
    
    for (const key of keys) {
      if (current && typeof current === 'object' && key in current) {
        current = current[key];
      } else {
        return null;
      }
    }
    
    return current;
  }

  isExperimentalFeatureEnabled(featureName) {
    return this.isFeatureEnabled(`experimental.${featureName}`);
  }

  getEnvironment() {
    return this.config?.environment || 'development';
  }
}

export default new ConfigService();