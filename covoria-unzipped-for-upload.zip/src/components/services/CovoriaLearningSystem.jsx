
// SPRINT 19 – AI SELF-LEARNING SYSTEM FOR COVORIA
// SPRINT 20 UPDATES: Knowledge integration, coverage analysis, assistant enhancement
// SPRINT 22 UPDATES: Fixed knowledge base sync and version management

import { InvokeLLM } from '@/api/integrations';
import { InsuranceKnowledgeBase } from '@/api/entities';

//////////////////////////////////////////////////////////////////
// 1. INITIATE KNOWLEDGE MEMORY ON FIRST LOAD
//////////////////////////////////////////////////////////////////

const initialKnowledge = {
  structure: {
    businessTabs: ["Partner Portal", "Product Listings", "Enterprise Tagline", "Admin Upload Tracker"],
    userTabs: ["Home", "Upload", "Insights", "Assistant", "Settings"]
  },
  behavior: {
    tone: "Empathetic, helpful, simple language, client-first always",
    mission: "Make insurance feel human. Provide instant peace of mind.",
    rules: ["No technical terms", "Emotional intelligence", "Color cues = trust/safety"]
  },
  // Updated pastSprints to be an array for easier logging of new sprints
  pastSprints: [
    { sprint: 17, description: "Emotional tooltips, color redesign, empathy-focused feedback system" },
    { sprint: 18, description: "Smart UX: ranked insights, rapid local analysis, simplified messaging" },
    { sprint: 19, description: "AI self-learning system with persistent knowledge and user context awareness" },
    { sprint: 22, description: "Fixed knowledge base sync, automatic PDF parsing, version management" }
  ],
  qaHistory: [],
  aiInsights: [],
  userPatterns: {},
  conversationContext: {},
  lastUpdated: new Date().toISOString(),
  knowledgeBaseVersion: '1.0.0'
};

export function initializeKnowledgeCore() {
  if (!localStorage.getItem("covoria_knowledge_core")) {
    localStorage.setItem("covoria_knowledge_core", JSON.stringify(initialKnowledge));
    console.log("🧠 Covoria AI Knowledge Core initialized");
  }

  // Initialize knowledge base version if not exists
  if (!localStorage.getItem("covoria_kb_version")) {
    localStorage.setItem("covoria_kb_version", "1.0.0");
    console.log("📚 Knowledge Base version initialized: 1.0.0");
  }
}

//////////////////////////////////////////////////////////////////
// 2. ENHANCED KNOWLEDGE BASE INTEGRATION
//////////////////////////////////////////////////////////////////

// FIXED: Enhanced function to get formatted knowledge with source attribution and version awareness
async function getKnowledgeBaseSnapshot(limit = 20, userContext = {}) {
    try {
        // Check if assistant refresh is needed
        const refreshNeeded = localStorage.getItem('covoria_assistant_refresh_needed');
        if (refreshNeeded) {
            console.log("🔄 Assistant knowledge refresh triggered");
            localStorage.removeItem('covoria_assistant_refresh_needed');
        }

        // Get current KB version
        const currentVersion = localStorage.getItem('covoria_kb_version') || '1.0.0';
        console.log(`📚 Loading knowledge base version: ${currentVersion}`);

        // Filter by active, AI-visible entries only
        const items = await InsuranceKnowledgeBase.filter({
            visibleToAI: true,
            is_active: true
        }, '-created_date', limit);

        if (!items || items.length === 0) {
            console.log("⚠️ No active knowledge base entries found");
            return `\n=== COVORIA KNOWLEDGE BASE (v${currentVersion}) ===\nNo expert knowledge available. Please upload knowledge documents.\n=== END KNOWLEDGE BASE ===\n`;
        }

        console.log(`📊 Loaded ${items.length} knowledge entries for assistant`);

        // Task 7: Score entries by relevance to user profile
        const relevantItems = items.filter(item => {
            if (!userContext.age) return true; // Include all if no age context

            const age = userContext.age;
            if (age < 30 && (item.targetPersona === 'beginner' || item.targetPersona === 'young_professional')) return true;
            if (age > 55 && (item.targetPersona === 'advanced' || item.targetPersona === 'senior')) return true;
            if (item.targetPersona === 'general') return true;

            return false;
        });

        // Prioritize by insight type (tips and traps are most actionable)
        const prioritizedItems = relevantItems.sort((a, b) => {
            const typeOrder = { tip: 0, trap: 1, gap_detection: 2, optimization: 3, definition: 4 };
            const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };

            const typeA = typeOrder[a.insightType] || 99;
            const typeB = typeOrder[b.insightType] || 99;
            const priorityA = priorityOrder[a.priority] || 99;
            const priorityB = priorityOrder[b.priority] || 99;

            return (typeA - typeB) || (priorityA - priorityB);
        });

        const snapshot = prioritizedItems.map((item, index) => {
            const sourceInfo = item.sourceFile && item.sourceFile !== 'Manual Entry'
                ? `Source: ${item.sourceFile} (v${item.version || 1})`
                : 'Source: Manual Entry';

            return `
[KNOWLEDGE ENTRY ${index + 1}]
ID: ${item.id}
${sourceInfo}
Topic: ${item.sectionTitle}
Category: ${item.insuranceType} | Type: ${item.insightType} | Target: ${item.targetPersona}
Content: ${item.content}
Tags: ${item.tags ? item.tags.join(', ') : 'none'}
Uploaded: ${item.parsedOn ? new Date(item.parsedOn).toLocaleDateString() : 'N/A'}
---`;
        }).join('\n');

        const header = `\n=== COVORIA EXPERT KNOWLEDGE BASE (v${currentVersion}) ===\n` +
                      `Loaded ${prioritizedItems.length} relevant entries from ${items.length} total entries.\n` +
                      `Knowledge Sources: ${[...new Set(items.map(i => i.sourceFile))].join(', ')}\n` +
                      `Last Updated: ${new Date().toLocaleDateString()}\n\n`;

        return header + snapshot + '\n=== END KNOWLEDGE BASE ===\n';

    } catch (error) {
        console.error("❌ Failed to fetch knowledge base snapshot:", error);
        return "⚠️ Could not retrieve expert knowledge base. System may be experiencing issues.";
    }
}

// Task 26: Enhanced assistant with better reasoning and knowledge integration
export async function learnAndAdviseUser(userInput, userEmail = null, sessionContext = {}, userProfileContext = "", userAge = null) {
  try {
    const knowledge = getKnowledgeCore(); // This now returns a safe object
    const knowledgeSnapshot = await getKnowledgeBaseSnapshot(20, { age: userAge });
    const currentVersion = localStorage.getItem('covoria_kb_version') || '1.0.0';

    console.log(`🤖 Assistant advising using KB v${currentVersion}. KB Snapshot length: ${knowledgeSnapshot.length}`);

    const prompt = `
You are Covoria, an expert insurance advisor with access to professional knowledge base (version ${currentVersion}).

CORE PRINCIPLES:
1. Always explain WHY you're making each recommendation - cite underlying principles
2. Reference specific knowledge sources when available (mention source file and version)
3. Make complex concepts simple but thorough
4. Show genuine care for the user's financial security
5. Distinguish between file-based insights (educational) and policy-based insights (personal)

USER QUESTION: "${userInput}"

USER PROFILE & DATA:
${userProfileContext}

YOUR EXPERT KNOWLEDGE BASE:
${knowledgeSnapshot}

RESPONSE REQUIREMENTS:
- Start with a direct answer to their question
- Explain reasoning using this format: "I recommend this because [principle/reason]. According to [source], [supporting evidence]."
- When citing knowledge base, use: "Based on our expert knowledge from [Source Name], [specific guidance]"
- Include 2-3 specific action steps they can take
- Use warm, confidence-building language
- If uncertain about specifics, acknowledge limitations and suggest professional consultation
- Differentiate between general advice (from knowledge files) and personal recommendations (based on their policies)

SESSION CONTEXT: ${JSON.stringify(sessionContext)}
BEHAVIORAL PATTERNS: ${JSON.stringify(knowledge.behavior)}

Remember: Your goal is to make them feel informed, confident, and financially secure while providing accurate, traceable advice.
`;

    const response = await InvokeLLM({ prompt });

    // This line will no longer cause an error.
    knowledge.pastSprints.push({
      sprint: 22,
      topic: 'assistant_kb_connection_fix',
      userQuery: userInput.substring(0, 100),
      knowledgeVersion: currentVersion,
      success: true,
      timestamp: new Date().toISOString()
    });

    // Update knowledge core
    knowledge.lastUpdated = new Date().toISOString();
    knowledge.knowledgeBaseVersion = currentVersion;
    updateKnowledgeCore(knowledge);

    console.log(`✅ Assistant response generated using KB v${currentVersion}`);

    return response || "I understand your question, but I need more context to provide the best advice. Could you share more details about your situation?";

  } catch (error) {
    console.error("❌ Enhanced assistant failed:", error);

    // Fallback response with helpful guidance
    const fallbackResponse = `I'm experiencing some technical difficulties accessing my knowledge base right now.

However, I can still help you with general guidance:
- For specific policy questions, I'd recommend checking your policy documents or contacting your agent
- For general insurance education, consider speaking with a licensed professional
- If this is urgent, most insurance companies have 24/7 customer service lines

Please try asking your question again in a moment, or let me know if you'd like me to help in a different way.`;

    return fallbackResponse;
  }
}

//////////////////////////////////////////////////////////////////
// 3. ENHANCED COVERAGE ANALYSIS WITH VERSION TRACKING
//////////////////////////////////////////////////////////////////

// Enhanced analyzer with knowledge base integration and version awareness
export async function analyzeUserCoverage(userProfile, policies) {
  try {
    const currentVersion = localStorage.getItem('covoria_kb_version') || '1.0.0';
    const allKnowledge = await InsuranceKnowledgeBase.filter({
      visibleToAI: true,
      is_active: true
    });

    console.log(`🔍 Coverage analysis using ${allKnowledge.length} knowledge entries (v${currentVersion})`);

    if (allKnowledge.length === 0) {
      console.log("⚠️ No knowledge base available for coverage analysis");
      return [];
    }

    const insights = [];
    const userPolicyTypes = new Set(policies.map(p => p.insurance_type));

    // Enhanced gap detection with knowledge base
    const commonCoverages = ['health', 'auto', 'life', 'home', 'disability'];

    for (const coverage of commonCoverages) {
      if (!userPolicyTypes.has(coverage)) {
        const relatedKnowledge = allKnowledge.find(item =>
          item.insuranceType === coverage && item.insightType === 'gap_detection'
        );

        const sourceAttribution = relatedKnowledge
          ? `Based on expert knowledge from ${relatedKnowledge.sourceFile}`
          : 'Based on industry best practices';

        insights.push({
          title: `Coverage Gap: Missing ${coverage.charAt(0).toUpperCase() + coverage.slice(1)} Insurance`,
          description: relatedKnowledge ? relatedKnowledge.content :
            `Having ${coverage} insurance is crucial for financial protection. We couldn't find an active policy of this type in your portfolio.`,
          category: 'coverage_gap',
          priority: (coverage === 'health' || coverage === 'disability') ? 'critical' : 'high',
          reasoning: `${sourceAttribution}. This is a standard recommended coverage for your profile and life situation.`,
          action_required: `Consider getting quotes for ${coverage} insurance to protect yourself and your family.`,
          financial_impact_level: (coverage === 'health' || coverage === 'disability') ? 'very_high' : 'high',
          insight_suggestion_origin: 'ai_generated',
          triggeredBy: 'KnowledgeFile', // Mark as knowledge-based
          is_resolved: false,
          knowledgeBaseVersion: currentVersion
        });
      }
    }

    // Policy-specific insights based on knowledge base
    for (const policy of policies) {
      const policyTraps = allKnowledge.filter(item =>
        item.insuranceType === policy.insurance_type && item.insightType === 'trap'
      );

      for (const trap of policyTraps.slice(0, 2)) { // Limit to avoid overwhelm
        insights.push({
          title: `Policy Review: ${trap.sectionTitle}`,
          description: trap.content,
          category: 'risk_alert',
          priority: 'medium',
          reasoning: `This common issue was identified in our expert knowledge base from ${trap.sourceFile}. It's worth reviewing your ${policy.insurance_type} policy for this potential concern.`,
          action_required: `Review your ${policy.insurance_type} policy documents or contact your provider to verify this doesn't apply to your coverage.`,
          financial_impact_level: 'medium',
          related_policies: [policy.id],
          insight_suggestion_origin: 'ai_generated',
          triggeredBy: 'UserPolicy', // Mark as policy-based
          is_resolved: false,
          knowledgeBaseVersion: currentVersion
        });
      }
    }

    // Sort by priority and limit results
    const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    insights.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);

    console.log(`✅ Generated ${insights.length} coverage insights using KB v${currentVersion}`);
    return insights.slice(0, 6); // Return top 6 insights

  } catch (error) {
    console.error("❌ Coverage analysis failed:", error);
    return [];
  }
}

//////////////////////////////////////////////////////////////////
// 4. EXISTING UTILITY FUNCTIONS (Enhanced)
//////////////////////////////////////////////////////////////////

export function getKnowledgeCore() {
  const data = localStorage.getItem("covoria_knowledge_core");
  const knowledge = data ? JSON.parse(data) : { ...initialKnowledge };

  // CRITICAL FIX: Ensure pastSprints is always an array to prevent .push() errors.
  if (!Array.isArray(knowledge.pastSprints)) {
    console.warn("`pastSprints` was not an array. Resetting from initial knowledge.");
    // Safely reset to a copy of the initial state or an empty array
    knowledge.pastSprints = initialKnowledge.pastSprints ? [...initialKnowledge.pastSprints] : [];
  }

  // Ensure version tracking
  if (!knowledge.knowledgeBaseVersion) {
    knowledge.knowledgeBaseVersion = localStorage.getItem('covoria_kb_version') || '1.0.0';
  }

  return knowledge;
}

export function getUserPatterns(userEmail) {
  const knowledge = getKnowledgeCore();
  return knowledge.userPatterns[userEmail] || null;
}

export function getRecentInsights(limit = 10) {
  const knowledge = getKnowledgeCore();
  return knowledge.aiInsights.slice(-limit);
}

export function getConversationHistory(userEmail = null, limit = 10) {
  const knowledge = getKnowledgeCore();
  let history = knowledge.qaHistory.slice(-limit);

  if (userEmail) {
    history = history.filter(qa => qa.userEmail === userEmail);
  }

  return history;
}

export function updateKnowledgeCore(knowledge) {
  knowledge.lastUpdated = new Date().toISOString();
  localStorage.setItem("covoria_knowledge_core", JSON.stringify(knowledge));
}

export function resetKnowledgeCore() {
  localStorage.setItem("covoria_knowledge_core", JSON.stringify(initialKnowledge));
  localStorage.setItem("covoria_kb_version", "1.0.0");
  console.log("🧠 Covoria AI Knowledge Core reset to defaults");
}

export function exportKnowledgeCore() {
  const knowledge = getKnowledgeCore();
  const blob = new Blob([JSON.stringify(knowledge, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `covoria-knowledge-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function getKnowledgeStats() {
  const knowledge = getKnowledgeCore();
  const currentVersion = localStorage.getItem('covoria_kb_version') || '1.0.0';

  return {
    totalInteractions: knowledge.qaHistory.length,
    uniqueUsers: Object.keys(knowledge.userPatterns).length,
    aiInsights: knowledge.aiInsights.length,
    lastUpdated: knowledge.lastUpdated,
    currentVersion: currentVersion,
    topTopics: getTopTopics(),
    systemHealth: knowledge.qaHistory.length > 0 ? knowledge.qaHistory.filter(qa => !qa.error).length / knowledge.qaHistory.length : 1
  };
}

function getTopTopics() {
  const knowledge = getKnowledgeCore();
  const topics = {};

  knowledge.qaHistory.forEach(qa => {
    if (qa.topic) {
      topics[qa.topic] = (topics[qa.topic] || 0) + 1;
    }
  });

  return Object.entries(topics)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 5)
    .map(([topic, count]) => ({ topic, count }));
}


// Initialize on module load
initializeKnowledgeCore();

console.log("🧠 Covoria Learning System loaded with enhanced knowledge base integration");
