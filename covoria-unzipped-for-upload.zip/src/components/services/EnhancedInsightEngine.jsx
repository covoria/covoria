// Enhanced Insight Engine that leverages Master Advisor for knowledge-based insights
import { masterAdvisor } from './MasterAdvisorEngine';
import { InsuranceKnowledgeBase } from '@/api/entities';
import { Insight } from '@/api/entities';
import { User } from '@/api/entities';

export async function generateKnowledgeBasedInsights(userEmail, userProfile = {}) {
  console.log("🔍 Generating knowledge-based insights for user:", userEmail);
  
  try {
    const user = await User.me();
    const existingInsights = await Insight.filter({ created_by: userEmail });
    const existingTitles = new Set(existingInsights.map(i => i.title));
    
    // Get general tips and important concepts from knowledge base
    const generalKnowledge = await InsuranceKnowledgeBase.filter({
      is_active: true,
      visibleToAI: true,
      insuranceType: 'general'
    }, '-created_date', 10);

    const tipKnowledge = await InsuranceKnowledgeBase.filter({
      is_active: true,
      visibleToAI: true,
      insightType: 'tip'
    }, '-created_date', 5);

    const allKnowledge = [...generalKnowledge, ...tipKnowledge];
    
    if (allKnowledge.length === 0) {
      console.log("⚠️ No knowledge base entries found for insight generation");
      return [];
    }

    const newInsights = [];
    
    // Convert knowledge entries to insights
    for (const knowledge of allKnowledge.slice(0, 6)) {
      const insightTitle = `${knowledge.sectionTitle}`;
      
      if (!existingTitles.has(insightTitle)) {
        const insight = {
          title: insightTitle,
          description: knowledge.content,
          category: knowledge.insightType === 'tip' ? 'optimization' : 'coverage_gap',
          priority: 'medium',
          action_required: `Review this advice: ${knowledge.content}`,
          reasoning: `This insight comes from our expert knowledge base. Source: ${knowledge.sourceFile || 'Expert Knowledge'}`,
          insight_suggestion_origin: 'knowledge_base',
          is_resolved: false,
          date_identified: new Date().toISOString().split('T')[0],
          created_by: userEmail,
          related_knowledge_id: knowledge.id
        };
        
        newInsights.push(insight);
        existingTitles.add(insightTitle);
      }
    }

    // Create the insights in the database
    if (newInsights.length > 0) {
      await Insight.bulkCreate(newInsights);
      console.log(`✅ Created ${newInsights.length} knowledge-based insights`);
    }

    return newInsights;

  } catch (error) {
    console.error("❌ Failed to generate knowledge-based insights:", error);
    return [];
  }
}

// Function to refresh insights based on knowledge base updates
export async function refreshInsightsFromKnowledge() {
  try {
    const users = await User.list();
    let totalGenerated = 0;
    
    for (const user of users.slice(0, 10)) { // Limit to prevent overload
      const insights = await generateKnowledgeBasedInsights(user.email, user);
      totalGenerated += insights.length;
    }
    
    console.log(`🔄 Refreshed insights for users. Total generated: ${totalGenerated}`);
    return totalGenerated;
    
  } catch (error) {
    console.error("❌ Failed to refresh insights from knowledge:", error);
    return 0;
  }
}