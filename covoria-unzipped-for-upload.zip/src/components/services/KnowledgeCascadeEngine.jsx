// SPRINT 22: Knowledge Cascade Layer
// Advanced AI Reasoning Engine with 1000+ Expert Insights Integration

import { InsuranceKnowledgeBase } from '@/api/entities';
import { Insight } from '@/api/entities';
import { InsurancePolicy } from '@/api/entities';
import { User } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';

//////////////////////////////////////////////////////////////////
// KNOWLEDGE CASCADE ORCHESTRATOR
//////////////////////////////////////////////////////////////////

export class KnowledgeCascadeEngine {
  constructor() {
    this.knowledgeCache = new Map();
    this.lastCacheUpdate = null;
    this.cacheValidityPeriod = 15 * 60 * 1000; // 15 minutes
  }

  async loadKnowledgeBase(forceRefresh = false) {
    const now = Date.now();
    
    if (!forceRefresh && this.lastCacheUpdate && 
        (now - this.lastCacheUpdate) < this.cacheValidityPeriod && 
        this.knowledgeCache.size > 0) {
      return Array.from(this.knowledgeCache.values());
    }

    console.log("🔄 Loading full knowledge cascade...");
    
    try {
      const allInsights = await InsuranceKnowledgeBase.filter({
        is_active: true,
        visibleToAI: true
      }, '-created_date');

      // Build searchable cache
      this.knowledgeCache.clear();
      allInsights.forEach(insight => {
        this.knowledgeCache.set(insight.id, {
          ...insight,
          searchableText: this.buildSearchableText(insight),
          tagSet: new Set((insight.tags || []).map(t => t.toLowerCase()))
        });
      });

      this.lastCacheUpdate = now;
      console.log(`✅ Knowledge cascade loaded: ${this.knowledgeCache.size} insights`);
      
      return Array.from(this.knowledgeCache.values());
    } catch (error) {
      console.error("❌ Failed to load knowledge cascade:", error);
      return [];
    }
  }

  buildSearchableText(insight) {
    return [
      insight.sectionTitle || '',
      insight.content || '',
      insight.insuranceType || '',
      insight.insightType || '',
      ...(insight.tags || []),
      insight.targetPersona || ''
    ].join(' ').toLowerCase();
  }

  // ADVANCED SEARCH ENGINE
  async findRelevantInsights(query, filters = {}) {
    const knowledge = await this.loadKnowledgeBase();
    if (knowledge.length === 0) return [];

    const {
      insuranceType,
      insightType,
      tags,
      minRiskScore,
      minConfidenceScore,
      targetPersona,
      maxResults = 10
    } = filters;

    const queryLower = query.toLowerCase();
    const queryWords = queryLower.split(/\s+/).filter(w => w.length > 2);
    
    const scoredInsights = knowledge.map(insight => {
      let score = 0;
      
      // Exact match bonuses
      if (insight.searchableText.includes(queryLower)) score += 20;
      
      // Word matching
      queryWords.forEach(word => {
        if (insight.sectionTitle?.toLowerCase().includes(word)) score += 10;
        if (insight.content?.toLowerCase().includes(word)) score += 5;
        if (insight.tagSet.has(word)) score += 8;
        if (insight.insuranceType?.toLowerCase().includes(word)) score += 6;
      });

      // Filter matches
      if (insuranceType && insight.insuranceType !== insuranceType) return null;
      if (insightType && insight.insightType !== insightType) return null;
      if (targetPersona && insight.targetPersona !== targetPersona) return null;
      if (minRiskScore && (insight.riskScore || 0) < minRiskScore) return null;
      if (minConfidenceScore && (insight.confidenceScore || 0) < minConfidenceScore) return null;
      
      if (tags && tags.length > 0) {
        const hasMatchingTag = tags.some(tag => insight.tagSet.has(tag.toLowerCase()));
        if (!hasMatchingTag) return null;
      }

      return { ...insight, relevanceScore: score };
    }).filter(Boolean);

    return scoredInsights
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, maxResults);
  }

  // POLICY DOCUMENT ANALYSIS ENGINE
  async analyzeUserPolicyGaps(userEmail) {
    console.log(`🔍 Analyzing policy gaps for user: ${userEmail}`);
    
    try {
      const policies = await InsurancePolicy.filter({ created_by: userEmail });
      const user = await User.get(userEmail);
      
      if (policies.length === 0) {
        return await this.getNewUserRecommendations(user);
      }

      const gapAnalysis = [];
      const policyTypes = new Set(policies.map(p => p.insurance_type));
      const age = user?.age || 30;
      const hasFamily = (user?.dependents || 0) > 0;

      // Check for missing essential coverage types
      const essentialTypes = ['health', 'auto', 'life'];
      if (hasFamily) essentialTypes.push('disability');
      if (age > 55) essentialTypes.push('disability');

      for (const type of essentialTypes) {
        if (!policyTypes.has(type)) {
          const gapInsights = await this.findRelevantInsights(`${type} insurance gap coverage essential`, {
            insuranceType: type,
            insightType: 'gap',
            maxResults: 2
          });
          
          gapAnalysis.push(...gapInsights.map(insight => ({
            ...insight,
            gapType: 'missing_coverage',
            severity: 'high',
            reasoning: `No ${type} insurance found in your policies`
          })));
        }
      }

      // Analyze existing policies for optimization
      for (const policy of policies) {
        const optimizationInsights = await this.findRelevantInsights(`${policy.insurance_type} optimization cost saving`, {
          insuranceType: policy.insurance_type,
          insightType: 'optimization',
          maxResults: 1
        });
        
        gapAnalysis.push(...optimizationInsights.map(insight => ({
          ...insight,
          gapType: 'optimization',
          severity: 'medium',
          reasoning: `Potential optimization for your ${policy.insurance_type} policy`
        })));
      }

      return gapAnalysis.slice(0, 6); // Limit results

    } catch (error) {
      console.error("❌ Policy gap analysis failed:", error);
      return [];
    }
  }

  async getNewUserRecommendations(user) {
    const age = user?.age || 30;
    const persona = this.determinePersona(user);
    
    const recommendations = await this.findRelevantInsights('essential coverage basics', {
      targetPersona: persona,
      insightType: 'tip',
      maxResults: 4
    });

    return recommendations.map(insight => ({
      ...insight,
      gapType: 'new_user_guidance',
      severity: 'medium',
      reasoning: 'Essential coverage for new users'
    }));
  }

  determinePersona(user) {
    const age = user?.age || 30;
    const dependents = user?.dependents || 0;
    const employment = user?.employment_status;

    if (age >= 65) return 'senior';
    if (dependents > 0) return 'family';
    if (employment === 'self_employed') return 'freelancer';
    if (age < 30) return 'young_professional';
    return 'general';
  }

  // FORECAST RISK ENGINE
  async generateFutureRiskInsights(userEmail) {
    console.log(`🔮 Generating future risk insights for: ${userEmail}`);
    
    try {
      const user = await User.get(userEmail);
      const policies = await InsurancePolicy.filter({ created_by: userEmail });
      
      const forecastInsights = [];
      const age = user?.age || 30;
      
      // Age-based future risks
      if (age >= 60 && age < 65) {
        const medicareInsights = await this.findRelevantInsights('medicare transition planning', {
          insightType: 'forecast',
          tags: ['medicare', 'retirement'],
          maxResults: 2
        });
        forecastInsights.push(...medicareInsights);
      }

      // Policy expiration risks
      const currentDate = new Date();
      const sixMonthsFromNow = new Date(currentDate.getTime() + (6 * 30 * 24 * 60 * 60 * 1000));
      
      for (const policy of policies) {
        if (policy.end_date && new Date(policy.end_date) <= sixMonthsFromNow) {
          const renewalInsights = await this.findRelevantInsights(`${policy.insurance_type} renewal preparation`, {
            insuranceType: policy.insurance_type,
            insightType: 'forecast',
            maxResults: 1
          });
          forecastInsights.push(...renewalInsights);
        }
      }

      return forecastInsights.slice(0, 4);

    } catch (error) {
      console.error("❌ Future risk analysis failed:", error);
      return [];
    }
  }

  // SMART RECOMMENDATION GENERATOR
  async generateSmartRecommendations(userEmail) {
    const [gapAnalysis, futureRisks] = await Promise.all([
      this.analyzeUserPolicyGaps(userEmail),
      this.generateFutureRiskInsights(userEmail)
    ]);

    const recommendations = [];

    // Priority 1: Critical gaps
    const criticalGaps = gapAnalysis.filter(g => g.severity === 'high');
    recommendations.push(...criticalGaps.slice(0, 2));

    // Priority 2: Future risks
    recommendations.push(...futureRisks.slice(0, 1));

    // Priority 3: Optimizations
    const optimizations = gapAnalysis.filter(g => g.gapType === 'optimization');
    recommendations.push(...optimizations.slice(0, 1));

    return recommendations.map(rec => ({
      title: rec.sectionTitle,
      description: rec.content,
      category: rec.gapType,
      priority: rec.severity === 'high' ? 'critical' : rec.severity === 'medium' ? 'high' : 'medium',
      reasoning: rec.reasoning,
      source: 'Knowledge Cascade Engine',
      insightId: rec.id,
      actionRequired: `Review and consider: ${rec.content}`,
      insight_suggestion_origin: 'knowledge_cascade'
    }));
  }
}

// Initialize global instance
export const knowledgeCascade = new KnowledgeCascadeEngine();

console.log("🌊 Knowledge Cascade Engine initialized");