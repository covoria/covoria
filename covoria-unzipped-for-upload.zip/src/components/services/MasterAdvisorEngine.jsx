// MASTER ADVISOR ENABLEMENT - Insurance Intelligence AI Layer v1.0
// Complete AI Advisor Engine with Intent Classification and Response Blueprints

import { InvokeLLM } from '@/api/integrations';
import { InsuranceKnowledgeBase } from '@/api/entities';

//////////////////////////////////////////////////////////////////
// A. KNOWLEDGE BASE ACTIVATION LAYER
//////////////////////////////////////////////////////////////////

class KnowledgeBaseConnector {
  constructor() {
    this.lastRefresh = null;
    this.cachedKnowledge = null;
    this.refreshInterval = 30 * 60 * 1000; // 30 minutes
  }

  async getKnowledgeEntries(refresh = false) {
    const now = Date.now();
    
    // Auto-refresh every 30 minutes
    if (!this.cachedKnowledge || !this.lastRefresh || 
        (now - this.lastRefresh > this.refreshInterval) || refresh) {
      
      console.log("🔄 Refreshing Knowledge Base cache...");
      try {
        const entries = await InsuranceKnowledgeBase.filter({
          is_active: true,
          visibleToAI: true
        }, '-created_date');
        
        this.cachedKnowledge = entries || [];
        this.lastRefresh = now;
        console.log(`✅ Knowledge Base loaded: ${this.cachedKnowledge.length} entries`);
      } catch (error) {
        console.error("❌ Failed to load Knowledge Base:", error);
        this.cachedKnowledge = [];
      }
    }
    
    return this.cachedKnowledge;
  }

  // Dual Match: Semantic + Keyword Search
  async findRelevantKnowledge(query, insuranceType = null, maxResults = 3) {
    const entries = await this.getKnowledgeEntries();
    if (!entries || entries.length === 0) return [];

    const lowerQuery = query.toLowerCase();
    const queryWords = lowerQuery.split(/\s+/).filter(w => w.length > 2);
    
    const scoredEntries = entries.map(entry => {
      let score = 0;
      
      // Insurance type match bonus
      if (insuranceType && entry.insuranceType === insuranceType) {
        score += 10;
      }
      
      // Title match (high weight)
      queryWords.forEach(word => {
        if (entry.sectionTitle?.toLowerCase().includes(word)) {
          score += 5;
        }
        if (entry.content?.toLowerCase().includes(word)) {
          score += 2;
        }
        if (entry.tags?.some(tag => tag.toLowerCase().includes(word))) {
          score += 3;
        }
      });
      
      // Exact phrase match (bonus)
      if (entry.content?.toLowerCase().includes(lowerQuery) || 
          entry.sectionTitle?.toLowerCase().includes(lowerQuery)) {
        score += 15;
      }
      
      return { ...entry, relevanceScore: score };
    });

    return scoredEntries
      .filter(entry => entry.relevanceScore > 0)
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, maxResults);
  }
}

//////////////////////////////////////////////////////////////////
// B. INTENT CLASSIFICATION ENGINE
//////////////////////////////////////////////////////////////////

class IntentClassifier {
  static patterns = {
    DIRECT_TIP: {
      keywords: ['tip', 'advice', 'suggest', 'recommend'],
      phrases: ['give me', 'what should', 'any tips']
    },
    TERM_DEFINITION: {
      keywords: ['what is', 'what does', 'define', 'meaning', 'means'],
      phrases: ['what is', 'what does', 'define']
    },
    SCENARIO: {
      keywords: ['i am', 'im', 'my situation', 'need', 'should i'],
      phrases: ['i am', 'i live', 'my family', 'i have']
    },
    COMPARISON: {
      keywords: ['vs', 'versus', 'compare', 'difference', 'better', 'which'],
      phrases: ['which is better', 'difference between', 'compare']
    },
    COVERAGE_GAPS: {
      keywords: ['need', 'required', 'must have', 'essential', 'gap'],
      phrases: ['do i need', 'should i get', 'is required']
    },
    TAX_TIP: {
      keywords: ['tax', 'deduct', 'deduction', 'save money', 'irs'],
      phrases: ['tax deduct', 'save on taxes', 'tax benefit']
    },
    CHILDREN_COVERAGE: {
      keywords: ['child', 'son', 'daughter', 'kid', 'family', 'dependent'],
      phrases: ['my child', 'my son', 'my daughter', 'family coverage']
    },
    RED_FLAG: {
      keywords: ['not covered', 'exclusion', 'avoid', 'watch out', 'trap'],
      phrases: ['not covered', 'what to avoid', 'red flags']
    },
    COST_OPTIMIZATION: {
      keywords: ['save', 'cheaper', 'reduce', 'lower', 'cost', 'expensive'],
      phrases: ['save money', 'pay less', 'reduce cost']
    },
    DEADLINE_INFO: {
      keywords: ['when', 'deadline', 'enroll', 'signup', 'open enrollment'],
      phrases: ['when can i', 'deadline for', 'enrollment period']
    },
    AGING: {
      keywords: ['65', 'retire', 'senior', 'medicare', 'old'],
      phrases: ['turning 65', 'about to retire', 'senior citizen']
    }
  };

  static classifyIntent(query) {
    const lowerQuery = query.toLowerCase();
    let bestMatch = { intent: 'UNSTRUCTURED', confidence: 0 };

    for (const [intent, pattern] of Object.entries(this.patterns)) {
      let confidence = 0;

      // Check keywords
      pattern.keywords.forEach(keyword => {
        if (lowerQuery.includes(keyword)) {
          confidence += 1;
        }
      });

      // Check phrases (higher weight)
      pattern.phrases.forEach(phrase => {
        if (lowerQuery.includes(phrase)) {
          confidence += 3;
        }
      });

      if (confidence > bestMatch.confidence) {
        bestMatch = { intent, confidence };
      }
    }

    return bestMatch;
  }
}

//////////////////////////////////////////////////////////////////
// C. RESPONSE BLUEPRINT ENGINE
//////////////////////////////////////////////////////////////////

class ResponseBlueprints {
  constructor(knowledgeConnector) {
    this.kb = knowledgeConnector;
  }

  async handleDirectTip(query, userContext = {}) {
    const knowledge = await this.kb.findRelevantKnowledge(query, 'general', 2);
    if (knowledge.length === 0) {
      return this.getFallbackTip();
    }

    const tips = knowledge.filter(k => k.insightType === 'tip' || k.sectionTitle.toLowerCase().includes('tip'));
    const selectedTip = tips[0] || knowledge[0];

    return {
      response: `💡 **Tip:** ${selectedTip.content}`,
      source: selectedTip.sectionTitle,
      confidence: 0.9
    };
  }

  async handleTermDefinition(query, userContext = {}) {
    const knowledge = await this.kb.findRelevantKnowledge(query, null, 1);
    if (knowledge.length === 0) {
      return { response: "I don't have a definition for that term in my current knowledge base. Could you provide more context?", confidence: 0.3 };
    }

    const definition = knowledge[0];
    const prompt = `Explain this insurance term in simple, plain English: "${definition.content}". Make it easy to understand for someone new to insurance.`;
    
    try {
      const explanation = await InvokeLLM({ prompt });
      return {
        response: `📚 **${definition.sectionTitle}**\n\n${explanation}\n\n*Source: ${definition.sourceFile || 'Knowledge Base'}*`,
        source: definition.sectionTitle,
        confidence: 0.95
      };
    } catch (error) {
      return {
        response: `📚 **${definition.sectionTitle}**\n\n${definition.content}\n\n*Source: ${definition.sourceFile || 'Knowledge Base'}*`,
        source: definition.sectionTitle,
        confidence: 0.8
      };
    }
  }

  async handleScenario(query, userContext = {}) {
    const age = this.extractAge(query);
    const situation = this.extractSituation(query);
    
    let insuranceType = 'general';
    if (query.includes('health')) insuranceType = 'health';
    if (query.includes('auto') || query.includes('car')) insuranceType = 'auto';
    if (query.includes('home') || query.includes('house')) insuranceType = 'home';
    if (query.includes('life')) insuranceType = 'life';

    const knowledge = await this.kb.findRelevantKnowledge(query, insuranceType, 3);
    
    if (knowledge.length === 0) {
      return { response: "I'd need more specific information about your situation to provide personalized advice. Could you tell me more details?", confidence: 0.4 };
    }

    const recommendations = knowledge.map(k => `• ${k.content}`).join('\n');
    const sources = [...new Set(knowledge.map(k => k.sectionTitle))].join(', ');

    let contextualAdvice = '';
    if (age >= 65) {
      contextualAdvice = '\n\n🎯 **Since you mentioned being 65+:** Medicare eligibility may affect your options.';
    } else if (age < 30) {
      contextualAdvice = '\n\n🎯 **For your age group:** Focus on essential coverage at affordable rates.';
    }

    return {
      response: `Based on your situation, here's what you should consider:\n\n${recommendations}${contextualAdvice}\n\n*Sources: ${sources}*`,
      source: sources,
      confidence: 0.85
    };
  }

  async handleComparison(query, userContext = {}) {
    const knowledge = await this.kb.findRelevantKnowledge(query, null, 4);
    if (knowledge.length < 2) {
      return { response: "I need more information in my knowledge base to make this comparison. Could you be more specific about what you're comparing?", confidence: 0.3 };
    }

    const comparisonPrompt = `Compare these insurance concepts based on the following information: ${knowledge.map(k => `${k.sectionTitle}: ${k.content}`).join('\n\n')}. Provide a clear pros and cons comparison.`;
    
    try {
      const comparison = await InvokeLLM({ prompt: comparisonPrompt });
      const sources = knowledge.map(k => k.sectionTitle).join(', ');
      
      return {
        response: `⚖️ **Comparison:**\n\n${comparison}\n\n*Sources: ${sources}*`,
        source: sources,
        confidence: 0.9
      };
    } catch (error) {
      const simple = knowledge.map(k => `**${k.sectionTitle}:** ${k.content}`).join('\n\n');
      return {
        response: `⚖️ **Here's what I know about each:**\n\n${simple}`,
        source: knowledge.map(k => k.sectionTitle).join(', '),
        confidence: 0.7
      };
    }
  }

  async handleCoverageGaps(query, userContext = {}) {
    const knowledge = await this.kb.findRelevantKnowledge(query + ' coverage gap essential required', null, 3);
    
    if (knowledge.length === 0) {
      return this.getGeneralCoverageAdvice();
    }

    const gaps = knowledge.filter(k => 
      k.insightType === 'gap_detection' || 
      k.content.toLowerCase().includes('need') ||
      k.content.toLowerCase().includes('require')
    );

    const advice = gaps.length > 0 ? gaps : knowledge;
    const recommendations = advice.map(k => `• ${k.content}`).join('\n');
    const sources = advice.map(k => k.sectionTitle).join(', ');

    return {
      response: `🛡️ **Coverage Analysis:**\n\n${recommendations}\n\n*Sources: ${sources}*`,
      source: sources,
      confidence: 0.8
    };
  }

  // Helper methods
  extractAge(query) {
    const ageMatch = query.match(/(\d{2})/);
    return ageMatch ? parseInt(ageMatch[1]) : null;
  }

  extractSituation(query) {
    const situations = {
      'alone': 'single',
      'married': 'married',
      'family': 'family',
      'children': 'family',
      'retire': 'retirement',
      'work': 'employed'
    };

    for (const [keyword, situation] of Object.entries(situations)) {
      if (query.toLowerCase().includes(keyword)) {
        return situation;
      }
    }
    return null;
  }

  getFallbackTip() {
    return {
      response: "💡 **General Tip:** Always read your policy documents carefully and understand your deductibles, copays, and coverage limits. Don't hesitate to ask your insurance provider to explain anything unclear.",
      source: "General Advice",
      confidence: 0.6
    };
  }

  getGeneralCoverageAdvice() {
    return {
      response: "🛡️ **Essential Coverage:** Most people need health, auto (if driving), and renters/homeowners insurance as a foundation. Life insurance becomes important if you have dependents. The specifics depend on your personal situation.",
      source: "General Guidelines",
      confidence: 0.6
    };
  }
}

//////////////////////////////////////////////////////////////////
// D. MASTER ADVISOR ORCHESTRATOR
//////////////////////////////////////////////////////////////////

export class MasterAdvisorEngine {
  constructor() {
    this.knowledgeConnector = new KnowledgeBaseConnector();
    this.responseBlueprints = new ResponseBlueprints(this.knowledgeConnector);
    this.requestCount = 0;
  }

  async processQuery(userQuery, userContext = {}) {
    this.requestCount++;
    console.log(`🤖 Master Advisor Query #${this.requestCount}: "${userQuery}"`);
    
    try {
      // Step 1: Classify Intent
      const intentResult = IntentClassifier.classifyIntent(userQuery);
      console.log(`🎯 Intent Classified: ${intentResult.intent} (confidence: ${intentResult.confidence})`);

      // Step 2: Route to appropriate blueprint
      let response;
      switch (intentResult.intent) {
        case 'DIRECT_TIP':
          response = await this.responseBlueprints.handleDirectTip(userQuery, userContext);
          break;
        case 'TERM_DEFINITION':
          response = await this.responseBlueprints.handleTermDefinition(userQuery, userContext);
          break;
        case 'SCENARIO':
          response = await this.responseBlueprints.handleScenario(userQuery, userContext);
          break;
        case 'COMPARISON':
          response = await this.responseBlueprints.handleComparison(userQuery, userContext);
          break;
        case 'COVERAGE_GAPS':
          response = await this.responseBlueprints.handleCoverageGaps(userQuery, userContext);
          break;
        default:
          response = await this.handleUnstructured(userQuery, userContext);
      }

      // Step 3: Add metadata and return
      return {
        ...response,
        intent: intentResult.intent,
        queryId: `advisor_${this.requestCount}`,
        timestamp: new Date().toISOString(),
        knowledgeBaseUsed: true
      };

    } catch (error) {
      console.error("❌ Master Advisor Error:", error);
      return this.getErrorFallback(userQuery);
    }
  }

  async handleUnstructured(query, userContext) {
    // For unstructured queries, try to find relevant knowledge and let LLM synthesize
    const knowledge = await this.knowledgeConnector.findRelevantKnowledge(query, null, 2);
    
    if (knowledge.length === 0) {
      return {
        response: "I don't have specific information about that topic in my current knowledge base. This might be a good question for a licensed insurance agent who can provide personalized advice based on your specific situation.",
        source: "Fallback Response",
        confidence: 0.4
      };
    }

    const contextInfo = knowledge.map(k => `${k.sectionTitle}: ${k.content}`).join('\n\n');
    const prompt = `Answer this insurance question using the provided context: "${query}"\n\nContext:\n${contextInfo}\n\nProvide a helpful, accurate response.`;
    
    try {
      const aiResponse = await InvokeLLM({ prompt });
      const sources = knowledge.map(k => k.sectionTitle).join(', ');
      
      return {
        response: `${aiResponse}\n\n*Sources: ${sources}*`,
        source: sources,
        confidence: 0.75
      };
    } catch (error) {
      return {
        response: contextInfo,
        source: knowledge.map(k => k.sectionTitle).join(', '),
        confidence: 0.6
      };
    }
  }

  getErrorFallback(query) {
    return {
      response: "I'm having trouble accessing my knowledge base right now, but here's what I can suggest: For insurance questions, it's always best to review your policy documents and contact your provider directly for clarification. If you're shopping for new coverage, compare quotes from multiple providers and read the fine print carefully.",
      source: "Error Fallback",
      confidence: 0.3,
      intent: 'ERROR_MODE',
      queryId: `error_${this.requestCount}`,
      timestamp: new Date().toISOString(),
      knowledgeBaseUsed: false
    };
  }

  // Health check method
  async getSystemStatus() {
    const knowledge = await this.knowledgeConnector.getKnowledgeEntries();
    return {
      knowledgeBaseEntries: knowledge.length,
      lastRefresh: this.knowledgeConnector.lastRefresh,
      requestsProcessed: this.requestCount,
      status: knowledge.length > 0 ? 'operational' : 'degraded'
    };
  }
}

// Initialize global instance
export const masterAdvisor = new MasterAdvisorEngine();

console.log("🚀 Master Advisor Engine v1.0 initialized");