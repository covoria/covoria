import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { 
  Monitor, 
  Activity, 
  Database, 
  Zap, 
  Brain,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  XCircle
} from 'lucide-react';
import SystemHealthWidget from '../dashboard/SystemHealthWidget';
import { systemTelemetry } from '@/api/functions';

export default function SystemMonitoringCard() {
  const [metrics, setMetrics] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchMetrics();
  }, []);

  const fetchMetrics = async () => {
    setIsLoading(true);
    try {
      const response = await systemTelemetry();
      if (response.data?.success) {
        setMetrics(response.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch system metrics:', error);
    }
    setIsLoading(false);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
    >
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Monitor className="w-6 h-6 text-green-600" />
            System Monitoring
          </CardTitle>
          <p className="text-gray-600">Real-time system health and performance metrics</p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* System Health Widget */}
          <SystemHealthWidget />
          
          {/* Additional Metrics */}
          {metrics && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Database className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium">Database</span>
                </div>
                <div className="text-xl font-bold text-blue-900">
                  {(metrics.database_metrics.total_policies || 0) + 
                   (metrics.database_metrics.total_accounts || 0)} 
                </div>
                <div className="text-xs text-blue-600">Total Records</div>
              </div>
              
              <div className="p-4 bg-green-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-medium">Processing</span>
                </div>
                <div className="text-xl font-bold text-green-900">
                  {metrics.processing_metrics.success_rate?.toFixed(1) || 0}%
                </div>
                <div className="text-xs text-green-600">Success Rate</div>
              </div>
              
              <div className="p-4 bg-purple-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Brain className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium">AI Systems</span>
                </div>
                <div className="text-xl font-bold text-purple-900">
                  {metrics.ai_metrics.average_confidence?.toFixed(1) || 0}%
                </div>
                <div className="text-xs text-purple-600">Avg Confidence</div>
              </div>
            </div>
          )}
          
          <div className="flex justify-center">
            <Button 
              onClick={fetchMetrics} 
              disabled={isLoading}
              variant="outline"
              className="gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh Metrics
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}