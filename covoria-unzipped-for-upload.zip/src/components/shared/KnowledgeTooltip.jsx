import React, { useState, useEffect } from 'react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { HelpCircle, Loader2 } from 'lucide-react';
import { InsuranceKnowledgeBase } from '@/api/entities';

export default function KnowledgeTooltip({ term }) {
  const [content, setContent] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const fetchKnowledge = async () => {
    if (!term || content) return;
    setIsLoading(true);
    try {
      const results = await InsuranceKnowledgeBase.filter({ sectionTitle: term }, null, 1);
      if (results && results.length > 0) {
        setContent(results[0].content);
      } else {
        setContent(`No definition found for "${term}".`);
      }
    } catch (error) {
      console.error(`Failed to fetch knowledge for term: ${term}`, error);
      setContent('Could not load definition.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenChange = (open) => {
    setIsOpen(open);
    if (open && !content) {
      fetchKnowledge();
    }
  };

  return (
    <Popover onOpenChange={handleOpenChange} open={isOpen}>
      <PopoverTrigger asChild>
        <Button variant="link" className="p-0 h-auto text-cyan-400 hover:text-cyan-300 text-sm font-semibold inline-block ml-1">
          <span className="border-b border-dashed border-cyan-400/50">{term}</span>
          <HelpCircle className="w-3 h-3 inline-block ml-1" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 bg-slate-900 border-slate-700 text-white">
        {isLoading ? (
          <div className="flex items-center justify-center p-4">
            <Loader2 className="w-5 h-5 animate-spin text-cyan-400" />
          </div>
        ) : (
          <div className="p-2">
            <h4 className="font-bold text-base mb-2">{term}</h4>
            <p className="text-sm text-slate-300">{content}</p>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}