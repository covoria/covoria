import React, { createContext, useContext, useState } from 'react';

const LanguageContext = createContext();

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    return {
      language: 'en',
      setLanguage: () => {},
      t: (key) => key
    };
  }
  return context;
};

const translations = {
  en: {
    'welcome': 'Welcome',
    'dashboard': 'Dashboard',
    'insurance': 'Insurance',
    'savings': 'Savings',
    'insights': 'Insights',
    'documents': 'Documents',
    'assistant': 'Assistant'
  }
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState('en');

  const t = (key) => {
    return translations[language]?.[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};