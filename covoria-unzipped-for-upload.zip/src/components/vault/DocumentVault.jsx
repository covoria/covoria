import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  Upload, 
  Search, 
  Download, 
  Eye, 
  Trash2,
  Calendar,
  File,
  Filter
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { UploadFile } from '@/api/integrations';

export default function DocumentVault() {
  const [documents, setDocuments] = useState([]);
  const [filteredDocs, setFilteredDocs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [uploadStatus, setUploadStatus] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    loadDocuments();
  }, []);

  useEffect(() => {
    filterDocuments();
  }, [documents, searchTerm, categoryFilter]);

  const loadDocuments = () => {
    // Mock data - in real app, this would come from a database
    const mockDocs = [
      {
        id: 1,
        name: "Health Insurance Policy 2024.pdf",
        type: "health",
        uploadDate: "2024-01-15",
        size: "1.2 MB",
        fileUrl: "#",
        relatedPolicyId: "policy_1"
      },
      {
        id: 2,
        name: "Auto Coverage Details.pdf",
        type: "auto",
        uploadDate: "2024-01-12",
        size: "850 KB",
        fileUrl: "#",
        relatedPolicyId: "policy_2"
      },
      {
        id: 3,
        name: "401k Statement Q4.pdf",
        type: "retirement",
        uploadDate: "2024-01-08",
        size: "2.1 MB",
        fileUrl: "#",
        relatedPolicyId: "account_1"
      }
    ];
    setDocuments(mockDocs);
  };

  const filterDocuments = () => {
    let filtered = documents;

    if (searchTerm) {
      filtered = filtered.filter(doc =>
        doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doc.type.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (categoryFilter !== 'all') {
      filtered = filtered.filter(doc => doc.type === categoryFilter);
    }

    setFilteredDocs(filtered);
  };

  const handleFileUpload = async (file) => {
    if (!file) return;

    setIsUploading(true);
    setUploadStatus('Uploading...');

    try {
      const { file_url } = await UploadFile({ file });
      
      const newDoc = {
        id: Date.now(),
        name: file.name,
        type: detectDocumentType(file.name),
        uploadDate: new Date().toISOString().split('T')[0],
        size: formatFileSize(file.size),
        fileUrl: file_url
      };

      setDocuments(prev => [newDoc, ...prev]);
      setUploadStatus('✅ Upload successful!');
      
      setTimeout(() => {
        setUploadStatus('');
      }, 3000);
    } catch (error) {
      setUploadStatus('❌ Upload failed. Please try again.');
      setTimeout(() => {
        setUploadStatus('');
      }, 3000);
    } finally {
      setIsUploading(false);
    }
  };

  const detectDocumentType = (filename) => {
    const name = filename.toLowerCase();
    if (name.includes('health') || name.includes('medical')) return 'health';
    if (name.includes('auto') || name.includes('car') || name.includes('vehicle')) return 'auto';
    if (name.includes('life')) return 'life';
    if (name.includes('home') || name.includes('property')) return 'home';
    if (name.includes('401k') || name.includes('retirement') || name.includes('pension')) return 'retirement';
    return 'other';
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const removeDocument = (docId) => {
    setDocuments(prev => prev.filter(doc => doc.id !== docId));
  };

  const typeColors = {
    health: "bg-red-100 text-red-800",
    auto: "bg-blue-100 text-blue-800",
    life: "bg-purple-100 text-purple-800",
    home: "bg-green-100 text-green-800",
    retirement: "bg-yellow-100 text-yellow-800",
    other: "bg-gray-100 text-gray-800"
  };

  const categories = ['all', 'health', 'auto', 'life', 'home', 'retirement', 'other'];

  return (
    <div className="space-y-6">
      <Card className="covoria-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <FileText className="w-6 h-6 text-cyan-600" />
            Document Vault
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Upload Section */}
          <div className="mb-6">
            <div className="relative border-2 border-dashed border-gray-300 rounded-lg p-6 hover:border-cyan-400 transition-colors">
              <input
                type="file"
                onChange={(e) => handleFileUpload(e.target.files[0])}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                accept=".pdf,.doc,.docx,.jpg,.png,.xlsx,.csv"
                disabled={isUploading}
              />
              <div className="text-center">
                <Upload className={`mx-auto h-8 w-8 mb-2 ${isUploading ? 'animate-bounce text-cyan-600' : 'text-gray-400'}`} />
                <p className="text-sm text-gray-600 mb-1">
                  {isUploading ? 'Uploading...' : 'Click to upload or drag and drop'}
                </p>
                <p className="text-xs text-gray-500">
                  PDF, DOC, DOCX, JPG, PNG, XLSX, CSV up to 10MB
                </p>
              </div>
            </div>
            {uploadStatus && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-3 text-sm text-center"
              >
                {uploadStatus}
              </motion.div>
            )}
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search documents..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Documents List */}
          <div className="space-y-3">
            <AnimatePresence>
              {filteredDocs.map((doc, index) => (
                <motion.div
                  key={doc.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ delay: index * 0.1 }}
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-gray-100 rounded-lg">
                        <File className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{doc.name}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge className={typeColors[doc.type]}>
                            {doc.type}
                          </Badge>
                          <span className="text-xs text-gray-500">{doc.size}</span>
                          <div className="flex items-center gap-1 text-xs text-gray-500">
                            <Calendar className="w-3 h-3" />
                            {new Date(doc.uploadDate).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm">
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => removeDocument(doc.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {filteredDocs.length === 0 && (
            <div className="text-center py-8">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-700 mb-2">
                {searchTerm || categoryFilter !== 'all' 
                  ? 'No documents match your search' 
                  : 'No documents uploaded yet'
                }
              </h3>
              <p className="text-gray-500">
                {searchTerm || categoryFilter !== 'all'
                  ? 'Try adjusting your search or filter'
                  : 'Upload your first document to get started'
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}