import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import StatCard from '../components/admin/StatCard';
import RecentActivity from '../components/admin/RecentActivity';
import AnalyticsChart from '../components/admin/AnalyticsChart';
import DocumentManager from '../components/admin/DocumentManager';
import { User } from '@/api/entities';
import { InsurancePolicy } from '@/api/entities';
import { SavingsAccount } from '@/api/entities';
import { Insight } from '@/api/entities';
import { Document } from '@/api/entities';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    users: 0,
    policies: 0,
    accounts: 0,
    insights: 0,
    documents: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        // Use list() instead of count() and get length
        const [users, policies, accounts, insights, documents] = await Promise.all([
          User.list().then(data => data.length).catch(() => 0),
          InsurancePolicy.list().then(data => data.length).catch(() => 0),
          SavingsAccount.list().then(data => data.length).catch(() => 0),
          Insight.list().then(data => data.length).catch(() => 0),
          Document.list().then(data => data.length).catch(() => 0),
        ]);
        
        setStats({
          users,
          policies,
          accounts,
          insights,
          documents,
        });
      } catch (error) {
        console.error("Failed to fetch admin stats:", error);
        // Set default values on error
        setStats({
          users: 0,
          policies: 0,
          accounts: 0,
          insights: 0,
          documents: 0,
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchStats();
  }, []);

  return (
    <div className="p-4 md:p-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          <StatCard title="Total Users" value={stats.users} isLoading={isLoading} />
          <StatCard title="Policies" value={stats.policies} isLoading={isLoading} />
          <StatCard title="Savings Accounts" value={stats.accounts} isLoading={isLoading} />
          <StatCard title="Active Insights" value={stats.insights} isLoading={isLoading} />
          <StatCard title="Total Documents" value={stats.documents} isLoading={isLoading} />
        </div>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="grid grid-cols-1 lg:grid-cols-3 gap-6"
      >
        <div className="lg:col-span-2">
          <AnalyticsChart />
        </div>
        <div className="lg:col-span-1">
          <RecentActivity />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <DocumentManager />
      </motion.div>
    </div>
  );
}