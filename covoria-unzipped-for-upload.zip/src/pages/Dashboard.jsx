import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { User } from '@/api/entities';
import OverviewCards from '../components/dashboard/OverviewCards';
import InsuranceSummary from '../components/dashboard/InsuranceSummary';
import SavingsSummary from '../components/dashboard/SavingsSummary';
import AssistantCTA from '../components/dashboard/AssistantCTA';
import { Skeleton } from '@/components/ui/skeleton';

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Failed to fetch user:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUser();
  }, []);

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-12 w-1/3" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-48 w-full" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="p-4 md:p-6 space-y-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white">
            Welcome back, {user?.full_name?.split(' ')[0] || 'User'}
          </h1>
          <p className="text-slate-400">Here's your financial overview.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <OverviewCards />
            <InsuranceSummary />
            <SavingsSummary />
          </div>
          <div className="space-y-6">
            <AssistantCTA />
          </div>
        </div>
      </div>
    </motion.div>
  );
}