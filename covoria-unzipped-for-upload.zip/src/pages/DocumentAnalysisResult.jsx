import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Document, DocumentField, InsurancePolicy, SavingsAccount, Insight } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader, CheckCircle, AlertTriangle, ArrowRight, Home, FileText, Shield, PiggyBank, Lightbulb, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { processDocument } from '@/api/functions';

const StatusDisplay = ({ status, summary, onRetry }) => {
    const statusConfig = {
        pending: { 
            icon: <Loader className="w-12 h-12 text-gray-400 animate-spin" />, 
            title: "Starting Analysis...", 
            message: "Your document is being prepared for AI analysis.",
            color: "text-gray-600",
            bgColor: "bg-gray-50"
        },
        processing: { 
            icon: <Loader className="w-12 h-12 text-cyan-500 animate-spin" />, 
            title: "AI Analysis in Progress", 
            message: "Our advanced AI is extracting insights and structured data from your document.",
            color: "text-cyan-700",
            bgColor: "bg-cyan-50"
        },
        analyzed: { 
            icon: <CheckCircle className="w-12 h-12 text-green-500" />, 
            title: "Analysis Complete", 
            message: summary || "We've successfully analyzed your document and extracted key information.",
            color: "text-green-700",
            bgColor: "bg-green-50"
        },
        failed: { 
            icon: <AlertTriangle className="w-12 h-12 text-red-500" />, 
            title: "Analysis Failed", 
            message: summary || "We encountered an issue processing this document. Please try again.",
            color: "text-red-700",
            bgColor: "bg-red-50"
        },
    };

    const currentStatus = statusConfig[status] || statusConfig.pending;

    return (
        <div className={`text-center p-8 space-y-6 ${currentStatus.bgColor} rounded-xl`}>
            <motion.div 
                initial={{ scale: 0.5, opacity: 0 }} 
                animate={{ scale: 1, opacity: 1 }} 
                transition={{ type: "spring", stiffness: 260, damping: 20 }}
            >
                {currentStatus.icon}
            </motion.div>
            <div>
                <h2 className={`text-2xl font-bold ${currentStatus.color} mb-2`}>{currentStatus.title}</h2>
                <p className={`${currentStatus.color} max-w-md mx-auto leading-relaxed`}>{currentStatus.message}</p>
            </div>
            
            {status === 'failed' && onRetry && (
                <Button onClick={onRetry} className="mt-4 covoria-gradient text-white">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Retry Analysis
                </Button>
            )}
        </div>
    );
};

const AnalysisResults = ({ document, fields, relatedData }) => {
    const { policies, accounts, insights } = relatedData;
    
    return (
        <div className="space-y-6">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="covoria-card">
                    <CardContent className="p-4 text-center">
                        <FileText className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                        <div className="text-2xl font-bold text-gray-900">{fields.length}</div>
                        <div className="text-sm text-gray-600">Fields Extracted</div>
                    </CardContent>
                </Card>
                
                <Card className="covoria-card">
                    <CardContent className="p-4 text-center">
                        <Shield className="w-8 h-8 text-green-600 mx-auto mb-2" />
                        <div className="text-2xl font-bold text-gray-900">{policies.length + accounts.length}</div>
                        <div className="text-sm text-gray-600">Records Created</div>
                    </CardContent>
                </Card>
                
                <Card className="covoria-card">
                    <CardContent className="p-4 text-center">
                        <Lightbulb className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                        <div className="text-2xl font-bold text-gray-900">{insights.length}</div>
                        <div className="text-sm text-gray-600">AI Insights</div>
                    </CardContent>
                </Card>
            </div>

            {/* Document Fields */}
            {fields.length > 0 && (
                <Card className="covoria-card">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <FileText className="w-5 h-5" />
                            Extracted Fields
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {fields.slice(0, 10).map((field, index) => (
                                <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                    <div>
                                        <div className="font-medium text-sm capitalize">
                                            {field.field_name.replace(/_/g, ' ')}
                                        </div>
                                        <div className="text-sm text-gray-600">{field.field_value}</div>
                                    </div>
                                    <Badge 
                                        className={
                                            field.confidence_score >= 0.9 ? 'bg-green-100 text-green-800' :
                                            field.confidence_score >= 0.7 ? 'bg-yellow-100 text-yellow-800' :
                                            'bg-red-100 text-red-800'
                                        }
                                    >
                                        {Math.round(field.confidence_score * 100)}%
                                    </Badge>
                                </div>
                            ))}
                        </div>
                        {fields.length > 10 && (
                            <p className="text-sm text-gray-500 mt-3 text-center">
                                And {fields.length - 10} more fields extracted...
                            </p>
                        )}
                    </CardContent>
                </Card>
            )}

            {/* Created Records */}
            {(policies.length > 0 || accounts.length > 0) && (
                <Card className="covoria-card">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Shield className="w-5 h-5" />
                            Created Records
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {policies.map((policy, index) => (
                            <div key={index} className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                                <div>
                                    <div className="font-medium">{policy.policy_name}</div>
                                    <div className="text-sm text-gray-600">
                                        {policy.provider} • {policy.insurance_type} • ${policy.coverage_amount?.toLocaleString()}
                                    </div>
                                </div>
                                <Badge className="bg-blue-100 text-blue-800">Insurance Policy</Badge>
                            </div>
                        ))}
                        
                        {accounts.map((account, index) => (
                            <div key={index} className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                                <div>
                                    <div className="font-medium">{account.account_name}</div>
                                    <div className="text-sm text-gray-600">
                                        {account.provider} • {account.account_type} • ${account.current_balance?.toLocaleString()}
                                    </div>
                                </div>
                                <Badge className="bg-green-100 text-green-800">Savings Account</Badge>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            )}

            {/* AI Insights */}
            {insights.length > 0 && (
                <Card className="covoria-card">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Lightbulb className="w-5 h-5" />
                            AI-Generated Insights
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {insights.map((insight, index) => (
                            <div key={index} className="p-4 border-l-4 border-l-cyan-500 bg-cyan-50 rounded-r-lg">
                                <div className="flex items-start justify-between mb-2">
                                    <h4 className="font-medium text-gray-900">{insight.title}</h4>
                                    <Badge 
                                        className={
                                            insight.priority === 'critical' ? 'bg-red-100 text-red-800' :
                                            insight.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                                            insight.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                            'bg-gray-100 text-gray-800'
                                        }
                                    >
                                        {insight.priority}
                                    </Badge>
                                </div>
                                <p className="text-sm text-gray-700 mb-2">{insight.description}</p>
                                {insight.action_required && (
                                    <p className="text-sm font-medium text-cyan-700">
                                        💡 {insight.action_required}
                                    </p>
                                )}
                                {insight.potential_savings > 0 && (
                                    <p className="text-sm font-medium text-green-700">
                                        💰 Potential savings: ${insight.potential_savings.toLocaleString()}/year
                                    </p>
                                )}
                            </div>
                        ))}
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default function DocumentAnalysisResult() {
    const [document, setDocument] = useState(null);
    const [fields, setFields] = useState([]);
    const [relatedData, setRelatedData] = useState({ policies: [], accounts: [], insights: [] });
    const [error, setError] = useState(null);
    const [isRetrying, setIsRetrying] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();
    
    const urlParams = new URLSearchParams(location.search);
    const documentId = urlParams.get('id');

    useEffect(() => {
        if (!documentId) {
            setError("No document ID provided.");
            return;
        }

        const fetchData = async () => {
            try {
                const doc = await Document.get(documentId);
                setDocument(doc);

                // If document is pending or processing, trigger analysis
                if (doc.status === 'pending' || doc.status === 'uploading') {
                    await triggerAnalysis(documentId);
                }

                // Load related data
                await loadRelatedData(documentId);
            } catch (err) {
                console.error("Error loading document:", err);
                setError("Failed to load document details.");
            }
        };

        fetchData();

        // Set up polling for document status updates
        const interval = setInterval(async () => {
            try {
                const doc = await Document.get(documentId);
                setDocument(doc);
                
                if (doc.status === 'analyzed' || doc.status === 'failed') {
                    clearInterval(interval);
                    if (doc.status === 'analyzed') {
                        await loadRelatedData(documentId);
                    }
                }
            } catch (err) {
                console.error("Polling error:", err);
            }
        }, 2000);

        return () => clearInterval(interval);
    }, [documentId]);

    const triggerAnalysis = async (docId) => {
        try {
            await processDocument({ document_id: docId });
        } catch (error) {
            console.error("Analysis trigger failed:", error);
        }
    };

    const loadRelatedData = async (docId) => {
        try {
            const [docFields, policies, accounts, insights] = await Promise.all([
                DocumentField.filter({ document_id: docId }).catch(() => []),
                InsurancePolicy.filter({ origin_document_id: docId }).catch(() => []),
                SavingsAccount.filter({ origin_document_id: docId }).catch(() => []),
                Insight.filter({ related_document_id: docId }).catch(() => [])
            ]);

            setFields(Array.isArray(docFields) ? docFields : []);
            setRelatedData({
                policies: Array.isArray(policies) ? policies : [],
                accounts: Array.isArray(accounts) ? accounts : [],
                insights: Array.isArray(insights) ? insights : []
            });
        } catch (err) {
            console.error("Error loading related data:", err);
        }
    };

    const handleRetry = async () => {
        setIsRetrying(true);
        try {
            await triggerAnalysis(documentId);
            // Refresh document data
            const doc = await Document.get(documentId);
            setDocument(doc);
        } catch (err) {
            console.error("Retry failed:", err);
        } finally {
            setIsRetrying(false);
        }
    };

    const handleGoToDashboard = () => {
        navigate(createPageUrl('Dashboard'));
    };

    const handleGoToVault = () => {
        navigate(createPageUrl('DocumentVault'));
    };

    if (error) {
        return (
            <div className="p-6">
                <Card className="max-w-2xl mx-auto">
                    <CardContent className="p-8 text-center">
                        <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
                        <h2 className="text-xl font-bold text-gray-900 mb-2">Error</h2>
                        <p className="text-gray-600 mb-6">{error}</p>
                        <Button onClick={() => navigate(createPageUrl('Settings'))} className="covoria-gradient text-white">
                            <Home className="w-4 h-4 mr-2" />
                            Return Home
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    if (!document) {
        return (
            <div className="p-6">
                <Card className="max-w-2xl mx-auto">
                    <CardContent className="p-8">
                        <StatusDisplay status="pending" />
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="p-6 max-w-6xl mx-auto">
            <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">Document Analysis</h1>
                <p className="text-gray-600">{document.file_name}</p>
            </div>

            <AnimatePresence mode="wait">
                {(document.status === 'pending' || document.status === 'processing') && (
                    <motion.div
                        key="processing"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                    >
                        <Card className="mb-6">
                            <CardContent className="p-8">
                                <StatusDisplay 
                                    status={document.status} 
                                    summary={document.analysis_summary}
                                />
                            </CardContent>
                        </Card>
                    </motion.div>
                )}

                {document.status === 'analyzed' && (
                    <motion.div
                        key="results"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                    >
                        <Card className="mb-6">
                            <CardContent className="p-6">
                                <StatusDisplay 
                                    status={document.status} 
                                    summary={document.analysis_summary}
                                />
                            </CardContent>
                        </Card>
                        
                        <AnalysisResults 
                            document={document}
                            fields={fields}
                            relatedData={relatedData}
                        />
                    </motion.div>
                )}

                {document.status === 'failed' && (
                    <motion.div
                        key="failed"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                    >
                        <Card className="mb-6">
                            <CardContent className="p-8">
                                <StatusDisplay 
                                    status={document.status} 
                                    summary={document.analysis_summary}
                                    onRetry={handleRetry}
                                />
                            </CardContent>
                        </Card>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Action Buttons */}
            <div className="flex gap-4 justify-center mt-8">
                <Button 
                    variant="outline" 
                    onClick={handleGoToVault}
                    className="flex items-center gap-2"
                >
                    <FileText className="w-4 h-4" />
                    Document Vault
                </Button>
                <Button 
                    onClick={handleGoToDashboard}
                    className="covoria-gradient text-white flex items-center gap-2"
                >
                    Dashboard
                    <ArrowRight className="w-4 h-4" />
                </Button>
            </div>
        </div>
    );
}