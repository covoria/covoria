import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { RefreshCw, Search, FileText, Shield, PiggyBank, Trash2, AlertTriangle, CheckCircle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Document } from '@/api/entities';
import { InsurancePolicy } from '@/api/entities';
import { SavingsAccount } from '@/api/entities';
import { deleteDocumentAndData } from '@/api/functions';

const DocumentItemCard = ({ item, onDelete, isDeletingId }) => {
    const { type, name, subtext, Icon, iconBg } = item;
    
    return (
        <motion.div
            layout
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4 hover:border-slate-600 transition-colors"
        >
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className={`p-3 rounded-lg ${iconBg} flex-shrink-0`}>
                        <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="min-w-0 flex-1">
                        <p className="text-sm font-semibold text-slate-100 truncate">{name}</p>
                        <p className="text-xs text-slate-400 truncate">{subtext}</p>
                    </div>
                </div>
                <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => onDelete(item.id)}
                    disabled={isDeletingId === item.id}
                    className="text-slate-500 hover:text-red-500 hover:bg-red-900/20 flex-shrink-0 ml-2"
                    title="Delete this document and all related data"
                >
                    {isDeletingId === item.id 
                        ? <RefreshCw className="w-4 h-4 animate-spin" /> 
                        : <Trash2 className="w-4 h-4" />
                    }
                </Button>
            </div>
        </motion.div>
    );
};

export default function DocumentVault() {
    const [allItems, setAllItems] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [isDeletingId, setIsDeletingId] = useState(null);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const loadVaultData = useCallback(async () => {
        console.log('🚀 [DocumentVault] Loading vault data...');
        setIsLoading(true);
        setError('');
        setSuccess('');
        
        try {
            const [docs, policies, accounts] = await Promise.all([
                Document.list('-created_date'),
                InsurancePolicy.list('-created_date'),
                SavingsAccount.list('-created_date')
            ]);
            
            console.log('🚀 [DocumentVault] Data loaded:', { docs: docs.length, policies: policies.length, accounts: accounts.length });
            
            const combinedItems = docs.map(d => {
                const policy = policies.find(p => p.source_document_id === d.id);
                const account = accounts.find(a => a.source_document_id === d.id);
                
                if (policy) {
                    return { 
                        id: d.id, 
                        type: 'policy', 
                        name: policy.policy_name || d.file_name, 
                        subtext: `${policy.insurance_type || 'Insurance'} Policy • ${policy.provider || 'Unknown Provider'}`, 
                        Icon: Shield, 
                        iconBg: 'bg-blue-600' 
                    };
                }
                if (account) {
                    return { 
                        id: d.id, 
                        type: 'account', 
                        name: account.account_name || d.file_name, 
                        subtext: `${account.account_type || 'Savings'} Account • ${account.provider || 'Unknown Provider'}`, 
                        Icon: PiggyBank, 
                        iconBg: 'bg-green-600' 
                    };
                }
                return { 
                    id: d.id, 
                    type: 'document', 
                    name: d.file_name, 
                    subtext: `Document • ${d.status || 'Uploaded'}`, 
                    Icon: FileText, 
                    iconBg: 'bg-slate-600' 
                };
            });
            
            console.log('🚀 [DocumentVault] Combined items:', combinedItems.length);
            setAllItems(combinedItems);
        } catch (err) {
            console.error("🚀 [DocumentVault] Failed to load vault data:", err);
            setError("Could not load documents. Please try refreshing.");
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        loadVaultData();
    }, [loadVaultData]);

    const handleDelete = async (documentId) => {
        console.log('🚀 [DocumentVault] Starting deletion for:', documentId);
        setIsDeletingId(documentId);
        setError('');
        setSuccess('');
        
        try {
            const result = await deleteDocumentAndData({ documentId });
            console.log('🚀 [DocumentVault] Deletion result:', result);
            
            if (result?.data?.success) {
                setSuccess(result.data.message || 'Item deleted successfully.');
                // Optimistic UI update - remove the item immediately
                setAllItems(prev => prev.filter(item => item.id !== documentId));
                
                // Also reload data to ensure consistency
                setTimeout(() => {
                    loadVaultData();
                }, 1000);
            } else {
                throw new Error(result?.data?.error || 'Deletion failed');
            }
        } catch (err) {
            console.error("🚀 [DocumentVault] Deletion failed:", err);
            setError(`Could not delete item: ${err.message}`);
        } finally {
            setIsDeletingId(null);
        }
    };

    const filteredItems = allItems.filter(item =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.subtext.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="p-4 md:p-6 space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl">
                        <FileText className="w-8 h-8 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-slate-100">Document Vault</h1>
                        <p className="text-slate-400">Manage your uploaded documents and extracted data.</p>
                    </div>
                </div>
                <Button 
                    onClick={loadVaultData} 
                    variant="outline" 
                    disabled={isLoading}
                    className="bg-slate-800/50 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white"
                >
                    <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    Refresh
                </Button>
            </div>
            
            {/* Status Messages */}
            <AnimatePresence>
                {error && (
                    <motion.div 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="p-3 bg-red-900/50 text-red-300 border border-red-700 rounded-lg flex items-center gap-2"
                    >
                        <AlertTriangle size={16}/>
                        {error}
                    </motion.div>
                )}
                {success && (
                    <motion.div 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="p-3 bg-green-900/50 text-green-300 border border-green-700 rounded-lg flex items-center gap-2"
                    >
                        <CheckCircle size={16}/>
                        {success}
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Search */}
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <Input
                    placeholder="Search documents by name or type..."
                    className="pl-10 bg-slate-800/50 border-slate-700 text-slate-200 placeholder-slate-500"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            {/* Content */}
            {isLoading ? (
                <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                        <Skeleton key={i} className="h-20 w-full bg-slate-800 rounded-2xl" />
                    ))}
                </div>
            ) : (
                <AnimatePresence mode="wait">
                    {filteredItems.length > 0 ? (
                        <motion.div 
                            key="items-grid"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="grid grid-cols-1 gap-4"
                        >
                            <AnimatePresence>
                                {filteredItems.map(item => (
                                    <DocumentItemCard 
                                        key={item.id} 
                                        item={item} 
                                        onDelete={handleDelete} 
                                        isDeletingId={isDeletingId} 
                                    />
                                ))}
                            </AnimatePresence>
                        </motion.div>
                    ) : (
                        <motion.div
                            key="empty-state"
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -20 }}
                            className="text-center py-16 border-2 border-dashed border-slate-700 rounded-xl bg-slate-800/30"
                        >
                            <FileText className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-slate-200 mb-2">No Documents Found</h3>
                            <p className="text-slate-400">
                                {searchTerm ? "No items match your search." : "Upload documents to get started."}
                            </p>
                        </motion.div>
                    )}
                </AnimatePresence>
            )}
        </div>
    );
}