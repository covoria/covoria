import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart3, 
  Users, 
  MessageCircle, 
  Lightbulb,
  TrendingUp,
  AlertTriangle,
  Brain,
  Eye,
  RefreshCw,
  Download
} from 'lucide-react';
import { User } from '@/api/entities';
import { AssistantConversation } from '@/api/entities';
import { Insight } from '@/api/entities';
import { InsightInteraction } from '@/api/entities';
import { UserActivity } from '@/api/entities';
import { LLMUsageLog } from '@/api/entities';
import { AIFeedback } from '@/api/entities';

export default function FounderDashboard() {
  const [analytics, setAnalytics] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('7d');

  useEffect(() => {
    checkAccess();
  }, []);

  const checkAccess = async () => {
    try {
      const user = await User.me();
      if (user.role !== 'admin' && user.email !== 'michael@covoria.com') {
        window.location.href = '/Dashboard';
        return;
      }
      loadAnalytics();
    } catch (error) {
      console.error('Access check failed:', error);
      window.location.href = '/Dashboard';
    }
  };

  const loadAnalytics = async () => {
    setIsLoading(true);
    try {
      // Calculate date range
      const now = new Date();
      const daysBack = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
      const startDate = new Date(now.getTime() - (daysBack * 24 * 60 * 60 * 1000));

      // Load all analytics data
      const [
        conversations,
        insights,
        interactions,
        activities,
        llmUsage,
        feedback
      ] = await Promise.all([
        AssistantConversation.list(),
        Insight.list(),
        InsightInteraction.list(),
        UserActivity.list(),
        LLMUsageLog.list(),
        AIFeedback.list()
      ]);

      // Filter by date range
      const filterByDate = (items, dateField) => items.filter(item => {
        const itemDate = new Date(item[dateField]);
        return itemDate >= startDate;
      });

      const recentConversations = filterByDate(conversations, 'created_date');
      const recentInsights = filterByDate(insights, 'created_date');
      const recentInteractions = filterByDate(interactions, 'interaction_timestamp');
      const recentActivities = filterByDate(activities, 'activity_date');
      const recentLLMUsage = filterByDate(llmUsage, 'usage_date');
      const recentFeedback = filterByDate(feedback, 'created_date');

      // Calculate analytics
      const analytics = {
        overview: {
          total_conversations: recentConversations.length,
          total_insights: recentInsights.length,
          total_interactions: recentInteractions.length,
          ai_satisfaction: calculateSatisfactionScore(recentFeedback)
        },
        
        popular_questions: getPopularQuestions(recentConversations),
        insight_performance: getInsightPerformance(recentInsights, recentInteractions),
        user_dropoff_points: getUserDropoffPoints(recentActivities),
        problematic_policies: getProblematicPolicies(recentLLMUsage),
        ai_performance: getAIPerformance(recentLLMUsage, recentFeedback),
        
        trends: {
          daily_conversations: getDailyTrends(recentConversations, 'created_date'),
          daily_insights: getDailyTrends(recentInsights, 'created_date'),
          user_engagement: getUserEngagementTrends(recentActivities)
        }
      };

      setAnalytics(analytics);
    } catch (error) {
      console.error('Failed to load analytics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Helper functions for analytics calculations
  const calculateSatisfactionScore = (feedback) => {
    if (feedback.length === 0) return 0;
    const positive = feedback.filter(f => f.feedback_type === 'thumbs_up').length;
    return Math.round((positive / feedback.length) * 100);
  };

  const getPopularQuestions = (conversations) => {
    const userMessages = conversations.filter(c => c.message_type === 'user');
    const questionCounts = {};
    
    userMessages.forEach(msg => {
      // Simple keyword extraction
      const keywords = msg.content.toLowerCase()
        .split(' ')
        .filter(word => word.length > 3)
        .slice(0, 3);
      
      const key = keywords.join(' ');
      questionCounts[key] = (questionCounts[key] || 0) + 1;
    });
    
    return Object.entries(questionCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([question, count]) => ({ question, count }));
  };

  const getInsightPerformance = (insights, interactions) => {
    return insights.map(insight => {
      const insightInteractions = interactions.filter(i => i.insight_id === insight.id);
      const clicks = insightInteractions.filter(i => i.interaction_type === 'click').length;
      const views = insightInteractions.filter(i => i.interaction_type === 'view').length;
      
      return {
        title: insight.title,
        category: insight.category,
        views,
        clicks,
        engagement_rate: views > 0 ? Math.round((clicks / views) * 100) : 0
      };
    }).sort((a, b) => b.engagement_rate - a.engagement_rate).slice(0, 10);
  };

  const getUserDropoffPoints = (activities) => {
    const pageViews = activities.filter(a => a.activity_type === 'navigation');
    const pageCounts = {};
    
    pageViews.forEach(activity => {
      const page = activity.page_url || activity.title;
      pageCounts[page] = (pageCounts[page] || 0) + 1;
    });
    
    return Object.entries(pageCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([page, count]) => ({ page, count }));
  };

  const getProblematicPolicies = (llmUsage) => {
    const failures = llmUsage.filter(usage => !usage.success);
    const errorCounts = {};
    
    failures.forEach(failure => {
      const context = failure.context_tab || 'unknown';
      errorCounts[context] = (errorCounts[context] || 0) + 1;
    });
    
    return Object.entries(errorCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([context, count]) => ({ context, count }));
  };

  const getAIPerformance = (llmUsage, feedback) => {
    const totalCalls = llmUsage.length;
    const successfulCalls = llmUsage.filter(usage => usage.success).length;
    const avgResponseTime = llmUsage.reduce((sum, usage) => sum + (usage.processing_time_ms || 0), 0) / totalCalls;
    
    return {
      success_rate: totalCalls > 0 ? Math.round((successfulCalls / totalCalls) * 100) : 0,
      avg_response_time: Math.round(avgResponseTime),
      total_calls: totalCalls,
      user_satisfaction: calculateSatisfactionScore(feedback)
    };
  };

  const getDailyTrends = (items, dateField) => {
    const dailyCounts = {};
    
    items.forEach(item => {
      const date = new Date(item[dateField]).toDateString();
      dailyCounts[date] = (dailyCounts[date] || 0) + 1;
    });
    
    return Object.entries(dailyCounts)
      .sort(([a], [b]) => new Date(a) - new Date(b))
      .map(([date, count]) => ({ date, count }));
  };

  const getUserEngagementTrends = (activities) => {
    const engagementScores = {};
    
    activities.forEach(activity => {
      const date = new Date(activity.activity_date).toDateString();
      const score = activity.impact_score || 50;
      
      if (!engagementScores[date]) {
        engagementScores[date] = { total: 0, count: 0 };
      }
      
      engagementScores[date].total += score;
      engagementScores[date].count += 1;
    });
    
    return Object.entries(engagementScores)
      .map(([date, data]) => ({
        date,
        avg_engagement: Math.round(data.total / data.count)
      }))
      .sort((a, b) => new Date(a.date) - new Date(b.date));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-white text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4" />
          <p>Loading founder analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Founder Dashboard</h1>
            <p className="text-slate-400">Internal AI & User Analytics</p>
          </div>
          
          <div className="flex gap-3">
            <select 
              value={timeRange} 
              onChange={(e) => setTimeRange(e.target.value)}
              className="bg-slate-800 text-white border border-slate-700 rounded px-3 py-2"
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last 90 days</option>
            </select>
            
            <Button onClick={loadAnalytics} variant="outline">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">AI Conversations</p>
                  <p className="text-2xl font-bold text-white">{analytics?.overview.total_conversations || 0}</p>
                </div>
                <MessageCircle className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Insights Generated</p>
                  <p className="text-2xl font-bold text-white">{analytics?.overview.total_insights || 0}</p>
                </div>
                <Lightbulb className="w-8 h-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">User Interactions</p>
                  <p className="text-2xl font-bold text-white">{analytics?.overview.total_interactions || 0}</p>
                </div>
                <Eye className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">AI Satisfaction</p>
                  <p className="text-2xl font-bold text-white">{analytics?.overview.ai_satisfaction || 0}%</p>
                </div>
                <Brain className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Popular Questions */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Most Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {analytics?.popular_questions?.map((item, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-slate-300 text-sm truncate flex-1">{item.question}</span>
                    <Badge variant="outline" className="ml-2">{item.count}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Insight Performance */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Top Performing Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {analytics?.insight_performance?.slice(0, 5).map((insight, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300 text-sm truncate flex-1">{insight.title}</span>
                      <Badge variant="outline">{insight.engagement_rate}%</Badge>
                    </div>
                    <div className="flex gap-2 text-xs text-slate-500">
                      <span>{insight.views} views</span>
                      <span>•</span>
                      <span>{insight.clicks} clicks</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* AI Performance */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">AI Performance Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-slate-400">Success Rate</span>
                  <span className="text-white font-bold">{analytics?.ai_performance.success_rate}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Avg Response Time</span>
                  <span className="text-white font-bold">{analytics?.ai_performance.avg_response_time}ms</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Total Calls</span>
                  <span className="text-white font-bold">{analytics?.ai_performance.total_calls}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">User Satisfaction</span>
                  <span className="text-white font-bold">{analytics?.ai_performance.user_satisfaction}%</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Problem Areas */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                Areas Needing Attention
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {analytics?.problematic_policies?.map((item, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-slate-300 text-sm">{item.context}</span>
                    <Badge variant="outline" className="text-red-400 border-red-400">
                      {item.count} errors
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}