
import React, { useState, useEffect } from "react";
import { InsurancePolicy } from "@/api/entities";
import { User } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Shield, Plus, Search, RefreshCw, DollarSign, FileText } from "lucide-react";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton"; // Assuming this path for Skeleton

import PolicyCard from "../components/insurance/PolicyCard";
import AddPolicyDialog from "../components/insurance/AddPolicyDialog";
import PolicyFilters from "../components/insurance/PolicyFilters";

export default function InsurancePage() {
  const [policies, setPolicies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [addDialogOpen, setAddDialogOpen] = useState(false); // Renamed from isDialogOpen
  const [editingPolicy, setEditingPolicy] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    type: "all",
    status: "all",
    provider: "all"
  });

  useEffect(() => {
    loadPolicies();
  }, []);

  const loadPolicies = async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      const data = await InsurancePolicy.filter({ created_by: user.email }, '-created_date');
      setPolicies(data);
    } catch (error) {
      console.error("Failed to load user policies:", error);
      setPolicies([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefresh = async () => {
    await loadPolicies();
  };

  const handleUpdate = async () => { // Renamed from handlePolicyUpdate
    setAddDialogOpen(false); // Close dialog
    setEditingPolicy(null); // Clear editing policy
    await loadPolicies(); // Refresh policies
  };

  const filteredPolicies = policies.filter(policy => {
    const matchesSearch = policy.policy_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         policy.provider?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filters.type === "all" || policy.insurance_type === filters.type;
    const matchesStatus = filters.status === "all" ||
                         (filters.status === "active" && policy.is_active) ||
                         (filters.status === "inactive" && !policy.is_active);
    const matchesProvider = filters.provider === "all" || policy.provider === filters.provider;
    
    return matchesSearch && matchesType && matchesStatus && matchesProvider;
  });

  const activePolicies = policies.filter(p => p.is_active);

  const totalCoverage = activePolicies
    .reduce((sum, policy) => sum + (policy.coverage_amount || 0), 0);

  const monthlyPremiums = activePolicies
    .reduce((sum, policy) => {
      const monthlyPremium = policy.premium_frequency === 'annually'
        ? (policy.premium_amount || 0) / 12
        : policy.premium_frequency === 'quarterly'
        ? (policy.premium_amount || 0) / 3
        : (policy.premium_amount || 0);
      return sum + monthlyPremium;
    }, 0);

  return (
    <div className="min-h-screen bg-[var(--covoria-bg-main)] p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8"
        >
          <div className="flex items-center gap-4">
            <div className="p-3 covoria-gradient rounded-xl">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-[var(--covoria-text-primary)]">Insurance Policies</h1>
              <p className="text-gray-600 dark:text-[var(--covoria-text-secondary)]">Manage and analyze your insurance coverage</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={handleRefresh}
              variant="outline"
              disabled={isLoading}
              className="bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)] hover:bg-slate-700"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button
              onClick={() => setAddDialogOpen(true)}
              className="covoria-gradient text-white"
            >
              <Plus className="w-5 h-5 mr-2" />
              Add Policy
            </Button>
          </div>
        </motion.div>

        {/* Stats Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="covoria-card p-6"
          >
            <div className="flex items-center gap-4">
              <div className="p-3 bg-cyan-100 dark:bg-cyan-900/30 rounded-xl">
                <Shield className="w-6 h-6 text-cyan-600 dark:text-cyan-400" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-[var(--covoria-text-secondary)]">Total Coverage</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-[var(--covoria-text-primary)]">
                  ${totalCoverage.toLocaleString()}
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="covoria-card p-6"
          >
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-xl">
                <DollarSign className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-[var(--covoria-text-secondary)]">Monthly Premiums</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-[var(--covoria-text-primary)]">
                  ${Math.round(monthlyPremiums).toLocaleString()}
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="covoria-card p-6"
          >
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-xl">
                <FileText className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-[var(--covoria-text-secondary)]">Active Policies</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-[var(--covoria-text-primary)]">
                  {activePolicies.length}
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search policies..."
              className="pl-9 pr-4 py-2 border rounded-md w-full bg-[var(--covoria-bg-surface)] border-[var(--covoria-border-color)] text-[var(--covoria-text-primary)] placeholder-gray-400"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <PolicyFilters onFilterChange={setFilters} />
        </div>

        {/* Policies Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-64 w-full bg-gray-200 dark:bg-slate-700 rounded-lg" />
            ))}
          </div>
        ) : filteredPolicies.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPolicies.map((policy, index) => (
              <PolicyCard
                key={policy.id}
                policy={policy}
                delay={index * 0.1}
                onEdit={() => {
                  setEditingPolicy(policy);
                  setAddDialogOpen(true);
                }}
              />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-16 border border-dashed border-[var(--covoria-border-color)] rounded-lg bg-[var(--covoria-bg-surface)]"
          >
            <Shield className="w-16 h-16 text-gray-400 dark:text-slate-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 dark:text-[var(--covoria-text-primary)] mb-2">
              {searchTerm || Object.values(filters).some(f => f !== 'all') ? "No policies match your filters" : "No policies found"}
            </h3>
            <p className="text-gray-600 dark:text-[var(--covoria-text-secondary)] mb-6">
              {searchTerm || Object.values(filters).some(f => f !== 'all') ? "Try adjusting your search or filters." : "Upload documents or add your first policy to get started."}
            </p>
            <Button
              onClick={() => setAddDialogOpen(true)}
              className="covoria-gradient text-white"
            >
              <Plus className="w-5 h-5 mr-2" />
              Add Your First Policy
            </Button>
          </motion.div>
        )}

        {/* Dialogs */}
        {addDialogOpen && (
          <AddPolicyDialog
            isOpen={addDialogOpen}
            onClose={() => {
              setAddDialogOpen(false);
              setEditingPolicy(null);
            }}
            onUpdate={handleUpdate}
            policy={editingPolicy}
          />
        )}
      </div>
    </div>
  );
}
