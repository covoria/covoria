import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { InsuranceKnowledgeBase } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Search, Database, AlertTriangle } from 'lucide-react';

export default function KnowledgeBaseViewer() {
  const [entries, setEntries] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      try {
        const data = await InsuranceKnowledgeBase.list('-created_date');
        setEntries(data || []);
      } catch (error) {
        console.error("Failed to load knowledge base:", error);
        setEntries([]);
      } finally {
        setIsLoading(false);
      }
    }
    fetchData();
  }, []);

  const filteredEntries = useMemo(() => {
    return entries.filter(entry => {
      const searchMatch = searchTerm.toLowerCase() === '' ||
        entry.sectionTitle?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entry.content?.toLowerCase().includes(searchTerm.toLowerCase());
      
      const typeMatch = filterType === 'all' || entry.insuranceType === filterType;

      return searchMatch && typeMatch;
    });
  }, [entries, searchTerm, filterType]);
  
  const uniqueInsuranceTypes = useMemo(() => {
      const types = new Set(entries.map(e => e.insuranceType));
      return ['all', ...Array.from(types)];
  }, [entries]);

  return (
    <div className="p-4 md:p-6 min-h-screen">
      <div className="flex items-center gap-4 mb-6">
        <div className="p-3 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-xl">
          <Database className="w-8 h-8 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-white">Knowledge Base Viewer</h1>
          <p className="text-slate-400">Direct view of the `InsuranceKnowledgeBase` table content.</p>
        </div>
      </div>

      <Card className="bg-slate-800/50 border-slate-700 mb-6">
        <CardContent className="p-4 flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder={`Search ${entries.length} entries...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-800 border-slate-700 pl-10"
            />
          </div>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-full md:w-[200px] bg-slate-800 border-slate-700">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 text-white">
              {uniqueInsuranceTypes.map(type => (
                <SelectItem key={type} value={type} className="capitalize">{type}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-32 w-full bg-slate-700 rounded-lg" />)}
        </div>
      ) : filteredEntries.length === 0 ? (
        <div className="text-center py-16 border border-dashed border-slate-700 rounded-lg">
            <AlertTriangle className="mx-auto h-12 w-12 text-yellow-500" />
            <h3 className="mt-4 text-lg font-medium text-white">{entries.length === 0 ? "The Knowledge Base is empty." : "No entries match your search."}</h3>
            <p className="mt-2 text-sm text-slate-400">{entries.length === 0 ? "No data could be retrieved from the InsuranceKnowledgeBase table." : "Try adjusting your search or filter."}</p>
        </div>
      ) : (
        <div className="space-y-4">
          <p className="text-sm text-slate-400">Showing {filteredEntries.length} of {entries.length} entries.</p>
          {filteredEntries.map(entry => (
            <motion.div
              key={entry.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="bg-slate-800/80 border-slate-700">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-base text-cyan-400">{entry.sectionTitle}</CardTitle>
                    <div className="flex gap-2">
                        <Badge variant="secondary" className="capitalize">{entry.insuranceType || 'general'}</Badge>
                        <Badge variant="outline" className="capitalize">{entry.insightType || 'definition'}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-slate-300 leading-relaxed">{entry.content}</p>
                   {entry.sourceFile && (
                        <p className="text-xs text-slate-500 mt-3 pt-3 border-t border-slate-700">Source: {entry.sourceFile}</p>
                   )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}