
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User } from '@/api/entities';
import { Document } from '@/api/entities';
import { InsuranceKnowledgeBase } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { FileText, Upload, Trash2, RefreshCw, AlertTriangle, CheckCircle, Clock, BookOpen, Search, X } from 'lucide-react';
import { processKnowledgeDocument } from '@/api/functions';

export default function KnowledgeManagement() {
  const [sourceDocuments, setSourceDocuments] = useState([]);
  const [knowledgeEntries, setKnowledgeEntries] = useState([]);
  const [filteredEntries, setFilteredEntries] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  const [uploadError, setUploadError] = useState('');
  const [activeTab, setActiveTab] = useState('files');
  const [searchTerm, setSearchTerm] = useState('');
  const fileInputRef = useRef(null);
  const [isDeleting, setIsDeleting] = useState(null);
  const [isReprocessing, setIsReprocessing] = useState(null);

  const pollerRef = useRef(null);

  const loadAllData = useCallback(async (isPolling = false) => {
    if (!isPolling) setIsLoading(true);
    try {
      const [docs, entries] = await Promise.all([
        Document.filter({ document_type: 'knowledge_source' }, '-created_date'),
        InsuranceKnowledgeBase.list('-created_date')
      ]);
      setSourceDocuments(docs || []);
      setKnowledgeEntries(entries || []);

      // If all documents are processed, stop polling
      const isStillProcessing = (docs || []).some(d => d.status === 'pending' || d.status === 'analyzing');
      if (!isStillProcessing && pollerRef.current) {
        clearInterval(pollerRef.current);
        pollerRef.current = null;
      }

    } catch (error) {
      console.error("Failed to load data:", error);
    } finally {
      if (!isPolling) setIsLoading(false);
    }
  }, []);

  const startPolling = () => {
    if (pollerRef.current) clearInterval(pollerRef.current);
    pollerRef.current = setInterval(() => {
        loadAllData(true);
    }, 5000); 
    // Set a timeout to stop polling after 3 minutes to prevent infinite loops
    setTimeout(() => {
        if(pollerRef.current) {
            clearInterval(pollerRef.current);
            pollerRef.current = null;
        }
    }, 180000); // 3 minutes
  };
  
  useEffect(() => {
    loadAllData();
    return () => {
        if (pollerRef.current) clearInterval(pollerRef.current);
    };
  }, [loadAllData]);

  useEffect(() => {
    if (!knowledgeEntries) return;
    const lowercasedFilter = searchTerm.toLowerCase();
    const filtered = knowledgeEntries.filter(entry => {
      return (
        entry.sectionTitle?.toLowerCase().includes(lowercasedFilter) ||
        entry.content?.toLowerCase().includes(lowercasedFilter) ||
        entry.sourceFile?.toLowerCase().includes(lowercasedFilter)
      );
    });
    setFilteredEntries(filtered);
  }, [knowledgeEntries, searchTerm]);

  const handleReprocess = async (documentId) => {
    setIsReprocessing(documentId);
    try {
        await Document.update(documentId, { status: 'pending', analysis_summary: 'Queued for re-processing...' });
        await processKnowledgeDocument({ documentId });
        startPolling();
    } catch (error) {
        console.error("Failed to trigger re-processing:", error);
        alert('Failed to start re-processing. Please check the logs.');
    } finally {
        setIsReprocessing(null);
    }
  };

  const handleDeleteDocument = async (docToDelete) => {
    if (!confirm(`Are you sure you want to delete "${docToDelete.file_name}" and all associated knowledge entries? This cannot be undone.`)) {
        return;
    }
    setIsDeleting(docToDelete.id);
    try {
        const relatedEntries = await InsuranceKnowledgeBase.filter({ sourceFileId: docToDelete.id });
        for (const entry of relatedEntries) {
            await InsuranceKnowledgeBase.delete(entry.id);
        }
        await Document.delete(docToDelete.id);
        await loadAllData();
    } catch (error) {
        console.error("Failed to delete document:", error);
        alert("An error occurred during deletion.");
    } finally {
        setIsDeleting(null);
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setIsUploading(true);
    setUploadError('');
    setUploadProgress(`Validating "${file.name}"...`);
    
    if (!file.type.includes('pdf')) {
      setUploadError('Invalid file type. Please upload a PDF.');
      setIsUploading(false);
      return;
    }

    try {
      setUploadProgress(`Uploading "${file.name}"...`);
      const { file_url } = await UploadFile({ file });
      
      const user = await User.me();
      const newDoc = await Document.create({
        file_name: file.name,
        file_url: file_url,
        document_type: 'knowledge_source',
        status: 'pending',
        user_email: user.email,
        analysis_summary: 'File uploaded, awaiting processing.'
      });
      
      setSourceDocuments(prev => [newDoc, ...prev]);

      // Trigger processing immediately
      await processKnowledgeDocument({ documentId: newDoc.id });
      startPolling();

      setUploadProgress(`Processing started for "${file.name}". Check back soon.`);
      localStorage.setItem('covoria_assistant_refresh_needed', 'true');
      
    } catch (error) {
      console.error("File upload failed:", error);
      setUploadError(`Upload failed: ${error.message}`);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
      setTimeout(() => {
        setUploadProgress('');
        setUploadError('');
      }, 5000);
    }
  };

  const renderStatusBadge = (doc) => {
    const statusConfig = {
        pending: { icon: Clock, color: "text-yellow-400", bgColor: "bg-yellow-900/50", label: "Pending" },
        analyzing: { icon: RefreshCw, color: "text-cyan-400", bgColor: "bg-cyan-900/50", label: "Analyzing...", animate: true },
        completed: { icon: CheckCircle, color: "text-green-400", bgColor: "bg-green-900/50", label: "Completed" },
        failed: { icon: AlertTriangle, color: "text-red-400", bgColor: "bg-red-900/50", label: "Failed" }
    };
    const config = statusConfig[doc.status] || statusConfig.pending;
    
    return (
        <Badge variant="outline" className={`border-none ${config.bgColor} ${config.color}`}>
            <config.icon className={`w-3 h-3 mr-1.5 ${config.animate || isReprocessing === doc.id ? 'animate-spin' : ''}`} />
            {isReprocessing === doc.id ? 'Starting...' : config.label}
        </Badge>
    );
  };
  
  const SourceFilesTab = () => (
    <div className="space-y-4">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-lg">Upload Knowledge Source File</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-600 rounded-lg">
            <Upload className="w-10 h-10 text-slate-400 mb-2" />
            <p className="mb-4 text-sm text-slate-300">Drop a PDF here or click to upload</p>
            <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" id="knowledge-upload" accept=".pdf"/>
            <Button onClick={() => fileInputRef.current.click()} disabled={isUploading}>
              {isUploading ? 'Uploading...' : 'Choose File'}
            </Button>
            {uploadProgress && <p className="mt-3 text-sm text-cyan-400">{uploadProgress}</p>}
            {uploadError && <p className="mt-3 text-sm text-red-400">{uploadError}</p>}
          </div>
        </CardContent>
      </Card>
      
      <div className="space-y-3">
        {isLoading ? (
          [...Array(2)].map((_, i) => <Skeleton key={i} className="h-24 w-full bg-slate-700 rounded-lg" />)
        ) : sourceDocuments.length === 0 ? (
          <div className="text-center py-10 border border-dashed border-slate-700 rounded-lg">
            <FileText className="mx-auto h-10 w-10 text-slate-500" />
            <h3 className="mt-2 text-sm font-medium text-white">No source files uploaded</h3>
            <p className="mt-1 text-sm text-slate-400">Upload a PDF to get started.</p>
          </div>
        ) : (
          sourceDocuments.map((doc) => (
            <div key={doc.id} className="bg-slate-800/50 p-4 rounded-lg flex items-start gap-4 transition-all hover:bg-slate-800">
              <FileText className="w-6 h-6 text-slate-400 mt-1 flex-shrink-0" />
              <div className="flex-grow min-w-0">
                  <p className="text-white font-medium truncate" title={doc.file_name}>{doc.file_name}</p>
                  <div className="flex items-center gap-2 mt-1">
                      {renderStatusBadge(doc)}
                      <p className="text-xs text-slate-500">Uploaded: {new Date(doc.created_date).toLocaleDateString()}</p>
                  </div>
                  {doc.analysis_summary && (
                      <p className={`text-xs mt-1.5 ${doc.status === 'failed' ? 'text-red-400' : 'text-slate-400'}`}>{doc.analysis_summary}</p>
                  )}
              </div>
              <div className="flex-shrink-0 flex gap-2 items-center">
                  {doc.status === 'failed' && (
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-cyan-400 hover:bg-cyan-900/50" onClick={() => handleReprocess(doc.id)} disabled={isReprocessing === doc.id} title="Re-process File">
                          <RefreshCw className={`w-4 h-4 ${isReprocessing === doc.id ? 'animate-spin' : ''}`} />
                      </Button>
                  )}
                  <Button 
                      size="icon" 
                      variant="ghost" 
                      className="h-8 w-8 text-red-400 hover:bg-red-900/50" 
                      onClick={() => handleDeleteDocument(doc)}
                      disabled={isDeleting === doc.id}
                      title="Delete File and Entries"
                  >
                      {isDeleting === doc.id ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                  </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );

  const KnowledgeEntriesTab = () => (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <Input
          type="text"
          placeholder="Search entries by title, content, or source file..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-slate-800 border-slate-700 pl-10"
        />
        {searchTerm && (
          <Button size="icon" variant="ghost" className="absolute right-2 top-1/2 -translate-y-1/2 h-7 w-7" onClick={() => setSearchTerm('')}>
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>
      
      {isLoading ? (
         [...Array(3)].map((_, i) => <Skeleton key={i} className="h-24 w-full bg-slate-700 rounded-lg" />)
      ) : filteredEntries.length === 0 ? (
        <div className="text-center py-10 border border-dashed border-slate-700 rounded-lg">
          <BookOpen className="mx-auto h-10 w-10 text-slate-500" />
          <h3 className="mt-2 text-sm font-medium text-white">{knowledgeEntries.length > 0 ? 'No entries match your search' : 'No knowledge entries found'}</h3>
          <p className="mt-1 text-sm text-slate-400">{knowledgeEntries.length > 0 ? 'Try a different search term.' : 'Upload a source file to extract knowledge.'}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredEntries.map(entry => (
            <motion.div
              key={entry.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base text-cyan-400">{entry.sectionTitle}</CardTitle>
                  <div className="flex items-center gap-2 flex-wrap text-xs pt-2">
                    <Badge variant="secondary">{entry.insuranceType}</Badge>
                    <Badge variant="secondary">{entry.insightType}</Badge>
                    <p className="text-slate-400">
                      Source: <span className="font-medium text-slate-300 truncate" title={entry.sourceFile}>{entry.sourceFile}</span>
                    </p>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-slate-300 leading-relaxed">{entry.content}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="p-4 md:p-6 min-h-screen">
       <div className="flex items-center gap-4 mb-6">
          <div className="p-3 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl">
            <BookOpen className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Knowledge Base</h1>
            <p className="text-slate-400">Manage expert documents and AI-extracted insights</p>
          </div>
        </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-slate-800">
          <TabsTrigger value="files" className="gap-2"><FileText className="w-4 h-4" />Source Files</TabsTrigger>
          <TabsTrigger value="entries" className="gap-2"><BookOpen className="w-4 h-4" />Knowledge Entries ({knowledgeEntries.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="files" className="mt-4">
          <SourceFilesTab />
        </TabsContent>
        <TabsContent value="entries" className="mt-4">
          <KnowledgeEntriesTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
