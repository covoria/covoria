

import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutDashboard,
  Shield,
  PiggyBank,
  Lightbulb,
  MessageCircle,
  Home,
  Target,
  FileText,
  Lock,
  ArrowRight,
  User as UserIcon,
  DownloadCloud,
  Menu,
  X,
  BarChart3,
  BookOpen,
  ClipboardList,
  Brain, // NEW icon for Behavioral Trainer
  LifeBuoy, // Existing but added for clarity from outline
  Settings, // Existing but added for clarity from outline
  Bot, // Existing but added for clarity from outline
  Landmark, // Existing but added for clarity from outline
  FileUp, // Existing but added for clarity from outline
  FlaskConical, // Existing but added for clarity from outline
  BarChart, // Existing but added for clarity from outline
  BrainCircuit, // New Icon - System Sync
} from "lucide-react";
import { LanguageProvider } from "./components/shared/LanguageProvider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input"; // Fixed syntax error: removed '1'
import { motion, AnimatePresence } from "framer-motion";

// Password gate for partner/admin routes
function PartnerPasswordGate({ onAuthenticated, routeName }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      if (password === 'gabriel2025') {
        const sessionDuration = 2 * 60 * 60 * 1000; // 2 hours
        const sessionData = {
          timestamp: Date.now(),
          duration: sessionDuration,
        };
        localStorage.setItem('covoria_partner_session', JSON.stringify(sessionData));
        onAuthenticated();
      } else {
        setError('❌ Incorrect password');
        setPassword('');
      }
      setIsLoading(false);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-8 shadow-xl">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">🔐</span>
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Partner Access Only</h1>
            <p className="text-slate-400">Please enter password to continue to {routeName}.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              type="password"
              placeholder="Enter admin password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
              className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 text-center"
              autoComplete="off"
            />

            {error && (
              <p className="text-red-400 text-sm text-center">{error}</p>
            )}

            <Button
              type="submit"
              className="w-full bg-orange-600 hover:bg-orange-700 text-white"
              disabled={isLoading || !password.trim()}
            >
              {isLoading ? 'Checking...' : 'Enter'}
            </Button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}

function PasswordGate({ onAuthenticated }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(null);
  const correctPassword = 'resman1211';

  useEffect(() => {
    const sessionData = localStorage.getItem('covoria_session');
    if (sessionData) {
      try {
        const { timestamp, duration } = JSON.parse(sessionData);
        const now = Date.now();
        const elapsed = now - timestamp;

        if (elapsed < duration) {
          const remaining = duration - elapsed;
          setTimeRemaining(remaining);
          onAuthenticated();

          const interval = setInterval(() => {
            const newRemaining = duration - (Date.now() - timestamp);
            if (newRemaining <= 0) {
              localStorage.removeItem('covoria_session');
              clearInterval(interval);
              setTimeRemaining(null);
            } else {
              setTimeRemaining(newRemaining);
            }
          }, 1000);

          return () => clearInterval(interval);
        } else {
          localStorage.removeItem('covoria_session');
        }
      } catch (e) {
        localStorage.removeItem('covoria_session');
      }
    }
  }, [onAuthenticated]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      if (password === correctPassword) {
        const sessionDuration = 2 * 60 * 60 * 1000;
        const sessionData = {
          timestamp: Date.now(),
          duration: sessionDuration
        };
        localStorage.setItem('covoria_session', JSON.stringify(sessionData));
        setTimeRemaining(sessionDuration);
        onAuthenticated();
      } else {
        setError('Nice try 😏 — but that\'s not it.');
        setPassword('');
      }
      setIsLoading(false);
    }, 500);
  };

  const formatTimeRemaining = (ms) => {
    if (ms === null || ms < 0) return '';
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor((totalSeconds / 3600) % 24);
    const minutes = Math.floor((totalSeconds % 3600) / 60);

    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes}m`;
    }
  };

  return (
    <div className="min-h-screen w-full relative overflow-hidden" style={{
      background: 'linear-gradient(135deg, #0D1117 0%, #161B22 25%, #21262D 50%, #161B22 75%, #0D1117 100%)'
    }}>
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute w-96 h-96 rounded-full opacity-10"
          style={{
            background: 'radial-gradient(circle, #00C9FF 0%, #36D399 100%)',
            top: '-10%',
            left: '-10%'
          }}
          animate={{
            x: [0, 30, 0],
            y: [0, -20, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute w-80 h-80 rounded-full opacity-8"
          style={{
            background: 'radial-gradient(circle, #FACC15 0%, #00C9FF 100%)',
            bottom: '-15%',
            right: '-15%'
          }}
          animate={{
            x: [0, -25, 0],
            y: [0, 15, 0],
            scale: [1, 0.9, 1]
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400 rounded-full opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.3, 0.8, 0.3]
            }}
            transition={{
              duration: 3 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 2
            }}
          />
        ))}

        <div
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 201, 255, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 201, 255, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        />
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-md"
        >
          <div className="relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 rounded-3xl blur opacity-20 group-hover:opacity-30 transition duration-1000"></div>

            <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-2xl">
              <div className="text-center mb-8">
                <motion.div
                  className="mx-auto mb-6 relative"
                  animate={{
                    rotateY: [0, 5, 0, -5, 0]
                  }}
                  transition={{
                    duration: 6,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <div className="relative w-20 h-20 mx-auto">
                    <div className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 opacity-20 animate-pulse"></div>
                    <div className="absolute inset-2 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 flex items-center justify-center">
                      <Lock className="h-8 w-8 text-white" />
                    </div>
                  </div>
                </motion.div>

                <motion.h1
                  className="text-3xl font-bold text-white mb-2"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.6 }}
                >
                  Welcome to <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Covoria</span>
                </motion.h1>

                <motion.p
                  className="text-gray-300 text-base leading-relaxed mb-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5, duration: 0.6 }}
                >
                  If Michael gave you the password, you're in.<br />
                  If not — no hard feelings. Just know this app<br />
                  <span className="text-cyan-400 font-medium">might change the insurance game.</span>
                </motion.p>

                {timeRemaining && (
                  <motion.div
                    className="mt-4 p-3 bg-green-500/10 border border-green-500/20 rounded-xl backdrop-blur-sm"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.7, duration: 0.4 }}
                  >
                    <p className="text-sm text-green-400 flex items-center justify-center gap-2">
                      <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                      Session expires in: {formatTimeRemaining(timeRemaining)}
                    </p>
                  </motion.div>
                )}
              </div>

              <motion.form
                onSubmit={handleSubmit}
                className="space-y-6"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.6 }}
              >
                <div className="space-y-2">
                  <div className="relative">
                    <Input
                      type="password"
                      placeholder="Enter access password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      disabled={isLoading}
                      className="w-full h-14 bg-slate-800/50 border border-slate-600 rounded-2xl text-white placeholder-slate-400 text-center text-lg font-mono tracking-widest backdrop-blur-sm focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition-all duration-300"
                      autoComplete="off"
                    />
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-400/20 to-blue-500/20 opacity-0 focus-within:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
                  </div>

                  {error && (
                    <motion.p
                      initial={{ opacity: 0, y: -10, scale: 0.9 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      className="text-red-400 text-sm text-center bg-red-500/10 border border-red-500/20 rounded-xl py-2 px-4"
                    >
                      {error}
                    </motion.p>
                  )}
                </div>

                <Button
                  type="submit"
                  className="w-full h-14 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold text-lg rounded-2xl transition-all duration-300 transform hover:scale-[1.02] hover:shadow-2xl hover:shadow-cyan-500/25 disabled:opacity-50 disabled:transform-none disabled:hover:shadow-none"
                  disabled={isLoading || !password.trim()}
                >
                  {isLoading ? (
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Accessing Covoria...
                    </div>
                  ) : (
                    <div className="flex items-center gap-3">
                      Enter Covoria
                      <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
                    </div>
                  )}
                </Button>
              </motion.form>

              <motion.div
                className="mt-8 text-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1, duration: 0.6 }}
              >
                <p className="text-xs text-gray-500">
                  Powered by advanced AI • Enterprise-grade security
                </p>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function AppLayout({ children, currentPageName }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [isPartnerAuthenticated, setIsPartnerAuthenticated] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', 'dark');
    
    // Check for partner session
    const partnerSessionData = localStorage.getItem('covoria_partner_session');
    if (partnerSessionData) {
      try {
        const { timestamp, duration } = JSON.parse(partnerSessionData);
        if (Date.now() - timestamp < duration) {
          setIsPartnerAuthenticated(true);
        } else {
          localStorage.removeItem('covoria_partner_session');
        }
      } catch (e) {
        localStorage.removeItem('covoria_partner_session');
      }
    }
  }, []);

  // Effect to handle Escape key to close the nav
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        setIsNavOpen(false);
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    let isHandlingBack = false;

    const handleAndroidBack = (event) => {
      if (isHandlingBack) return;
      isHandlingBack = true;

      event.preventDefault();

      const currentPath = location.pathname;

      const navigationHierarchy = {
        '/Settings': '/Dashboard',
        '/Insurance': '/Dashboard',
        '/Savings': '/Dashboard',
        '/Insights': '/Dashboard',
        '/CoverageAnalysis': '/Dashboard',
        '/DocumentVault': '/Dashboard',
        '/KnowledgeManagement': '/Dashboard',
        '/Assistant': '/Dashboard',
        '/AdminDashboard': '/Dashboard',
        '/PartnerReports': '/AdminDashboard',
        '/ProductCatalog': '/AdminDashboard',
        '/UserProfile': '/Dashboard',
        '/FutureOutlook': '/Dashboard',
        '/KnowledgeBaseViewer': '/AdminDashboard',
        '/BehavioralTrainerViewer': '/AdminDashboard',
        '/PersonalizedPolicyAnalysis': '/Dashboard', // Added for back navigation
        '/MyInsuranceCopilot': '/Dashboard', // Added for back navigation
        '/FounderDashboard': '/AdminDashboard', // Added for back navigation
        '/SystemSync': '/Dashboard', // Added for back navigation
        '/': '/Dashboard',
        '/Dashboard': null
      };

      const parentPath = navigationHierarchy[currentPath];

      if (parentPath) {
        navigate(parentPath);
      } else if (currentPath === '/Dashboard') {
        if (window.history.length > 1) {
          window.history.back();
        }
      } else {
        navigate('/Dashboard');
      }

      setTimeout(() => {
        isHandlingBack = false;
      }, 100);
    };

    const handlePopState = (event) => {
      // React Router handles this
    };

    document.addEventListener('backbutton', handleAndroidBack, false);
    window.addEventListener('popstate', handlePopState);

    const handleKeyDown = (event) => {
      if (event.key === 'Escape' || (event.altKey && event.key === 'ArrowLeft')) {
        handleAndroidBack(event);
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('backbutton', handleAndroidBack, false);
      window.removeEventListener('popstate', handlePopState);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [navigate, location.pathname]);

  const userNavItems = [
    { key: "home", icon: Home, url: createPageUrl("Settings"), label: "Home" }, // Changed to settings as per previous context
    { key: "copilot", icon: Bot, url: createPageUrl("MyInsuranceCopilot"), label: "My Insurance Co-Pilot" },
    { key: "dashboard", icon: LayoutDashboard, url: createPageUrl("Dashboard"), label: "Dashboard" },
    { key: "insurance", icon: Shield, url: createPageUrl("Insurance"), label: "Insurance" },
    { key: "savings", icon: Landmark, url: createPageUrl("Savings"), label: "Savings" },
    { key: "document-vault", icon: FileUp, url: createPageUrl("DocumentVault"), label: "Documents" },
    { key: "system-sync", icon: BrainCircuit, url: createPageUrl("SystemSync"), label: "System Sync" }, // NEW
    { key: "user-profile", icon: UserIcon, url: createPageUrl("UserProfile"), label: "Profile" },
    { key: "assistant", icon: MessageCircle, url: createPageUrl("Assistant"), label: "Assistant" },
    { key: "admin", icon: Lock, url: createPageUrl("AdminDashboard"), label: "Admin" },
  ];

  // Show partner nav items only if partner access is granted
  const partnerNavItems = isPartnerAuthenticated ? [
    { key: "founder-dashboard", icon: BarChart3, url: createPageUrl("FounderDashboard"), label: "Founder Analytics" },
    { key: "partner-reports", icon: BarChart3, url: createPageUrl("PartnerReports"), label: "Advanced Analytics" },
    { key: "product-catalog", icon: FileText, url: createPageUrl("ProductCatalog"), label: "Product Catalog" },
    { key: "knowledge-management", icon: BookOpen, url: createPageUrl("KnowledgeManagement"), label: "Knowledge Base" }, 
    { key: "knowledge-viewer", icon: ClipboardList, url: createPageUrl("KnowledgeBaseViewer"), label: "Knowledge Viewer" }
  ] : [];

  useEffect(() => {
    const sessionData = localStorage.getItem('covoria_session');
    if (sessionData) {
      try {
        const { timestamp, duration } = JSON.parse(sessionData);
        const elapsed = Date.now() - timestamp;
        if (elapsed < duration) {
          setIsAuthenticated(true);
        } else {
          localStorage.removeItem('covoria_session');
          setIsAuthenticated(false);
        }
      } catch (e) {
        localStorage.removeItem('covoria_session');
        setIsAuthenticated(false);
      }
    } else {
      setIsAuthenticated(false);
    }
  }, []);

  if (!isAuthenticated) {
    return <PasswordGate onAuthenticated={() => setIsAuthenticated(true)} />;
  }

  // Check if current route requires partner authentication
  const partnerRoutes = ['/AdminDashboard', '/PartnerReports', '/ProductCatalog', '/KnowledgeManagement', '/KnowledgeBaseViewer', '/BehavioralTrainerViewer', '/FounderDashboard'];
  const isPartnerRoute = partnerRoutes.some(route => location.pathname.startsWith(createPageUrl(route.substring(1))));
  
  if (isPartnerRoute && !isPartnerAuthenticated) {
    return <PartnerPasswordGate 
      onAuthenticated={() => setIsPartnerAuthenticated(true)}
      routeName={currentPageName}
    />;
  }

  const isHomePage = location.pathname === createPageUrl('Settings');

  return (
    <>
      <style>{`
        :root {
          --covoria-bg-main: #0f172a; /* slate-900 */
          --covoria-bg-surface: #1e293b; /* slate-800 */
          --covoria-accent: #38bdf8; /* cyan-400 */
          --covoria-card-bg: #1e293b; /* Solid slate-800 */
          --covoria-border-color: #334155; /* slate-700 */
          --covoria-text-primary: #f8fafc; /* slate-50 - BRIGHTENED */
          --covoria-text-secondary: #cbd5e1; /* slate-300 - BRIGHTENED */
          font-size: clamp(14px, 2vw, 16px); /* Responsive Font Scaling */
        }

        body, html {
          background-color: var(--covoria-bg-main);
          font-family: sans-serif;
          overflow-x: hidden; /* Prevent horizontal scroll on body */
        }

        .covoria-card {
          background-color: var(--covoria-card-bg);
          border: 1px solid var(--covoria-border-color);
          border-radius: 1rem; /* Consistent rounded-2xl is 1rem */
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
          overflow: hidden;
          padding: 1rem 1.25rem; /* Adjusted padding */
        }

        .covoria-gradient {
          background-image: linear-gradient(to right, #06b6d4, #3b82f6);
        }

        /* Global Typography Fixes */
        h1, h2, h3, h4, h5, h6 {
          font-weight: 600;
          letter-spacing: -0.025em;
          color: var(--covoria-text-primary);
          line-height: 1.3;
        }

        /* Improved text contrast across dashboard */
        .text-slate-100, .text-white {
          color: #f8fafc !important; /* Brighter white */
        }
        
        .text-slate-200 {
          color: #e2e8f0 !important; /* Brighter light gray */
        }
        
        .text-slate-300 {
          color: #cbd5e1 !important; /* Brighter medium gray */
        }

        /* Fix for insight cards */
        .insight-card {
          background: #1e293b !important;
          backdrop-filter: none !important;
          filter: none !important;
        }

        .insight-card .insight-card-title {
          color: #f8fafc !important;
          font-weight: 700 !important;
          opacity: 1 !important;
        }

        .insight-card p {
          color: #e2e8f0 !important;
          opacity: 1 !important;
        }

        /* Text truncation utilities */
        .truncate {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        /* Enhanced chat bubble width */
        .chat-message-bubble {
          max-width: 85% !important;
          width: auto !important;
          word-wrap: break-word;
          overflow-wrap: break-word;
        }

        /* Tooltip styles */
        .tooltip {
          background: #020617; /* slate-950 */
          color: white;
          border-radius: 0.5rem;
          padding: 8px 12px;
          font-size: 0.75rem;
          border: 1px solid var(--covoria-border-color);
        }

        /* Enhanced Scrollbar and Scroll Container styles */
        .custom-scrollbar {
            overflow-y: auto;
            -webkit-overflow-scrolling: touch; /* Momentum scrolling for iOS */
            scroll-behavior: smooth;
            scrollbar-width: thin;
            scrollbar-color: #475569 #1e293b;
            padding-bottom: 80px; /* Prevent scroll lock */
        }
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: rgba(30, 41, 59, 0.1);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background-color: #475569;
            border-radius: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background-color: #64748b;
        }
        
        /* Horizontal Scroll for Tabs/Filters */
        .horizontal-scroll-container {
          overflow-x: auto;
          -webkit-overflow-scrolling: touch;
          scroll-behavior: smooth;
          scroll-snap-type: x proximity;
          -ms-overflow-style: none;  /* IE and Edge */
          scrollbar-width: none;  /* Firefox */
        }
        .horizontal-scroll-container::-webkit-scrollbar {
          display: none; /* Hide scrollbar for Chrome, Safari and Opera */
        }
        .horizontal-scroll-container > * {
          flex-shrink: 0;
          scroll-snap-align: start;
        }

        /* Global Text Wrapping Fix */
        .text-overflow-safe, .card-content, .insight-card-text, .button-label {
          white-space: normal;
          overflow-wrap: break-word;
          word-break: break-word;
          line-height: 1.5;
        }
        
        .main-content-wrapper {
            padding-inline: 16px;
            max-width: 1080px; /* Max width for desktop/tablet */
            margin: 0 auto;
            box-sizing: border-box;
        }
        
        @media (max-width: 768px) {
            .main-content-wrapper {
                max-width: 95vw; /* Near full width for mobile */
            }
        }
      `}</style>
      <div className="relative min-h-screen bg-slate-900 text-slate-200">
        {/* Floating Nav Button with glow effect */}
        <div className="fixed top-4 left-4 z-50">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              onClick={() => setIsNavOpen(true)}
              size="icon"
              className="w-12 h-12 rounded-full covoria-gradient shadow-lg hover:shadow-cyan-500/25 transition-all duration-300"
            >
              <Menu className="w-6 h-6" />
            </Button>
          </motion.div>
        </div>

        {/* Enhanced Sidebar */}
        <AnimatePresence>
          {isNavOpen && (
            <>
              {/* Overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
                onClick={() => setIsNavOpen(false)}
              />

              {/* Sidebar content */}
              <motion.aside
                initial={{ x: "-100%" }}
                animate={{ x: 0 }}
                exit={{ x: "-100%" }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="fixed top-0 left-0 h-full w-64 bg-slate-900/95 backdrop-blur-xl border-r border-slate-700/50 flex flex-col z-50 rounded-r-3xl"
              >
                 <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsNavOpen(false)}
                    className="absolute top-4 right-4 text-slate-400 hover:text-white hover:bg-slate-700/50 z-10 rounded-full"
                    aria-label="Close navigation"
                 >
                    <X className="w-5 h-5" />
                 </Button>

                 <div className="p-6 border-b border-slate-700/50">
                   <img
                      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/8c8e485f4_file_00000000a74c61fa895c27e866860641.png"
                      alt="Covoria Icon"
                      className="h-12 w-auto object-contain mx-auto brightness-150"
                      draggable="false"
                    />
                  </div>
                  
                  <nav className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-6">
                   <div>
                      <p className="px-3 text-xs text-slate-400 uppercase tracking-widest mb-3">User Interface</p>
                      <ul className="space-y-1">
                          {userNavItems.map(item => (
                              <li key={item.key}>
                                  <Link
                                    to={item.url}
                                    onClick={() => setIsNavOpen(false)}
                                    className={`flex items-center gap-3 text-slate-300 text-sm py-3 px-4 rounded-xl hover:bg-slate-800/60 hover:text-white transition-all duration-200 ${
                                      location.pathname === item.url ? 'bg-cyan-900/50 text-white font-semibold border-l-4 border-cyan-400' : ''
                                    }`}
                                  >
                                    <item.icon className="w-5 h-5 flex-shrink-0" />
                                    <span className="mobile-safe-text">{item.label}</span>
                                  </Link>
                              </li>
                          ))}
                      </ul>
                   </div>

                   {/* Partner Interface section - only shown if admin access is granted */}
                   {partnerNavItems.length > 0 && (
                     <div>
                        <p className="px-3 text-xs text-slate-400 uppercase tracking-widest mb-3">Partner Interface</p>
                        <ul className="space-y-1">
                            {partnerNavItems.map(item => {
                                // Hide Behavioral Training Viewer as requested in outline
                                if (item.key === 'behavioral-trainer') return null;
                                
                                return (
                                    <li key={item.key}>
                                        <Link
                                          to={item.url}
                                          onClick={() => setIsNavOpen(false)}
                                          className={`flex items-center gap-3 text-slate-300 text-sm py-3 px-4 rounded-xl hover:bg-slate-800/60 hover:text-white transition-all duration-200 ${
                                            location.pathname === item.url ? 'bg-zinc-700 text-white font-semibold border-l-4 border-zinc-400' : ''
                                          }`}
                                        >
                                            <item.icon className="w-5 h-5 flex-shrink-0" />
                                            <span className="mobile-safe-text">{item.label}</span>
                                        </Link>
                                    </li>
                                );
                            })}
                        </ul>
                     </div>
                   )}
                  </nav>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* Main Content Area */}
        <main className="w-full h-screen overflow-y-auto custom-scrollbar" style={{backgroundColor: 'var(--covoria-bg-main)'}}>
           {!isHomePage && (
              <header className="sticky top-0 z-30 w-full bg-slate-900/80 backdrop-blur-lg border-b border-700/50">
                <div className="flex items-center justify-center px-4 sm:px-6 py-4 relative h-16">
                  <h2 className="text-xl font-semibold tracking-tight text-white leading-snug break-words max-w-full text-center mobile-safe-text">
                    {[...userNavItems, ...partnerNavItems].find(item => item.url === location.pathname)?.label || currentPageName}
                  </h2>
                </div>
              </header>
            )}

          <div className={`w-full  pb-20 overflow-x-hidden`}>
              <div className="main-content-wrapper">
                  {children}
              </div>
          </div>
        </main>
      </div>
    </>
  );
}

export default function Layout({ children, currentPageName }) {
  return (
    <LanguageProvider>
      <AppLayout currentPageName={currentPageName}>
        {children}
      </AppLayout>
    </LanguageProvider>
  );
}

