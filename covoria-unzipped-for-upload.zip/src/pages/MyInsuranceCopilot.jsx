
import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { RefreshCw, MessageCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Insight } from '@/api/entities';
import { ForecastItem } from '@/api/entities';

// Import Tile Components
import CurrentInsightsTile from '../components/copilot/CurrentInsightsTile';
import FutureOutlookTile from '../components/copilot/FutureOutlookTile';
import CoverageGapsTile from '../components/copilot/CoverageGapsTile';
import SuggestedActionsTile from '../components/copilot/SuggestedActionsTile';
import RiskScannerTile from '../components/copilot/RiskScannerTile';
import LifeScenarioAdvisorTile from '../components/copilot/LifeScenarioAdvisorTile';

export default function MyInsuranceCopilot() {
    const [insights, setInsights] = useState([]);
    const [forecasts, setForecasts] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const navigate = useNavigate();

    const loadData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [insightData, forecastData] = await Promise.all([
                Insight.list('-created_date', 50),
                ForecastItem.list('-created_date', 50)
            ]);
            setInsights(insightData || []); // Ensure always array
            setForecasts(forecastData || []); // Ensure always array
        } catch (error) {
            console.error("Failed to load copilot data:", error);
            setInsights([]); // Set to empty array on error
            setForecasts([]); // Set to empty array on error
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        loadData();
    }, [loadData]);
    
    // Safe calculations with array checks
    const coverageGapsCount = Array.isArray(insights) ? insights.filter(i => i.category === 'coverage_gap').length : 0;
    const suggestedActionsCount = Array.isArray(insights) ? insights.filter(i => i.action_required).length : 0;
    const risksCount = Array.isArray(forecasts) ? forecasts.filter(f => ['high', 'critical'].includes(f.risk_level)).length : 0;

    const tiles = [
        { id: 'insights', component: <CurrentInsightsTile insights={insights} isLoading={isLoading} /> },
        { id: 'outlook', component: <FutureOutlookTile forecasts={forecasts} isLoading={isLoading} /> },
        { id: 'gaps', component: <CoverageGapsTile count={coverageGapsCount} insights={insights} isLoading={isLoading} /> },
        { id: 'actions', component: <SuggestedActionsTile count={suggestedActionsCount} insights={insights} isLoading={isLoading} /> },
        { id: 'risk', component: <RiskScannerTile count={risksCount} insights={insights} isLoading={isLoading} /> },
        { id: 'scenarios', component: <LifeScenarioAdvisorTile isLoading={isLoading} /> },
    ];

    return (
        <div className="p-4 md:p-6 min-h-screen">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div>
                    <h1 className="text-3xl font-bold text-slate-100">AI Co-Pilot</h1>
                    <p className="text-slate-400">Your intelligent financial command center.</p>
                </div>
                <div className="flex gap-2">
                    <Button onClick={loadData} variant="outline" disabled={isLoading} className="bg-slate-800/50 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white">
                        <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                        Refresh
                    </Button>
                    <Button onClick={() => navigate(createPageUrl('Assistant'))} className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Ask AI
                    </Button>
                </div>
            </div>

            <motion.div 
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
                initial="hidden"
                animate="visible"
                variants={{
                    visible: {
                        transition: {
                            staggerChildren: 0.1
                        }
                    }
                }}
            >
                {tiles.map((tile, index) => (
                    <motion.div key={tile.id} variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}>
                        {tile.component}
                    </motion.div>
                ))}
            </motion.div>
        </div>
    );
}
