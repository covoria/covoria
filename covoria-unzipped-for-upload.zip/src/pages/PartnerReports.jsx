
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Download, Users, FileText, Lightbulb, BarChart3, RefreshCw } from 'lucide-react';
import { User } from '@/api/entities';
import { InsurancePolicy } from '@/api/entities';
import { Insight } from '@/api/entities';
import { motion } from 'framer-motion';

export default function PartnerReports() {
  const [analytics, setAnalytics] = useState({
    totalUsers: 0,
    totalPolicies: 0,
    totalInsights: 0,
    activeUsers: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    setIsLoading(true);
    try {
      // Mock data for now
      setTimeout(() => {
        setAnalytics({
          totalUsers: 1250,
          totalPolicies: 3400,
          totalInsights: 8900,
          activeUsers: 980
        });
        setIsLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Failed to load partner data:', error);
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-blue-900/20 p-6">
      <div className="max-w-7xl mx-auto">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white mb-2">Partner Analytics Dashboard</h1>
            <p className="text-zinc-600 dark:text-zinc-400">Advanced insights and user behavior analysis</p>
          </motion.div>
          <div className="flex items-center gap-2">
            <Button className="bg-cyan-600 text-white hover:bg-cyan-700">
              <Download className="w-4 h-4 mr-2" />
              Export Summary
            </Button>
          </div>
        </header>

        <div className="flex flex-col md:flex-row items-center gap-4 mb-6">
          <Input
            placeholder="Filter by user email or partner domain..."
            className="flex-1 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-200 border-zinc-200 dark:border-zinc-700 placeholder-zinc-500 dark:placeholder-zinc-400 rounded-lg"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-zinc-600 dark:text-zinc-400">Total Users</p>
                    <p className="text-2xl font-bold text-zinc-900 dark:text-white">
                      {isLoading ? '...' : analytics.totalUsers?.toLocaleString() || '0'}
                    </p>
                  </div>
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-zinc-600 dark:text-zinc-400">Total Policies</p>
                    <p className="text-2xl font-bold text-zinc-900 dark:text-white">
                      {isLoading ? '...' : analytics.totalPolicies?.toLocaleString() || '0'}
                    </p>
                  </div>
                  <FileText className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-zinc-600 dark:text-zinc-400">Total Insights</p>
                    <p className="text-2xl font-bold text-zinc-900 dark:text-white">
                      {isLoading ? '...' : analytics.totalInsights?.toLocaleString() || '0'}
                    </p>
                  </div>
                  <Lightbulb className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-zinc-600 dark:text-zinc-400">Active Users</p>
                    <p className="text-2xl font-bold text-zinc-900 dark:text-white">
                      {isLoading ? '...' : analytics.activeUsers?.toLocaleString() || '0'}
                    </p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700">
              <CardHeader>
                <CardTitle className="text-zinc-900 dark:text-white">User Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-400 dark:text-zinc-400">User growth chart coming soon...</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700">
              <CardHeader>
                <CardTitle className="text-zinc-900 dark:text-white">Performance Insights</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-400 dark:text-zinc-400">Performance insights chart coming soon...</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="lg:col-span-2"
          >
            <Card className="bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-zinc-900 dark:text-white">Recent User Activity</CardTitle>
                <Button
                  onClick={loadAnalytics}
                  size="sm"
                  variant="outline"
                  className="bg-zinc-200 text-zinc-900 hover:bg-zinc-300 border-zinc-300"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Refresh
                </Button>
              </CardHeader>
              <CardContent>
                <p className="text-slate-400 dark:text-zinc-400">Detailed user activity list coming soon...</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            <Card className="bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700">
              <CardHeader>
                <CardTitle className="text-zinc-900 dark:text-white">Top Insights</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-400 dark:text-zinc-400">Top insights list coming soon...</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
