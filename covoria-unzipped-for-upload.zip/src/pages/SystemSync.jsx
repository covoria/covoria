import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { insightEngine } from '@/api/functions';
import { futureOutlookEngine } from '@/api/functions';
import { AlertCircle, CheckCircle, Loader2, Zap, Telescope } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

export default function SystemSyncPage() {
    const [isInsightLoading, setIsInsightLoading] = useState(false);
    const [isForecastLoading, setIsForecastLoading] = useState(false);
    const { toast } = useToast();

    const handleRunEngine = async (engineFn, setLoadingFn, engineName) => {
        setLoadingFn(true);
        try {
            const { data, error } = await engineFn();
            if (error || !data.success) {
                throw new Error(data?.error || `The ${engineName} failed to run.`);
            }
            const message = data.message || `Successfully generated ${data.insights_created || data.forecasts_created || 0} new items.`;
            toast({
                title: `${engineName} Completed`,
                description: message,
                variant: 'default',
            });
        } catch (err) {
            toast({
                title: `Error Running ${engineName}`,
                description: err.message,
                variant: 'destructive',
            });
        } finally {
            setLoadingFn(false);
        }
    };

    return (
        <div className="bg-slate-900 min-h-screen text-white p-4 sm:p-6 md:p-8">
            <div className="max-w-4xl mx-auto">
                <header className="mb-8">
                    <h1 className="text-3xl font-bold tracking-tight text-slate-100">System Sync & AI Analysis</h1>
                    <p className="text-slate-400 mt-2">
                        Manually trigger Covoria's AI engines to analyze your complete financial portfolio and generate new insights or forecasts.
                    </p>
                </header>

                <div className="grid md:grid-cols-2 gap-6">
                    <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3 text-xl">
                                <Zap className="text-indigo-400" />
                                Insight Engine
                            </CardTitle>
                            <CardDescription className="text-slate-400 pt-1">
                                Scans all your policies and accounts to find coverage gaps, savings opportunities, and potential risks.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Button 
                                onClick={() => handleRunEngine(insightEngine, setIsInsightLoading, 'Insight Engine')} 
                                disabled={isInsightLoading || isForecastLoading}
                                className="w-full bg-indigo-600 hover:bg-indigo-500"
                            >
                                {isInsightLoading ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Generating Insights...
                                    </>
                                ) : 'Run Insight Analysis'}
                            </Button>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3 text-xl">
                                <Telescope className="text-cyan-400" />
                                Future Outlook Engine
                            </CardTitle>
                            <CardDescription className="text-slate-400 pt-1">
                                Forecasts medium-term (6-18 months) financial risks and opportunities based on your current data.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Button 
                                onClick={() => handleRunEngine(futureOutlookEngine, setIsForecastLoading, 'Future Outlook Engine')} 
                                disabled={isInsightLoading || isForecastLoading}
                                className="w-full bg-cyan-600 hover:bg-cyan-500"
                            >
                                {isForecastLoading ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Generating Forecasts...
                                    </>
                                ) : 'Run Future Outlook'}
                            </Button>
                        </CardContent>
                    </Card>
                </div>
                
                <div className="mt-8 bg-slate-800/30 p-4 rounded-lg border border-slate-700">
                    <div className="flex items-start">
                        <AlertCircle className="h-5 w-5 text-slate-400 mr-3 mt-1" />
                        <div>
                            <h3 className="font-semibold text-slate-200">How does this work?</h3>
                            <p className="text-slate-400 text-sm mt-1">
                                After uploading new documents or making changes, run these engines to update your Co-Pilot with fresh analysis. This process can take a minute or two as the AI reviews all your information. You'll receive a notification when it's complete.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}