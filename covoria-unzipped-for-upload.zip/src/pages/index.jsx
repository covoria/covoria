import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Insurance from "./Insurance";

import Assistant from "./Assistant";

import Settings from "./Settings";

import Savings from "./Savings";

import CoverageAnalysis from "./CoverageAnalysis";

import DocumentVault from "./DocumentVault";

import AdminDashboard from "./AdminDashboard";

import PartnerReports from "./PartnerReports";

import ProductCatalog from "./ProductCatalog";

import AdminAnalytics from "./AdminAnalytics";

import DocumentAnalysisResult from "./DocumentAnalysisResult";

import UserProfile from "./UserProfile";

import KnowledgeManagement from "./KnowledgeManagement";

import KnowledgeBaseViewer from "./KnowledgeBaseViewer";

import SystemSync from "./SystemSync";

import BehavioralTrainerViewer from "./BehavioralTrainerViewer";

import DebugTrainingData from "./DebugTrainingData";

import QuickDatabaseCheck from "./QuickDatabaseCheck";

import MyInsuranceCopilot from "./MyInsuranceCopilot";

import FounderDashboard from "./FounderDashboard";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Insurance: Insurance,
    
    Assistant: Assistant,
    
    Settings: Settings,
    
    Savings: Savings,
    
    CoverageAnalysis: CoverageAnalysis,
    
    DocumentVault: DocumentVault,
    
    AdminDashboard: AdminDashboard,
    
    PartnerReports: PartnerReports,
    
    ProductCatalog: ProductCatalog,
    
    AdminAnalytics: AdminAnalytics,
    
    DocumentAnalysisResult: DocumentAnalysisResult,
    
    UserProfile: UserProfile,
    
    KnowledgeManagement: KnowledgeManagement,
    
    KnowledgeBaseViewer: KnowledgeBaseViewer,
    
    SystemSync: SystemSync,
    
    BehavioralTrainerViewer: BehavioralTrainerViewer,
    
    DebugTrainingData: DebugTrainingData,
    
    QuickDatabaseCheck: QuickDatabaseCheck,
    
    MyInsuranceCopilot: MyInsuranceCopilot,
    
    FounderDashboard: FounderDashboard,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Insurance" element={<Insurance />} />
                
                <Route path="/Assistant" element={<Assistant />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Savings" element={<Savings />} />
                
                <Route path="/CoverageAnalysis" element={<CoverageAnalysis />} />
                
                <Route path="/DocumentVault" element={<DocumentVault />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/PartnerReports" element={<PartnerReports />} />
                
                <Route path="/ProductCatalog" element={<ProductCatalog />} />
                
                <Route path="/AdminAnalytics" element={<AdminAnalytics />} />
                
                <Route path="/DocumentAnalysisResult" element={<DocumentAnalysisResult />} />
                
                <Route path="/UserProfile" element={<UserProfile />} />
                
                <Route path="/KnowledgeManagement" element={<KnowledgeManagement />} />
                
                <Route path="/KnowledgeBaseViewer" element={<KnowledgeBaseViewer />} />
                
                <Route path="/SystemSync" element={<SystemSync />} />
                
                <Route path="/BehavioralTrainerViewer" element={<BehavioralTrainerViewer />} />
                
                <Route path="/DebugTrainingData" element={<DebugTrainingData />} />
                
                <Route path="/QuickDatabaseCheck" element={<QuickDatabaseCheck />} />
                
                <Route path="/MyInsuranceCopilot" element={<MyInsuranceCopilot />} />
                
                <Route path="/FounderDashboard" element={<FounderDashboard />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}